package de.onur.labyrinth.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Zeichnen & Raten: einer zeichnet am Handy, alle anderen raten. 2–12 Spieler. */
public class DrawGame implements GameModule {

    static final String[] WORDS = (
        "Hund,Katze,Maus,Elefant,Giraffe,Löwe,Tiger,Pferd,Kuh,Schwein,Schaf,Huhn,Ente,Fisch,Hai,Wal,Delfin,Schildkröte,Schlange,Frosch," +
        "Spinne,Biene,Schmetterling,Schnecke,Eule,Pinguin,Affe,Bär,Hase,Igel,Fuchs,Wolf,Krokodil,Kamel,Zebra,Känguru,Papagei,Krake,Krabbe,Einhorn," +
        "Drache,Haus,Schloss,Kirche,Brücke,Leuchtturm,Zelt,Iglu,Turm,Ampel,Auto,Bus,Zug,Flugzeug,Hubschrauber,Fahrrad,Motorrad,Schiff,Boot,Rakete," +
        "Traktor,Feuerwehr,Polizei,Krankenwagen,U-Boot,Ballon,Baum,Blume,Rose,Pilz,Kaktus,Palme,Sonne,Mond,Stern,Wolke,Regenbogen,Blitz,Schneemann,Vulkan," +
        "Berg,Insel,Strand,Wasserfall,Apfel,Banane,Birne,Erdbeere,Kirsche,Ananas,Zitrone,Karotte,Kartoffel,Tomate,Pizza,Burger,Pommes,Brezel,Eis,Kuchen," +
        "Torte,Keks,Brot,Käse,Ei,Wurst,Spaghetti,Suppe,Kaffee,Tee,Milch,Stuhl,Tisch,Bett,Sofa,Lampe,Uhr,Wecker,Telefon,Handy," +
        "Computer,Fernseher,Kamera,Schlüssel,Tür,Fenster,Treppe,Leiter,Regenschirm,Brille,Hut,Mütze,Schal,Handschuh,Schuh,Socke,Hose,Kleid,Krawatte,Ring," +
        "Krone,Koffer,Rucksack,Buch,Brief,Stift,Schere,Hammer,Säge,Nagel,Schraube,Besen,Eimer,Kerze,Geschenk,Pinsel,Gitarre,Klavier,Trommel,Trompete," +
        "Ball,Fußball,Tennis,Basketball,Golf,Ski,Schlitten,Skateboard,Angel,Zahnbürste,Seife,Dusche,Badewanne,Toilette,Spiegel,Kamm,Pflaster,Spritze,Herz,Auge," +
        "Nase,Mund,Ohr,Hand,Fuß,Zahn,Knochen,Skelett,Geist,Hexe,Zauberer,Pirat,Ritter,Prinzessin,Roboter,Astronaut,Koch,Arzt,Clown,Engel," +
        "Teufel,Vampir,Mumie,Zombie,Weihnachtsbaum,Osterhase,Kürbis,Feuerwerk,Schatztruhe,Landkarte,Kompass,Anker,Fahne,Rad,Batterie,Glühbirne,Magnet,Steckdose,Kabel,Würfel," +
        "Puzzle,Drachen,Seifenblase,Sandburg,Spielplatz,Rutsche,Schaukel,Karussell,Achterbahn,Zirkus,Kino,Schwimmen,Tanzen,Schlafen,Lachen,Weinen,Laufen,Springen,Kochen,Malen"
    ).split(",");

    static class Seat {
        Player p;
        int score, gained;
        boolean guessed;
        String close = null;
    }

    Random rnd = new Random();
    final List<Seat> seats = new ArrayList<>();
    final Map<Integer, Seat> byId = new HashMap<>();
    String step = "choose"; // choose, draw, reveal
    int drawerIdx = 0, round = 1, rounds = 2, turnSecs = 80;
    String word = null;
    String[] choices = new String[0];
    boolean[] revealed = new boolean[0];
    int hintsGiven = 0;
    long deadline = 0, turnStart = 0;
    final List<StringBuilder> strokes = new ArrayList<>();
    int points = 0, strokeSeq = 0;
    final ArrayDeque<String> chat = new ArrayDeque<>();
    int chatSeq = 0, correctCount = 0;
    boolean finished = false;
    int winner = -1;
    final List<String> usedWords = new ArrayList<>();

    @Override public String id() { return "draw"; }
    @Override public int minPlayers() { return 2; }
    @Override public int maxPlayers() { return 12; }
    @Override public boolean finished() { return finished; }

    @Override
    public void start(List<Player> players, Map<String, String> o, Random rnd) {
        this.rnd = rnd;
        rounds = Math.max(1, Math.min(5, parse(o.get("drounds"), 2)));
        turnSecs = Math.max(30, Math.min(180, parse(o.get("dtime"), 80)));
        seats.clear(); byId.clear(); chat.clear(); usedWords.clear();
        for (Player p : players) { Seat s = new Seat(); s.p = p; seats.add(s); byId.put(p.id, s); }
        drawerIdx = 0; round = 1; finished = false; winner = -1;
        beginTurn();
    }

    Seat drawer() { return seats.get(drawerIdx); }

    private void beginTurn() {
        step = "choose";
        word = null; strokes.clear(); points = 0; strokeSeq++; hintsGiven = 0; correctCount = 0;
        for (Seat s : seats) { s.guessed = false; s.gained = 0; s.close = null; }
        List<String> pool = new ArrayList<>();
        for (String w : WORDS) if (!usedWords.contains(w)) pool.add(w);
        if (pool.size() < 3) { usedWords.clear(); Collections.addAll(pool, WORDS); }
        Collections.shuffle(pool, rnd);
        choices = new String[]{pool.get(0), pool.get(1), pool.get(2)};
        deadline = System.currentTimeMillis() + 15000;
        sys(drawer().p.name + " sucht sich einen Begriff aus …");
    }

    private void choose(String w) {
        word = w; usedWords.add(w);
        revealed = new boolean[w.length()];
        step = "draw";
        turnStart = System.currentTimeMillis();
        deadline = turnStart + turnSecs * 1000L;
        sys(drawer().p.name + " zeichnet jetzt. Ratet los!");
    }

    private void reveal(String why) {
        step = "reveal";
        // Zeichner bekommt Punkte je richtigem Rater
        Seat d = drawer();
        int dp = correctCount * 25;
        d.score += dp; d.gained = dp;
        sys(why + " Der Begriff war: " + word);
        deadline = System.currentTimeMillis() + 7000;
    }

    private void nextTurn() {
        drawerIdx++;
        if (drawerIdx >= seats.size()) { drawerIdx = 0; round++; }
        if (round > rounds) {
            Seat best = null;
            for (Seat s : seats) if (best == null || s.score > best.score) best = s;
            finished = true; winner = best.p.id; step = "end";
            sys(best.p.name + " gewinnt mit " + best.score + " Punkten!");
            return;
        }
        beginTurn();
    }

    @Override
    public boolean tick(long now) {
        if (finished || deadline == 0) return false;
        if ("draw".equals(step)) {
            // Hinweise: bei 50 % und 75 % der Zeit je einen Buchstaben aufdecken
            long total = turnSecs * 1000L, elapsed = now - turnStart;
            int want = elapsed >= total * 3 / 4 ? 2 : elapsed >= total / 2 ? 1 : 0;
            if (word != null && word.length() >= 4 && hintsGiven < want) { giveHint(); hintsGiven++; return true; }
        }
        if (now < deadline) return false;
        switch (step) {
            case "choose": choose(choices[rnd.nextInt(3)]); return true;
            case "draw": reveal("Die Zeit ist um!"); return true;
            case "reveal": nextTurn(); return true;
            default: return false;
        }
    }

    private void giveHint() {
        List<Integer> hidden = new ArrayList<>();
        for (int i = 0; i < word.length(); i++) if (!revealed[i] && Character.isLetter(word.charAt(i))) hidden.add(i);
        if (hidden.size() <= 2) return;
        revealed[hidden.get(rnd.nextInt(hidden.size()))] = true;
    }

    String hint() {
        if (word == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (!Character.isLetter(c)) b.append(c);
            else b.append(revealed[i] ? c : '_');
        }
        return b.toString();
    }

    // ---------- Aktionen ----------

    @Override
    public void act(Player pl, String a, Map<String, String> q) {
        if (finished) throw new IllegalStateException("Das Spiel ist vorbei.");
        Seat s = byId.get(pl.id);
        if (s == null) throw new IllegalStateException("Du spielst in dieser Runde nicht mit.");
        boolean isDrawer = s == drawer();
        switch (a) {
            case "pick": {
                if (!"choose".equals(step) || !isDrawer) throw new IllegalStateException("Du bist nicht dran.");
                int i = parse(q.get("i"), -1);
                if (i < 0 || i > 2) throw new IllegalStateException("Bitte einen Begriff wählen.");
                choose(choices[i]);
                return;
            }
            case "pts": {
                if (!"draw".equals(step) || !isDrawer) throw new IllegalStateException("Du zeichnest gerade nicht.");
                String pts = q.getOrDefault("p", "");
                if (!pts.matches("[0-9,;]{0,6000}")) throw new IllegalStateException("Ungültige Zeichnung.");
                int n = pts.isEmpty() ? 0 : pts.split(";").length;
                if (points + n > 8000) return; // Grenze erreicht
                if ("1".equals(q.get("n")) || strokes.isEmpty()) {
                    String col = q.getOrDefault("c", "#000000");
                    if (!col.matches("#[0-9a-fA-F]{6}")) col = "#000000";
                    int w = Math.max(1, Math.min(60, parse(q.get("w"), 6)));
                    strokes.add(new StringBuilder(col + "|" + w + "|"));
                    if (strokes.size() > 600) strokes.remove(0);
                }
                StringBuilder sb = strokes.get(strokes.size() - 1);
                if (!pts.isEmpty()) {
                    if (sb.charAt(sb.length() - 1) != '|') sb.append(';');
                    sb.append(pts);
                }
                points += n; strokeSeq++;
                return;
            }
            case "undo": {
                if (!"draw".equals(step) || !isDrawer) throw new IllegalStateException("Du zeichnest gerade nicht.");
                if (!strokes.isEmpty()) strokes.remove(strokes.size() - 1);
                strokeSeq++;
                return;
            }
            case "clear": {
                if (!"draw".equals(step) || !isDrawer) throw new IllegalStateException("Du zeichnest gerade nicht.");
                strokes.clear(); points = 0; strokeSeq++;
                return;
            }
            case "guess": {
                if (!"draw".equals(step)) throw new IllegalStateException("Gerade wird nicht geraten.");
                if (isDrawer) throw new IllegalStateException("Du zeichnest – nicht verraten!");
                if (s.guessed) throw new IllegalStateException("Du hast es schon erraten.");
                String g = q.getOrDefault("text", "").trim();
                if (g.isEmpty() || g.length() > 40) return;
                g = g.replaceAll("[\\p{Cntrl}<>{}|]", "");
                String ng = norm(g), nw = norm(word);
                if (ng.equals(nw)) {
                    s.guessed = true; correctCount++;
                    long left = Math.max(0, deadline - System.currentTimeMillis());
                    int pts = Math.max(20, (int) Math.round(100.0 * left / (turnSecs * 1000.0))) - (correctCount - 1) * 5;
                    pts = Math.max(15, pts);
                    s.score += pts; s.gained = pts; s.close = null;
                    chat("c", s.p.id, s.p.name + " hat es erraten! (+" + pts + ")");
                    boolean all = true;
                    for (Seat x : seats) if (x != drawer() && !x.guessed) all = false;
                    if (all) reveal("Alle haben es erraten!");
                } else {
                    s.close = levenshtein(ng, nw) <= (nw.length() >= 6 ? 2 : 1) && nw.length() >= 4 ? g : null;
                    chat("g", s.p.id, g);
                }
                return;
            }
            default: throw new IllegalStateException("Unbekannte Aktion.");
        }
    }

    @Override
    public void skip() {
        if (finished) return;
        if ("choose".equals(step)) choose(choices[0]);
        else if ("draw".equals(step)) reveal("Übersprungen.");
        else if ("reveal".equals(step)) nextTurn();
    }

    static String norm(String s) {
        s = s.toLowerCase().replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss");
        return s.replaceAll("[^a-z0-9]", "");
    }

    static int levenshtein(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++)
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    private void sys(String t) { chat("s", -1, t); }

    private void chat(String type, int pid, String t) {
        chatSeq++;
        chat.addLast(chatSeq + "|" + type + "|" + pid + "|" + t);
        while (chat.size() > 14) chat.removeFirst();
    }

    // ---------- Ansicht ----------

    @Override
    public void writeView(Json j) {
        long now = System.currentTimeMillis();
        String last = chat.isEmpty() ? "" : chat.peekLast().split("\\|", 4)[3];
        j.kv("phase", finished ? "FINISHED" : "PLAY").kv("st", step).kv("msg", last).kv("cur", drawer().p.id).kv("winner", winner)
         .kv("drawer", drawer().p.id).kv("round", round).kv("rounds", rounds).kv("turnSecs", turnSecs)
         .kv("left", deadline > 0 ? Math.max(0, deadline - now) : 0).kv("hint", hint()).kv("strokeSeq", strokeSeq);
        if ("reveal".equals(step) || finished) j.kv("word", word);
        j.key("strokes").arr(); for (StringBuilder sb : strokes) j.val(sb.toString()); j.end();
        j.key("chat").arr(); for (String c : chat) j.val(c); j.end();
    }

    @Override
    public void writePlayer(Json j, Player p) {
        Seat s = byId.get(p.id);
        if (s == null) return;
        j.kv("score", s.score).kv("guessed", s.guessed).kv("gained", s.gained);
    }

    @Override
    public void writeMe(Json j, Player me) {
        Seat s = byId.get(me.id);
        if (s == null) return;
        boolean isDrawer = s == drawer();
        if (isDrawer && "choose".equals(step)) { j.key("choices").arr(); for (String c : choices) j.val(c); j.end(); }
        if ((isDrawer || s.guessed) && word != null) j.kv("word", word);
        if (s.close != null) j.kv("close", s.close);
    }

    static int parse(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; } }
}
