package de.onur.labyrinth.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Supplier;

/**
 * Lobby der Spielesammlung: Spieler, Host, Spielauswahl, Optionen.
 * Das eigentliche Spiel steckt in einem GameModule. Alle öffentlichen Methoden sind synchronized.
 */
public class Hub {
    public static final int MAX_PLAYERS = 12;
    public static final String[] COLORS = {"#e53935", "#1e88e5", "#43a047", "#fdd835", "#fb8c00", "#8e24aa",
            "#00acc1", "#d81b60", "#6d4c41", "#7cb342", "#5e35b1", "#90a4ae"};
    public static final String[] COLOR_NAMES = {"Rot", "Blau", "Grün", "Gelb", "Orange", "Lila",
            "Türkis", "Pink", "Braun", "Hellgrün", "Violett", "Grau"};

    private final Random rnd;
    private final List<Player> players = new ArrayList<>();
    private final Map<String, Supplier<GameModule>> registry = new LinkedHashMap<>();
    private final Map<String, String> options = new HashMap<>();
    private final Map<String, int[]> limits = new HashMap<>();
    private String gameId = "labyrinth";
    private GameModule game;           // laufendes oder zuletzt gespieltes Spiel
    private boolean inLobby = true;
    private String lobbyMsg = "";
    private int nextId = 1;
    private long version = 0;

    public Hub() { this(new Random()); }

    public Hub(Random rnd) {
        this.rnd = rnd;
        registry.put("labyrinth", LabyrinthGame::new);
        registry.put("estate", EstateGame::new);
        registry.put("poker", PokerGame::new);
        registry.put("werewolf", WerewolfGame::new);
        registry.put("draw", DrawGame::new);
        // Zeitgesteuerte Spiele (Timer) regelmäßig anstoßen
        Thread t = new Thread(() -> {
            while (true) {
                try { Thread.sleep(250); } catch (InterruptedException e) { return; }
                tickNow();
            }
        }, "hub-tick");
        t.setDaemon(true);
        t.start();
    }

    private synchronized void tickNow() {
        if (inLobby || game == null) return;
        try { if (game.tick(System.currentTimeMillis())) changed(); } catch (RuntimeException ignored) { }
    }

    /** Für Tests: Zeit vorspulen. */
    synchronized void tickAt(long now) { if (!inLobby && game != null && game.tick(now)) changed(); }

    // ---------- Lobby ----------

    public synchronized String join(String name, String existingToken, boolean local) {
        if (existingToken != null) {
            Player p = byToken(existingToken);
            if (p != null) {
                if (name != null && !name.isEmpty() && inLobby) p.name = clean(name);
                if (local) p.local = true;
                touch(p); changed(); return p.token;
            }
        }
        if (!inLobby) throw new IllegalStateException("Das Spiel läuft schon. Warte auf die nächste Runde.");
        if (players.size() >= MAX_PLAYERS) throw new IllegalStateException("Es können maximal " + MAX_PLAYERS + " Personen mitspielen.");
        String n = clean(name);
        if (n.isEmpty()) throw new IllegalStateException("Bitte einen Namen eingeben.");
        Player p = new Player();
        p.id = nextId++;
        p.name = n;
        p.token = Long.toHexString(rnd.nextLong()) + Long.toHexString(System.nanoTime());
        p.color = freeColor();
        p.local = local;
        touch(p);
        players.add(p);
        lobbyMsg = n + " ist beigetreten.";
        changed();
        return p.token;
    }

    private int freeColor() {
        for (int col = 0; col < MAX_PLAYERS; col++) {
            boolean used = false;
            for (Player p : players) if (p.color == col) used = true;
            if (!used) return col;
        }
        return 0;
    }

    private static String clean(String s) {
        if (s == null) return "";
        s = s.replaceAll("[\\p{Cntrl}<>{}]", "").trim();
        if (s.length() > 16) s = s.substring(0, 16);
        return s;
    }

    public synchronized void leave(String token) {
        Player p = byToken(token);
        if (p == null || !inLobby) return;
        players.remove(p);
        lobbyMsg = p.name + " hat die Lobby verlassen.";
        changed();
    }

    public synchronized void kick(int playerId) {
        if (!inLobby) return;
        players.removeIf(p -> p.id == playerId);
        changed();
    }

    public synchronized void selectGame(String id) {
        if (!inLobby) return;
        if (!registry.containsKey(id)) throw new IllegalStateException("Unbekanntes Spiel.");
        gameId = id;
        changed();
    }

    public synchronized void setOption(String key, String value) {
        if (!inLobby || key == null) return;
        if (!key.matches("[a-zA-Z0-9_]{1,24}")) return;
        if (value == null || value.length() > 64) return;
        options.put(key, value);
        changed();
    }

    public synchronized void start() {
        if (!inLobby && game != null && !game.finished()) return;
        if (players.isEmpty()) throw new IllegalStateException("Es ist noch niemand beigetreten.");
        GameModule g = registry.get(gameId).get();
        if (players.size() < g.minPlayers()) throw new IllegalStateException("Für dieses Spiel braucht ihr mindestens " + g.minPlayers() + " Spieler.");
        if (players.size() > g.maxPlayers()) throw new IllegalStateException("Dieses Spiel geht mit höchstens " + g.maxPlayers() + " Spielern.");
        players.sort((a, b) -> a.color - b.color);
        g.start(new ArrayList<>(players), new HashMap<>(options), rnd);
        game = g;
        inLobby = false;
        changed();
    }

    public synchronized void toLobby() {
        inLobby = true;
        lobbyMsg = "Neue Runde – wer mitspielen will, scannt den QR-Code.";
        changed();
    }

    public synchronized void skip() {
        if (inLobby || game == null) return;
        game.skip();
        changed();
    }

    /** Spielzug an das laufende Spiel. */
    public synchronized void act(String token, String action, Map<String, String> params) {
        Player p = byToken(token);
        if (p == null) throw new IllegalStateException("Unbekannter Spieler. Bitte neu beitreten.");
        touch(p);
        if (inLobby || game == null) throw new IllegalStateException("Es läuft gerade kein Spiel.");
        try {
            game.act(p, action, params);
        } finally {
            changed(); // auch bei Fehlern: Teiländerungen (z. B. Würfel) anzeigen
        }
    }

    // ---------- Hilfen ----------

    private Player byToken(String token) {
        if (token == null) return null;
        for (Player p : players) if (p.token.equals(token)) return p;
        return null;
    }

    private void touch(Player p) { p.lastSeen = System.currentTimeMillis(); }

    /** Host ist, wer am App-Gerät spielt – gibt es so jemanden nicht, die Person, die zuerst beigetreten ist. */
    public synchronized boolean isHost(String token) {
        if (token == null) return false;
        Player h = host();
        return h != null && h.token.equals(token);
    }

    private Player host() {
        for (Player p : players) if (p.local) return p;
        Player first = null;
        for (Player p : players) if (first == null || p.id < first.id) first = p;
        return first;
    }

    /** Für Tests. */
    GameModule module() { return game; }

    public synchronized boolean hasAnyPlayer() { return !players.isEmpty(); }

    public synchronized boolean hasPlayer(String token) { return byToken(token) != null; }

    public synchronized boolean isIdle() { return inLobby || game == null || game.finished(); }

    private void changed() { version++; notifyAll(); }

    public synchronized void bump() { changed(); }

    public synchronized long version() { return version; }

    public synchronized long awaitChange(long known, long ms) throws InterruptedException {
        long end = System.currentTimeMillis() + ms;
        while (version == known) {
            long left = end - System.currentTimeMillis();
            if (left <= 0) break;
            wait(left);
        }
        return version;
    }

    // ---------- Ansicht ----------

    public synchronized String view(String token, String joinUrl, String appVersion) { return view(token, joinUrl, appVersion, 0, false, false); }

    public synchronized String view(String token, String joinUrl, String appVersion, long webStamp, boolean webUpdated, boolean local) {
        Player me = byToken(token);
        Player h = host();
        Json j = new Json().obj();
        j.kv("v", version).kv("app", appVersion).kv("web", webStamp).kv("webUpd", webUpdated).kv("local", local)
         .kv("hostId", h == null ? -1 : h.id).kv("url", joinUrl).kv("game", gameId);
        j.key("games").arr();
        for (String id : registry.keySet()) j.val(id);
        j.end();
        int[] lim = limits.computeIfAbsent(gameId, k -> { GameModule m = registry.get(k).get(); return new int[]{m.minPlayers(), m.maxPlayers()}; });
        j.kv("minPlayers", lim[0]).kv("maxPlayers", lim[1]).kv("now", System.currentTimeMillis());
        j.key("options").obj();
        for (Map.Entry<String, String> e : options.entrySet()) j.kv(e.getKey(), e.getValue());
        j.end();
        // Kompatibilität mit der Labyrinth-Oberfläche
        j.kv("cardsPerPlayer", LabyrinthGame.parseInt(options.get("cards"), 0));
        boolean showGame = !inLobby && game != null;
        if (showGame) {
            j.kv("playing", game.id());
            game.writeView(j);
        } else {
            j.kv("phase", "LOBBY").kv("msg", lobbyMsg).kv("cur", -1).kv("winner", -1);
        }
        j.key("players").arr();
        for (Player p : players) {
            j.obj().kv("id", p.id).kv("name", p.name).kv("color", COLORS[p.color]).kv("colorName", COLOR_NAMES[p.color]);
            if (showGame) game.writePlayer(j, p);
            j.end();
        }
        j.end();
        if (me != null) {
            j.key("me").obj().kv("id", me.id).kv("host", local || (h != null && h == me));
            if (showGame) game.writeMe(j, me);
            j.end();
        }
        j.end();
        return j.toString();
    }
}
