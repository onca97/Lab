package de.onur.labyrinth.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Texas Hold'em (No Limit) mit Spielchips, 2–10 Spieler.
 * Karten: 0–51, Rang = c % 13 (0 = Zwei … 12 = Ass), Farbe = c / 13.
 */
public class PokerGame implements GameModule {

    static class Seat {
        Player p;
        int chips;
        int[] hole = {-1, -1};
        boolean folded, allIn, out, acted, inHand;
        int bet;        // in dieser Setzrunde
        int committed;  // in dieser Hand insgesamt
        boolean show;   // Karten beim Showdown aufgedeckt
        String handName = null;
    }

    static class Win { int pid, amount; String hand; Win(int p, int a, String h) { pid = p; amount = a; hand = h; } }

    Random rnd = new Random();
    final List<Seat> seats = new ArrayList<>();
    final Map<Integer, Seat> byId = new HashMap<>();
    List<Integer> deck = new ArrayList<>();
    final List<Integer> board = new ArrayList<>();
    int dealer = -1, sbIdx = -1, bbIdx = -1, cur = -1;
    int street = 0; // 0 Preflop, 1 Flop, 2 Turn, 3 River
    String state = "bet"; // bet, result
    int currentBet = 0, lastRaise = 0;
    int smallBlind = 10, bigBlind = 20;
    int handNo = 0, blindUpEvery = 0, handLimit = 0, startChips = 1000;
    long nextHandAt = 0;
    boolean finished = false;
    int winner = -1;
    final List<Win> lastWins = new ArrayList<>();
    final ArrayDeque<String> log = new ArrayDeque<>();
    int logSeq = 0;
    int dealSeq = 0;

    @Override public String id() { return "poker"; }
    @Override public int minPlayers() { return 2; }
    @Override public int maxPlayers() { return 10; }
    @Override public boolean finished() { return finished; }

    @Override
    public void start(List<Player> players, Map<String, String> o, Random rnd) {
        this.rnd = rnd;
        startChips = clamp(parse(o.get("chips"), 1000), 100, 100000);
        blindUpEvery = clamp(parse(o.get("blindup"), 10), 0, 100);
        handLimit = clamp(parse(o.get("hands"), 0), 0, 500);
        bigBlind = Math.max(2, startChips / 50); smallBlind = bigBlind / 2;
        seats.clear(); byId.clear(); log.clear();
        for (Player p : players) { Seat s = new Seat(); s.p = p; s.chips = startChips; seats.add(s); byId.put(p.id, s); }
        dealer = rnd.nextInt(seats.size()) - 1;
        if (dealer < 0) dealer = seats.size() - 1;
        handNo = 0; finished = false; winner = -1;
        startHand();
    }

    private int nextAlive(int from) {
        int n = seats.size();
        for (int i = 1; i <= n; i++) { int k = (from + i) % n; if (!seats.get(k).out) return k; }
        return from;
    }

    private int nextToAct(int from) {
        int n = seats.size();
        for (int i = 1; i <= n; i++) {
            int k = (from + i) % n; Seat s = seats.get(k);
            if (s.inHand && !s.folded && !s.allIn) return k;
        }
        return -1;
    }

    private int aliveCount() { int c = 0; for (Seat s : seats) if (!s.out) c++; return c; }

    void startHand() {
        for (Seat s : seats) if (s.chips <= 0 && !s.out) { s.out = true; log("{p" + s.p.id + "} ist ausgeschieden."); }
        if (aliveCount() <= 1) { endGame(); return; }
        if (handLimit > 0 && handNo >= handLimit) { endGame(); return; }
        handNo++;
        if (blindUpEvery > 0 && handNo > 1 && (handNo - 1) % blindUpEvery == 0) {
            smallBlind *= 2; bigBlind *= 2;
            log("Die Blinds steigen auf {m" + smallBlind + "}/{m" + bigBlind + "}.");
        }
        board.clear(); lastWins.clear();
        deck = new ArrayList<>(); for (int i = 0; i < 52; i++) deck.add(i);
        Collections.shuffle(deck, rnd);
        for (Seat s : seats) {
            s.folded = false; s.allIn = false; s.acted = false; s.bet = 0; s.committed = 0; s.show = false; s.handName = null;
            s.inHand = !s.out;
            s.hole = s.inHand ? new int[]{deck.remove(0), deck.remove(0)} : new int[]{-1, -1};
        }
        dealSeq++;
        dealer = nextAlive(dealer);
        if (aliveCount() == 2) { sbIdx = dealer; bbIdx = nextAlive(dealer); }
        else { sbIdx = nextAlive(dealer); bbIdx = nextAlive(sbIdx); }
        post(seats.get(sbIdx), smallBlind);
        post(seats.get(bbIdx), bigBlind);
        currentBet = bigBlind; lastRaise = bigBlind;
        street = 0; state = "bet";
        log("Hand " + handNo + ": {p" + seats.get(dealer).p.id + "} gibt. Blinds {m" + smallBlind + "}/{m" + bigBlind + "}.");
        cur = nextToAct(bbIdx);
        if (cur < 0 || bettingDone()) advanceStreet();
    }

    private void post(Seat s, int amount) {
        int a = Math.min(amount, s.chips);
        s.chips -= a; s.bet += a; s.committed += a;
        if (s.chips == 0) s.allIn = true;
    }

    // ---------- Aktionen ----------

    @Override
    public void act(Player pl, String a, Map<String, String> q) {
        if (finished) throw new IllegalStateException("Das Spiel ist vorbei.");
        Seat s = byId.get(pl.id);
        if (s == null) throw new IllegalStateException("Du spielst in dieser Runde nicht mit.");
        if ("next".equals(a)) {
            if (!"result".equals(state)) throw new IllegalStateException("Die Hand läuft noch.");
            startHand(); return;
        }
        if (!"bet".equals(state)) throw new IllegalStateException("Gleich geht es mit der nächsten Hand weiter.");
        if (cur < 0 || seats.get(cur) != s) throw new IllegalStateException("Du bist nicht dran.");
        int toCall = currentBet - s.bet;
        switch (a) {
            case "fold":
                s.folded = true;
                log("{p" + s.p.id + "} passt.");
                break;
            case "check":
                if (toCall > 0) throw new IllegalStateException("Du musst mitgehen, erhöhen oder passen.");
                log("{p" + s.p.id + "} schiebt.");
                break;
            case "call": {
                if (toCall <= 0) throw new IllegalStateException("Nichts zu bezahlen – du kannst schieben.");
                int amt = Math.min(toCall, s.chips);
                s.chips -= amt; s.bet += amt; s.committed += amt;
                if (s.chips == 0) s.allIn = true;
                log("{p" + s.p.id + "} geht mit" + (s.allIn ? " (all-in)" : "") + ".");
                break;
            }
            case "raise": raiseTo(s, parse(q.get("to"), 0), false); break;
            case "allin": raiseTo(s, s.bet + s.chips, true); break;
            default: throw new IllegalStateException("Unbekannte Aktion.");
        }
        s.acted = true;
        afterAction();
    }

    private void raiseTo(Seat s, int to, boolean allin) {
        int max = s.bet + s.chips;
        if (to > max) throw new IllegalStateException("So viele Chips hast du nicht.");
        if (to <= currentBet) {
            if (allin) { // All-in, das nur mitgeht
                int amt = s.chips; s.chips = 0; s.bet += amt; s.committed += amt; s.allIn = true;
                log("{p" + s.p.id + "} geht all-in ({m" + s.bet + "}).");
                return;
            }
            throw new IllegalStateException("Eine Erhöhung muss über " + currentBet + " liegen.");
        }
        int raiseBy = to - currentBet;
        if (raiseBy < lastRaise && to < max) throw new IllegalStateException("Mindestens auf " + (currentBet + lastRaise) + " erhöhen.");
        int amt = to - s.bet;
        s.chips -= amt; s.bet = to; s.committed += amt;
        if (s.chips == 0) s.allIn = true;
        if (raiseBy >= lastRaise) lastRaise = raiseBy;
        currentBet = to;
        for (Seat o : seats) if (o != s && o.inHand && !o.folded && !o.allIn) o.acted = false;
        log("{p" + s.p.id + "} erhöht auf {m" + to + "}" + (s.allIn ? " (all-in)" : "") + ".");
    }

    private int notFolded() { int c = 0; for (Seat s : seats) if (s.inHand && !s.folded) c++; return c; }

    /** Setzrunde fertig, wenn alle, die noch setzen können, gehandelt und gleichgezogen haben. */
    private boolean bettingDone() {
        for (Seat s : seats) {
            if (!s.inHand || s.folded || s.allIn) continue;
            if (!s.acted || s.bet != currentBet) return false;
        }
        return true;
    }

    private void afterAction() {
        if (notFolded() == 1) { awardFold(); return; }
        if (bettingDone()) { advanceStreet(); return; }
        cur = nextToAct(cur);
    }

    private void advanceStreet() {
        for (Seat s : seats) { s.bet = 0; s.acted = false; }
        currentBet = 0; lastRaise = bigBlind;
        int canAct = 0;
        for (Seat s : seats) if (s.inHand && !s.folded && !s.allIn) canAct++;
        while (true) {
            if (street == 3) { showdown(); return; }
            street++;
            if (street == 1) { board.add(deck.remove(0)); board.add(deck.remove(0)); board.add(deck.remove(0)); }
            else board.add(deck.remove(0));
            if (canAct >= 2) break; // es wird wieder gesetzt
            // sonst: Karten bis zum Showdown aufdecken
        }
        String[] names = {"", "Flop", "Turn", "River"};
        log(names[street] + ".");
        cur = nextToAct(dealer);
    }

    private void awardFold() {
        Seat w = null;
        int pot = 0;
        for (Seat s : seats) { pot += s.committed; if (s.inHand && !s.folded) w = s; }
        w.chips += pot;
        for (Seat s : seats) { s.committed = 0; s.bet = 0; }
        lastWins.clear(); lastWins.add(new Win(w.p.id, pot, null));
        log("{p" + w.p.id + "} gewinnt {m" + pot + "}.");
        endHand();
    }

    final Map<Integer, Integer> debugCommitted = new HashMap<>(); // für Tests

    private void showdown() {
        street = 4;
        debugCommitted.clear();
        for (Seat x : seats) debugCommitted.put(x.p.id, x.committed);
        List<Seat> contenders = new ArrayList<>();
        for (Seat s : seats) if (s.inHand && !s.folded) { s.show = true; contenders.add(s); }
        Map<Seat, Long> score = new HashMap<>();
        for (Seat s : contenders) {
            int[] seven = new int[7];
            seven[0] = s.hole[0]; seven[1] = s.hole[1];
            for (int i = 0; i < 5; i++) seven[2 + i] = board.get(i);
            long sc = best7(seven);
            score.put(s, sc);
            s.handName = handName(sc);
        }
        // Side-Pots: jeweils bis zum kleinsten Einsatz der noch beteiligten Spieler
        lastWins.clear();
        Map<Integer, Integer> won = new java.util.LinkedHashMap<>();
        Map<Integer, String> wonHand = new HashMap<>();
        Seat overallBest = null;
        for (Seat c : contenders) if (overallBest == null || score.get(c) > score.get(overallBest)) overallBest = c;
        while (true) {
            List<Seat> eligible = new ArrayList<>();
            int m = Integer.MAX_VALUE;
            for (Seat c : contenders) if (c.committed > 0) { eligible.add(c); m = Math.min(m, c.committed); }
            if (eligible.isEmpty()) {
                int rest = 0; for (Seat x : seats) { rest += x.committed; x.committed = 0; }
                if (rest > 0) { overallBest.chips += rest; won.merge(overallBest.p.id, rest, Integer::sum); wonHand.put(overallBest.p.id, overallBest.handName); }
                break;
            }
            int pot = 0;
            for (Seat x : seats) { int take = Math.min(x.committed, m); pot += take; x.committed -= take; }
            long best = -1;
            for (Seat c : eligible) best = Math.max(best, score.get(c));
            List<Seat> winners = new ArrayList<>();
            for (Seat c : eligible) if (score.get(c) == best) winners.add(c);
            winners.sort((x, y) -> distFromDealer(x) - distFromDealer(y));
            int share = pot / winners.size(), odd = pot % winners.size();
            for (int i = 0; i < winners.size(); i++) {
                Seat w = winners.get(i);
                int amt = share + (i < odd ? 1 : 0);
                w.chips += amt;
                won.merge(w.p.id, amt, Integer::sum);
                wonHand.put(w.p.id, w.handName);
            }
        }
        for (Map.Entry<Integer, Integer> e : won.entrySet()) {
            lastWins.add(new Win(e.getKey(), e.getValue(), wonHand.get(e.getKey())));
            log("{p" + e.getKey() + "} gewinnt {m" + e.getValue() + "} mit " + wonHand.get(e.getKey()) + ".");
        }
        endHand();
    }

    private int distFromDealer(Seat s) {
        int i = seats.indexOf(s), n = seats.size();
        return (i - dealer - 1 + n) % n;
    }

    private void endHand() {
        state = "result";
        cur = -1;
        nextHandAt = System.currentTimeMillis() + 8000;
        int alive = 0; for (Seat s : seats) if (s.chips > 0) alive++;
        if (alive <= 1) nextHandAt = System.currentTimeMillis() + 5000;
    }

    private void endGame() {
        Seat best = null;
        for (Seat s : seats) if (best == null || s.chips > best.chips) best = s;
        finished = true; winner = best.p.id; state = "result"; cur = -1;
        log("{p" + winner + "} gewinnt das Spiel!");
    }

    @Override
    public boolean tick(long now) {
        if (!finished && "result".equals(state) && now >= nextHandAt) { startHand(); return true; }
        return false;
    }

    @Override
    public void skip() {
        if (finished || !"bet".equals(state) || cur < 0) return;
        Seat s = seats.get(cur);
        if (currentBet - s.bet > 0) { s.folded = true; log("{p" + s.p.id + "} wird übersprungen (passt)."); }
        else log("{p" + s.p.id + "} wird übersprungen (schiebt).");
        s.acted = true;
        afterAction();
    }

    // ---------- Handbewertung ----------

    static final String[] CAT = {"Höchste Karte", "Ein Paar", "Zwei Paare", "Drilling", "Straße", "Flush", "Full House", "Vierling", "Straight Flush"};

    static String handName(long sc) {
        int cat = (int) (sc >> 20);
        if (cat == 8 && ((sc >> 16) & 15) == 12) return "Royal Flush";
        return CAT[cat];
    }

    static long best7(int[] c) {
        long best = -1;
        int[] five = new int[5];
        for (int a = 0; a < 7; a++) for (int b = a + 1; b < 7; b++) {
            int k = 0;
            for (int i = 0; i < 7; i++) if (i != a && i != b) five[k++] = c[i];
            best = Math.max(best, eval5(five));
        }
        return best;
    }

    /** Bewertung von 5 Karten: Kategorie << 20 | 5 Ränge à 4 Bit (absteigend wichtig). */
    static long eval5(int[] c) {
        int[] cnt = new int[13];
        boolean flush = true;
        for (int i = 0; i < 5; i++) { cnt[c[i] % 13]++; if (c[i] / 13 != c[0] / 13) flush = false; }
        // Ränge nach (Anzahl, Rang) sortiert
        List<int[]> groups = new ArrayList<>();
        for (int r = 12; r >= 0; r--) if (cnt[r] > 0) groups.add(new int[]{cnt[r], r});
        groups.sort((x, y) -> x[0] != y[0] ? y[0] - x[0] : y[1] - x[1]);
        boolean straight = false; int high = -1;
        if (groups.size() == 5) {
            int top = groups.get(0)[1], low = groups.get(4)[1];
            if (top - low == 4) { straight = true; high = top; }
            else if (top == 12 && groups.get(1)[1] == 3) { straight = true; high = 3; } // A-2-3-4-5
        }
        int cat;
        if (straight && flush) cat = 8;
        else if (groups.get(0)[0] == 4) cat = 7;
        else if (groups.get(0)[0] == 3 && groups.get(1)[0] == 2) cat = 6;
        else if (flush) cat = 5;
        else if (straight) cat = 4;
        else if (groups.get(0)[0] == 3) cat = 3;
        else if (groups.get(0)[0] == 2 && groups.get(1)[0] == 2) cat = 2;
        else if (groups.get(0)[0] == 2) cat = 1;
        else cat = 0;
        long v = (long) cat << 20;
        if (straight) return v | ((long) high << 16);
        int shift = 16;
        for (int[] g : groups) { v |= (long) g[1] << shift; shift -= 4; }
        return v;
    }

    // ---------- Ansicht ----------

    private void log(String s) { logSeq++; log.addLast(logSeq + "|" + s); while (log.size() > 12) log.removeFirst(); }

    int pot() { int p = 0; for (Seat s : seats) p += s.committed; return p; }

    @Override
    public void writeView(Json j) {
        String last = log.isEmpty() ? "" : log.peekLast().substring(log.peekLast().indexOf('|') + 1);
        j.kv("phase", finished ? "FINISHED" : "PLAY").kv("st", state).kv("msg", last)
         .kv("cur", cur >= 0 ? seats.get(cur).p.id : -1).kv("winner", winner)
         .kv("dealer", dealer >= 0 ? seats.get(dealer).p.id : -1)
         .kv("sb", sbIdx >= 0 ? seats.get(sbIdx).p.id : -1).kv("bb", bbIdx >= 0 ? seats.get(bbIdx).p.id : -1)
         .kv("pot", pot()).kv("currentBet", currentBet).kv("minRaiseTo", currentBet + lastRaise)
         .kv("street", street).kv("hand", handNo).kv("handLimit", handLimit).kv("smallBlind", smallBlind).kv("bigBlind", bigBlind)
         .kv("dealSeq", dealSeq).kv("nextIn", "result".equals(state) ? Math.max(0, nextHandAt - System.currentTimeMillis()) : 0);
        j.key("board").arr(); for (int c : board) j.val(c); j.end();
        j.key("wins").arr();
        for (Win w : lastWins) j.obj().kv("pid", w.pid).kv("amount", w.amount).kv("hand", w.hand).end();
        j.end();
        j.key("log").arr(); for (String l : log) j.val(l); j.end();
    }

    @Override
    public void writePlayer(Json j, Player p) {
        Seat s = byId.get(p.id);
        if (s == null) return;
        j.kv("chips", s.chips).kv("bet", s.bet).kv("folded", s.folded).kv("allIn", s.allIn).kv("out", s.out).kv("inHand", s.inHand);
        if (s.show) {
            j.key("cards").arr().val(s.hole[0]).val(s.hole[1]).end();
            j.kv("handName", s.handName);
        }
    }

    @Override
    public void writeMe(Json j, Player me) {
        Seat s = byId.get(me.id);
        if (s == null) return;
        if (s.inHand) j.key("hole").arr().val(s.hole[0]).val(s.hole[1]).end();
        j.kv("toCall", Math.max(0, Math.min(currentBet - s.bet, s.chips))).kv("maxRaiseTo", s.bet + s.chips);
        if (s.inHand && board.size() >= 3) {
            int[] cards = new int[2 + board.size()];
            cards[0] = s.hole[0]; cards[1] = s.hole[1];
            for (int i = 0; i < board.size(); i++) cards[2 + i] = board.get(i);
            j.kv("myHand", handName(bestOf(cards)));
        }
    }

    /** Beste Hand aus 5–7 Karten (für die Anzeige am Handy). */
    static long bestOf(int[] c) {
        if (c.length == 7) return best7(c);
        if (c.length == 5) return eval5(c);
        long best = -1; int[] five = new int[5];
        for (int skip = 0; skip < c.length; skip++) {
            int k = 0;
            for (int i = 0; i < c.length; i++) if (i != skip) five[k++] = c[i];
            best = Math.max(best, eval5(five));
        }
        return best;
    }

    static int parse(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; } }
    static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
