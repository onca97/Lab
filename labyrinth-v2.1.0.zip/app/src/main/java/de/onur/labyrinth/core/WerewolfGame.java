package de.onur.labyrinth.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Werwolf (5–12 Spieler). Der Beamer ist der Erzähler.
 * Rollen: wolf, villager, seer, witch, hunter, cupid.
 */
public class WerewolfGame implements GameModule {

    static final Map<String, String> ROLE_NAME = new LinkedHashMap<>();
    static {
        ROLE_NAME.put("wolf", "Werwolf"); ROLE_NAME.put("villager", "Dorfbewohner"); ROLE_NAME.put("seer", "Seherin");
        ROLE_NAME.put("witch", "Hexe"); ROLE_NAME.put("hunter", "Jäger"); ROLE_NAME.put("cupid", "Amor");
    }

    static class Seat {
        Player p;
        String role;
        boolean alive = true, ready = false;
        int vote = -2;          // Tagesabstimmung: -2 noch nicht, -1 Enthaltung, sonst Spieler-ID
        int wolfVote = -1;
        int lover = -1;
        final List<String> seen = new ArrayList<>(); // Erkenntnisse der Seherin
    }

    Random rnd = new Random();
    final List<Seat> seats = new ArrayList<>();
    final Map<Integer, Seat> byId = new HashMap<>();
    String step = "intro";     // intro, cupid, wolves, seer, seerResult, witch, dawn, hunter, day, verdict
    int night = 0;
    int victim = -1;           // Opfer der Werwölfe in dieser Nacht
    int poisoned = -1;
    boolean healed = false, healUsed = false, poisonUsed = false;
    boolean hasWitch, hasSeer, hasHunter, hasCupid;
    long deadline = 0;         // für Schein-Phasen und automatische Übergänge
    String after = null;       // was nach Jäger-Schuss / Verkündung folgt
    int hunterId = -1;
    int seerTarget = -1;
    List<Integer> lastDead = new ArrayList<>();
    String say = "";
    int saySeq = 0;
    boolean finished = false;
    String winnerSide = null;
    int winner = -1;
    final Map<Integer, Integer> lastVotes = new LinkedHashMap<>();
    final ArrayDeque<String> log = new ArrayDeque<>();
    int logSeq = 0;
    int cupidPick1 = -1;

    @Override public String id() { return "werewolf"; }
    @Override public int minPlayers() { return 5; }
    @Override public int maxPlayers() { return 12; }
    @Override public boolean finished() { return finished; }

    @Override
    public void start(List<Player> players, Map<String, String> o, Random rnd) {
        this.rnd = rnd;
        int n = players.size();
        int wolves = parse(o.get("wolves"), 0);
        if (wolves <= 0) wolves = n <= 6 ? 1 : n <= 9 ? 2 : 3;
        wolves = Math.max(1, Math.min(wolves, (n - 1) / 2));
        hasSeer = !"0".equals(o.get("seer"));
        hasWitch = tri(o.get("witch"), n >= 6);
        hasHunter = tri(o.get("hunter"), n >= 7);
        hasCupid = tri(o.get("cupid"), n >= 8);
        List<String> roles = new ArrayList<>();
        for (int i = 0; i < wolves; i++) roles.add("wolf");
        if (hasSeer && roles.size() < n) roles.add("seer"); else hasSeer = false;
        if (hasWitch && roles.size() < n) roles.add("witch"); else hasWitch = false;
        if (hasHunter && roles.size() < n) roles.add("hunter"); else hasHunter = false;
        if (hasCupid && roles.size() < n) roles.add("cupid"); else hasCupid = false;
        while (roles.size() < n) roles.add("villager");
        Collections.shuffle(roles, rnd);
        seats.clear(); byId.clear(); log.clear(); lastVotes.clear();
        for (int i = 0; i < n; i++) {
            Seat s = new Seat(); s.p = players.get(i); s.role = roles.get(i);
            seats.add(s); byId.put(s.p.id, s);
        }
        night = 0; healUsed = poisonUsed = false; finished = false; winnerSide = null; winner = -1; lastDead.clear();
        step = "intro";
        narrate("Willkommen im Dorf Nebelgrund. Schaut heimlich auf euer Handy – dort steht eure Rolle. Tippt auf „Bereit“, wenn ihr sie gesehen habt.");
    }

    // ---------- Ablauf ----------

    private void narrate(String s) { say = s; saySeq++; log(s); }

    private Seat holder(String role) { for (Seat s : seats) if (s.role.equals(role)) return s; return null; }
    private boolean holderAlive(String role) { Seat h = holder(role); return h != null && h.alive; }

    private List<Seat> aliveWolves() { List<Seat> l = new ArrayList<>(); for (Seat s : seats) if (s.alive && s.role.equals("wolf")) l.add(s); return l; }

    private void startNight() {
        night++;
        victim = -1; poisoned = -1; healed = false; seerTarget = -1;
        for (Seat s : seats) s.wolfVote = -1;
        if (night == 1 && hasCupid) { enter("cupid"); return; }
        enter("wolves");
    }

    /** Nachtschritt betreten. Ist der Rolleninhaber tot, läuft eine Schein-Phase, damit niemand etwas merkt. */
    private void enter(String st) {
        step = st;
        deadline = 0;
        String prefix = ("cupid".equals(st) || ("wolves".equals(st) && !(night == 1 && hasCupid))) ? "Die Nacht bricht herein. Alle schließen die Augen. " : "";
        switch (st) {
            case "cupid":
                cupidPick1 = -1;
                narrate(prefix + "Amor erwacht und wählt zwei Menschen, die sich unsterblich ineinander verlieben.");
                if (!holderAlive("cupid")) fake();
                break;
            case "wolves":
                narrate(prefix + (night == 1 && hasCupid ? "Amor schläft wieder ein. " : "") + "Die Werwölfe erwachen und einigen sich auf ein Opfer.");
                break;
            case "seer":
                narrate("Die Werwölfe schlafen wieder ein. Die Seherin erwacht und darf die wahre Gestalt eines Menschen sehen.");
                if (!holderAlive("seer")) fake();
                break;
            case "witch":
                narrate((hasSeer ? "Die Seherin schläft wieder ein. " : "Die Werwölfe schlafen wieder ein. ") + "Die Hexe erwacht. Sie sieht das Opfer und darf ihre Tränke benutzen.");
                if (!holderAlive("witch") || (healUsed && poisonUsed)) fake();
                break;
            default:
        }
    }

    private void fake() { deadline = System.currentTimeMillis() + 6000 + rnd.nextInt(4000); }

    private void nextNightStep() {
        if ("cupid".equals(step)) { enter("wolves"); return; }
        if ("wolves".equals(step)) { if (hasSeer) { enter("seer"); return; } if (hasWitch) { enter("witch"); return; } dawn(); return; }
        if ("seer".equals(step) || "seerResult".equals(step)) { if (hasWitch) { enter("witch"); return; } dawn(); return; }
        if ("witch".equals(step)) { dawn(); }
    }

    private void dawn() {
        step = "dawn";
        List<Integer> dead = new ArrayList<>();
        if (victim >= 0 && !healed) dead.add(victim);
        if (poisoned >= 0 && !dead.contains(poisoned)) dead.add(poisoned);
        lastDead = killAll(dead);
        String text = "Der Morgen graut. Alle öffnen die Augen. ";
        if (lastDead.isEmpty()) text += "Wie durch ein Wunder ist in dieser Nacht niemand gestorben.";
        else text += describeDead(lastDead);
        narrate(text);
        after = "day";
        deadline = System.currentTimeMillis() + 9000;
        if (pendingHunter()) return;
    }

    /** Tötet Spieler inkl. Liebeskummer; liefert alle Toten. */
    private List<Integer> killAll(List<Integer> ids) {
        List<Integer> dead = new ArrayList<>();
        ArrayDeque<Integer> q = new ArrayDeque<>(ids);
        while (!q.isEmpty()) {
            Seat s = byId.get(q.poll());
            if (s == null || !s.alive) continue;
            s.alive = false; dead.add(s.p.id);
            if (s.role.equals("hunter")) hunterId = s.p.id;
            if (s.lover >= 0 && byId.get(s.lover).alive) q.add(s.lover);
        }
        return dead;
    }

    private String describeDead(List<Integer> ids) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) {
            Seat s = byId.get(ids.get(i));
            b.append(s.p.name).append(" ist tot");
            if (i > 0 && s.lover >= 0 && ids.contains(s.lover)) b.append(" – vor Liebeskummer");
            b.append(". ").append(s.p.name).append(" war ").append(roleWithArticle(s.role)).append(". ");
        }
        return b.toString().trim();
    }

    static String roleWithArticle(String r) {
        switch (r) {
            case "wolf": return "ein Werwolf";
            case "seer": return "die Seherin";
            case "witch": return "die Hexe";
            case "hunter": return "der Jäger";
            case "cupid": return "Amor";
            default: return "ein Dorfbewohner";
        }
    }

    /** Ist gerade ein Jäger gestorben, darf er schießen, bevor es weitergeht. */
    private boolean pendingHunter() {
        boolean anyAlive = false; for (Seat x : seats) if (x.alive) anyAlive = true;
        if (hunterId >= 0 && !anyAlive) hunterId = -1; // niemand mehr da, auf den er schießen könnte
        if (hunterId >= 0) {
            Seat h = byId.get(hunterId);
            step = "hunter"; deadline = 0;
            narrate(say + " " + h.p.name + " war der Jäger und reißt mit dem letzten Schuss jemanden mit in den Tod.");
            return true;
        }
        return false;
    }

    private boolean checkWin() {
        int wolves = 0, others = 0, alive = 0;
        List<Seat> al = new ArrayList<>();
        for (Seat s : seats) if (s.alive) { alive++; al.add(s); if (s.role.equals("wolf")) wolves++; else others++; }
        String side = null;
        if (alive == 2 && al.get(0).lover == al.get(1).p.id) side = "lovers";
        else if (wolves == 0) side = "village";
        else if (wolves >= others) side = "wolves";
        else if (alive == 0) side = "none";
        if (side == null) return false;
        finished = true; winnerSide = side; step = "end";
        for (Seat s : seats) if (s.alive && (side.equals("wolves") == s.role.equals("wolf") || side.equals("lovers"))) { winner = s.p.id; break; }
        String t = side.equals("village") ? "Alle Werwölfe sind besiegt – das Dorf hat gewonnen!"
                : side.equals("wolves") ? "Die Werwölfe haben das Dorf übernommen – die Werwölfe gewinnen!"
                : side.equals("lovers") ? "Nur die Verliebten sind übrig – die Liebe hat gewonnen!" : "Niemand hat überlebt.";
        narrate(t);
        return true;
    }

    private void startDay() {
        if (checkWin()) return;
        step = "day"; deadline = 0;
        for (Seat s : seats) s.vote = -2;
        lastVotes.clear();
        narrate("Diskutiert jetzt: Wer könnte ein Werwolf sein? Stimmt dann auf euren Handys ab.");
    }

    private void verdict() {
        Map<Integer, Integer> count = new HashMap<>();
        lastVotes.clear();
        for (Seat s : seats) if (s.alive) { lastVotes.put(s.p.id, s.vote); if (s.vote >= 0) count.merge(s.vote, 1, Integer::sum); }
        int best = 0; List<Integer> top = new ArrayList<>();
        for (Map.Entry<Integer, Integer> e : count.entrySet()) {
            if (e.getValue() > best) { best = e.getValue(); top.clear(); }
            if (e.getValue() == best) top.add(e.getKey());
        }
        step = "verdict";
        deadline = System.currentTimeMillis() + 9000;
        after = "night";
        if (top.size() != 1) {
            lastDead = new ArrayList<>();
            narrate(top.isEmpty() ? "Niemand wurde beschuldigt. Heute stirbt niemand." : "Unentschieden – das Dorf kann sich nicht einigen. Heute stirbt niemand.");
            return;
        }
        lastDead = killAll(List.of(top.get(0)));
        narrate("Das Dorf hat entschieden. " + describeDead(lastDead));
        pendingHunter();
    }

    private void continueAfter() {
        if (checkWin()) return;
        if ("day".equals(after)) startDay();
        else startNight();
    }

    @Override
    public boolean tick(long now) {
        if (finished || deadline == 0 || now < deadline) return false;
        deadline = 0;
        switch (step) {
            case "cupid": case "seer": case "witch": nextNightStep(); return true;
            case "wolves": resolveWolves(true); return true;
            case "dawn": case "verdict": continueAfter(); return true;
            default: return false;
        }
    }

    // ---------- Aktionen ----------

    @Override
    public void act(Player pl, String a, Map<String, String> q) {
        if (finished) throw new IllegalStateException("Das Spiel ist vorbei.");
        Seat s = byId.get(pl.id);
        if (s == null) throw new IllegalStateException("Du spielst in dieser Runde nicht mit.");
        int t = parse(q.get("t"), -1);
        Seat target = byId.get(t);
        switch (a) {
            case "ready": {
                if (!"intro".equals(step)) throw new IllegalStateException("Das Spiel läuft schon.");
                s.ready = true;
                boolean all = true; for (Seat x : seats) if (!x.ready) all = false;
                if (all) startNight();
                return;
            }
            case "cupid": {
                need(s, "cupid", "cupid");
                if (target == null) throw new IllegalStateException("Bitte eine Person wählen.");
                if (cupidPick1 < 0) { cupidPick1 = t; return; }
                if (cupidPick1 == t) throw new IllegalStateException("Bitte eine zweite, andere Person wählen.");
                byId.get(cupidPick1).lover = t; target.lover = cupidPick1;
                log("Amor hat gewählt.");
                cupidPick1 = -1;
                nextNightStep();
                return;
            }
            case "wolf": {
                if (!"wolves".equals(step) || !s.alive || !s.role.equals("wolf")) throw new IllegalStateException("Das ist nicht deine Aufgabe.");
                if (target == null || !target.alive || target.role.equals("wolf")) throw new IllegalStateException("Dieses Opfer geht nicht.");
                s.wolfVote = t;
                resolveWolves(false);
                return;
            }
            case "seer": {
                need(s, "seer", "seer");
                if (target == null || target == s || !target.alive) throw new IllegalStateException("Bitte eine andere lebende Person wählen.");
                seerTarget = t;
                s.seen.add(target.p.id + "|" + (target.role.equals("wolf") ? "1" : "0"));
                step = "seerResult";
                return;
            }
            case "seerok": {
                if (!"seerResult".equals(step) || !s.role.equals("seer")) throw new IllegalStateException("Das ist nicht deine Aufgabe.");
                nextNightStep();
                return;
            }
            case "heal": {
                need(s, "witch", "witch");
                if (healUsed) throw new IllegalStateException("Der Heiltrank ist verbraucht.");
                if (victim < 0) throw new IllegalStateException("Heute gibt es kein Opfer.");
                healUsed = true; healed = true;
                return;
            }
            case "poison": {
                need(s, "witch", "witch");
                if (poisonUsed) throw new IllegalStateException("Der Gifttrank ist verbraucht.");
                if (target == null || !target.alive) throw new IllegalStateException("Bitte eine lebende Person wählen.");
                poisonUsed = true; poisoned = t;
                return;
            }
            case "witchdone": {
                need(s, "witch", "witch");
                nextNightStep();
                return;
            }
            case "shoot": {
                if (!"hunter".equals(step) || s.p.id != hunterId) throw new IllegalStateException("Das ist nicht deine Aufgabe.");
                if (target == null || !target.alive) throw new IllegalStateException("Bitte eine lebende Person wählen.");
                hunterId = -1;
                List<Integer> d = killAll(List.of(t));
                lastDead.addAll(d);
                narrate("Der Jäger schießt: " + describeDead(d));
                step = "dawn".equals(after) ? "dawn" : ("day".equals(after) ? "dawn" : "verdict");
                if (pendingHunter()) return; // getroffener zweiter Jäger gibt es nicht, aber sicher ist sicher
                deadline = System.currentTimeMillis() + 7000;
                return;
            }
            case "vote": {
                if (!"day".equals(step)) throw new IllegalStateException("Gerade wird nicht abgestimmt.");
                if (!s.alive) throw new IllegalStateException("Tote stimmen nicht mit.");
                if (t != -1 && (target == null || !target.alive)) throw new IllegalStateException("Bitte eine lebende Person wählen.");
                s.vote = t;
                boolean all = true; for (Seat x : seats) if (x.alive && x.vote == -2) all = false;
                if (all) verdict();
                return;
            }
            default: throw new IllegalStateException("Unbekannte Aktion.");
        }
    }

    private void need(Seat s, String st, String role) {
        if (!st.equals(step) || !s.alive || !s.role.equals(role) || deadline != 0) throw new IllegalStateException("Das ist nicht deine Aufgabe.");
    }

    private void resolveWolves(boolean force) {
        List<Seat> w = aliveWolves();
        Map<Integer, Integer> c = new HashMap<>();
        boolean all = true;
        for (Seat x : w) { if (x.wolfVote < 0) all = false; else c.merge(x.wolfVote, 1, Integer::sum); }
        if (!force && !all) return;
        if (!force && c.size() > 1) { deadline = System.currentTimeMillis() + 20000; return; } // uneinig: 20 s zum Einigen
        if (c.isEmpty()) { // niemand hat gewählt (nur bei Überspringen): zufälliges Opfer
            List<Seat> pool = new ArrayList<>(); for (Seat x : seats) if (x.alive && !x.role.equals("wolf")) pool.add(x);
            victim = pool.get(rnd.nextInt(pool.size())).p.id;
        } else {
            int best = 0; List<Integer> top = new ArrayList<>();
            for (Map.Entry<Integer, Integer> e : c.entrySet()) { if (e.getValue() > best) { best = e.getValue(); top.clear(); } if (e.getValue() == best) top.add(e.getKey()); }
            victim = top.get(rnd.nextInt(top.size()));
        }
        deadline = 0;
        nextNightStep();
    }

    @Override
    public void skip() {
        if (finished) return;
        switch (step) {
            case "intro": startNight(); break;
            case "cupid": { // zufällig verkuppeln
                List<Seat> al = new ArrayList<>(seats); Collections.shuffle(al, rnd);
                al.get(0).lover = al.get(1).p.id; al.get(1).lover = al.get(0).p.id; nextNightStep(); break;
            }
            case "wolves": resolveWolves(true); break;
            case "seer": case "seerResult": case "witch": nextNightStep(); break;
            case "hunter": hunterId = -1; deadline = System.currentTimeMillis() + 100; step = "day".equals(after) ? "dawn" : "verdict"; break;
            case "day": verdict(); break;
            case "dawn": case "verdict": continueAfter(); break;
            default:
        }
    }

    // ---------- Ansicht ----------

    private void log(String s) { logSeq++; log.addLast(logSeq + "|" + s); while (log.size() > 10) log.removeFirst(); }

    @Override
    public void writeView(Json j) {
        int voted = 0, alive = 0;
        for (Seat s : seats) if (s.alive) { alive++; if (s.vote != -2) voted++; }
        int ready = 0; for (Seat s : seats) if (s.ready) ready++;
        j.kv("phase", finished ? "FINISHED" : "PLAY").kv("st", step).kv("msg", say).kv("say", say).kv("saySeq", saySeq)
         .kv("cur", -1).kv("winner", winner).kv("side", winnerSide).kv("night", night)
         .kv("voted", voted).kv("alive", alive).kv("ready", ready)
         .kv("fake", deadline != 0 && ("cupid".equals(step) || "seer".equals(step) || "witch".equals(step)));
        j.key("dead").arr(); for (int id : lastDead) j.val(id); j.end();
        if ("verdict".equals(step) || finished) {
            j.key("votes").obj(); for (Map.Entry<Integer, Integer> e : lastVotes.entrySet()) j.kv(String.valueOf(e.getKey()), e.getValue()); j.end();
        }
        j.key("roles").obj();
        for (Map.Entry<String, String> e : ROLE_NAME.entrySet()) {
            int n = 0; for (Seat s : seats) if (s.role.equals(e.getKey())) n++;
            if (n > 0) j.kv(e.getKey(), n);
        }
        j.end();
    }

    @Override
    public void writePlayer(Json j, Player p) {
        Seat s = byId.get(p.id);
        if (s == null) return;
        j.kv("alive", s.alive).kv("ready", s.ready);
        if (!s.alive || finished) j.kv("role", s.role); // Rollen der Toten (und am Ende aller) sind öffentlich
        if ("day".equals(step) && s.alive) j.kv("hasVoted", s.vote != -2);
    }

    @Override
    public void writeMe(Json j, Player me) {
        Seat s = byId.get(me.id);
        if (s == null) return;
        j.kv("role", s.role).kv("alive", s.alive).kv("vote", s.vote);
        if (s.lover >= 0) j.kv("lover", s.lover);
        if (s.role.equals("wolf")) {
            j.key("pack").arr(); for (Seat x : seats) if (x.role.equals("wolf")) j.val(x.p.id); j.end();
            if ("wolves".equals(step)) {
                j.key("wolfVotes").obj(); for (Seat x : aliveWolves()) j.kv(String.valueOf(x.p.id), x.wolfVote); j.end();
            }
        }
        if (s.role.equals("seer")) {
            j.key("seen").arr(); for (String x : s.seen) j.val(x); j.end();
        }
        if (s.role.equals("witch") && "witch".equals(step) && deadline == 0) {
            j.kv("victim", victim).kv("healUsed", healUsed).kv("poisonUsed", poisonUsed).kv("healed", healed).kv("poisoned", poisoned);
        }
        if (s.role.equals("cupid") && "cupid".equals(step)) j.kv("cupidPick", cupidPick1);
        if ("hunter".equals(step) && s.p.id == hunterId) j.kv("shoot", true);
    }

    /** "1" = an, "0" = aus, sonst automatisch nach Spielerzahl. */
    static boolean tri(String v, boolean auto) { return "1".equals(v) || (!"0".equals(v) && auto); }

    static int parse(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; } }
}
