/* Texas Hold'em – Beamer und Handy */
var Poker = (function () {
  var RANKS = "23456789TJQKA", SUITS = ["♠", "♥", "♦", "♣"];
  function $(id) { return document.getElementById(id); }
  function chips(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ".") + " 🪙"; }

  function card(c, cls) {
    if (c == null || c < 0) return '<span class="pcard2 back ' + (cls || "") + '"></span>';
    var r = RANKS[c % 13], s = Math.floor(c / 13);
    return '<span class="pcard2 ' + (s === 1 || s === 2 ? "red " : "") + (cls || "") + '"><span class="r">' + (r === "T" ? "10" : r) +
      '</span><span class="s">' + SUITS[s] + "</span></span>";
  }
  function placeholder() { return '<span class="pcard2 ph"></span>'; }

  function fmtLog(s, t) {
    return esc(t).replace(/\{p(\d+)\}/g, function (_, id) { var p = playerById(s, +id); return p ? '<b style="color:' + p.color + '">' + esc(p.name) + "</b>" : "?"; })
      .replace(/\{m(\d+)\}/g, function (_, n) { return chips(+n); });
  }

  // ---------- Beamer ----------
  var lastBoardLen = 0, lastDeal = -1;
  function renderBoard(s, fresh) {
    var t = $("pTable");
    var n = s.players.length;
    var newDeal = s.dealSeq !== lastDeal;
    var h = '<div class="pfelt"><div class="board">';
    for (var i = 0; i < 5; i++) h += s.board[i] != null ? card(s.board[i], fresh && (i >= lastBoardLen || newDeal) ? "deal" : "") : placeholder();
    h += '</div><div class="pot">Pot: ' + chips(s.pot) + '</div><div class="info">Hand ' + s.hand + (s.handLimit ? " von " + s.handLimit : "") +
      " · Blinds " + chips(s.smallBlind) + " / " + chips(s.bigBlind) + "</div>";
    if (s.st === "result" && s.wins && s.wins.length) {
      h += '<div class="res">' + s.wins.map(function (w) { var p = playerById(s, w.pid); return (p ? esc(p.name) : "?") + " gewinnt " + chips(w.amount) + (w.hand ? " mit " + esc(w.hand) : ""); }).join("<br>") + "</div>";
    } else if (s.phase === "PLAY") {
      var cp = playerById(s, s.cur);
      h += '<div class="info" style="font-size:2.6vh;color:#fff">' + (cp ? esc(cp.name) + " ist dran" + (s.currentBet ? " · zu bezahlen bis " + chips(s.currentBet) : "") : "") + "</div>";
    }
    h += "</div>";
    var winners = {}; (s.wins || []).forEach(function (w) { winners[w.pid] = true; });
    s.players.forEach(function (p, i) {
      var ang = Math.PI / 2 + (i / n) * Math.PI * 2; // unten beginnen, im Uhrzeigersinn
      var x = 50 + Math.cos(ang) * 42, y = 50 + Math.sin(ang) * 40;
      var cls = "pseat" + (p.id === s.cur ? " cur" : "") + (p.folded ? " fold" : "") + (p.out ? " out" : "") + (s.st === "result" && winners[p.id] ? " winner" : "");
      var cards = "";
      if (p.cards) cards = card(p.cards[0], "win") + card(p.cards[1], "win");
      else if (p.inHand && !p.folded) cards = card(-1, fresh && newDeal ? "deal" : "") + card(-1, fresh && newDeal ? "deal" : "");
      var tags = (p.id === s.dealer ? '<span class="tag d">D</span>' : "") + (p.id === s.sb ? '<span class="tag sb">S</span>' : "") + (p.id === s.bb ? '<span class="tag bb">B</span>' : "");
      var betTop = y < 50 ? "auto" : "-3.4vh", betBottom = y < 50 ? "-3.4vh" : "auto";
      h += '<div class="' + cls + '" style="left:' + x + "%;top:" + y + '%"><div class="box"><div class="nm"><span class="sw" style="background:' + p.color + '"></span>' +
        esc(p.name) + tags + '</div><div class="ch">' + (p.out ? "ausgeschieden" : chips(p.chips)) + (p.allIn ? ' <span class="badge2">ALL-IN</span>' : "") + "</div>" +
        '<div class="cards">' + cards + "</div>" + (p.handName ? '<div class="hn">' + esc(p.handName) + "</div>" : "") + "</div>" +
        (p.bet > 0 ? '<div class="betc" style="top:' + betTop + ";bottom:" + betBottom + '">' + chips(p.bet) + "</div>" : "") + "</div>";
    });
    h += '<div class="ptitle">♠ Texas Hold\'em</div><div class="plog">' + (s.log || []).slice(-8).map(function (l) { return "<div>" + fmtLog(s, l.slice(l.indexOf("|") + 1)) + "</div>"; }).join("") + "</div>" +
      '<div class="pbtns"><button class="ghost" id="pSkip">Zug überspringen</button><button class="ghost" id="pEnd">Zur Lobby</button></div>';
    t.innerHTML = h;
    $("pSkip").onclick = function () { boardAct("skip"); };
    $("pEnd").onclick = function () { if (confirm("Spiel abbrechen und zurück zur Lobby?")) boardAct("lobby"); };
    lastBoardLen = s.board.length; lastDeal = s.dealSeq;
    return 0;
  }

  // ---------- Handy ----------
  var hide = false, raiseVal = 0, lastCur = null;
  function renderPhone(s, fresh) {
    var me = s.me, p = playerById(s, me.id);
    var sl0 = $("pkSlider");
    if (sl0 && document.activeElement === sl0 && s.cur === me.id) return; // nicht neu zeichnen, während der Regler bewegt wird
    var myTurn = s.cur === me.id && s.st === "bet";
    if (fresh && myTurn && lastCur !== me.id && navigator.vibrate) { try { navigator.vibrate([120, 60, 120]); } catch (e) {} }
    lastCur = s.cur;
    var h = '<div class="eptop"><span class="sw" style="background:' + p.color + '"></span><span class="nm">' + esc(p.name) + '</span><span class="mo">' + chips(p.chips) +
      "</span>" + (me.host ? '<button class="ghost menuBtn" id="pkMenu">⋯</button>' : "") + "</div>";
    if (p.out) return $("pokerScr").innerHTML = h + '<div class="ecard2">Du bist ausgeschieden. 👀</div>';
    h += '<div class="ph-cards" id="pkCards">' + (me.hole ? (hide ? card(-1) + card(-1) : card(me.hole[0]) + card(me.hole[1])) : "") + "</div>";
    if (me.hole) h += '<div class="hint" style="text-align:center;color:var(--muted);font-size:13px">Antippen zum ' + (hide ? "Aufdecken" : "Verdecken") + (me.myHand && !hide ? " · <b style='color:#ffe082'>" + esc(me.myHand) + "</b>" : "") + "</div>";
    h += '<div class="ph-board">'; for (var i = 0; i < 5; i++) h += s.board[i] != null ? card(s.board[i]) : placeholder(); h += "</div>";
    h += '<div class="ph-info"><span>Pot: <b>' + chips(s.pot) + "</b></span><span>Dein Einsatz: <b>" + chips(p.bet) + "</b></span></div>";
    if (s.st === "result") {
      h += '<div class="ecard2">' + (s.wins || []).map(function (w) { var wp = playerById(s, w.pid); return (wp ? esc(wp.name) : "?") + " gewinnt " + chips(w.amount) + (w.hand ? " mit " + esc(w.hand) : ""); }).join("<br>") +
        '<div class="hint">Nächste Hand gleich …</div><button class="ghost" id="pkNext">Nächste Hand jetzt</button></div>';
    } else if (p.folded) {
      h += '<div class="ecard2">Du hast gepasst.</div>';
    } else if (p.allIn) {
      h += '<div class="ecard2">Du bist all-in. Daumen drücken! 🤞</div>';
    } else if (myTurn) {
      var toCall = me.toCall, minTo = Math.min(s.minRaiseTo, me.maxRaiseTo), maxTo = me.maxRaiseTo;
      if (raiseVal < minTo || raiseVal > maxTo) raiseVal = minTo;
      h += '<div class="ecard2"><b>Du bist dran!</b>' + (toCall ? '<div class="hint">Zum Mitgehen: ' + chips(toCall) + "</div>" : "") +
        '<div class="ph-row"><button class="ghost" id="pkFold">Passen</button>' +
        (toCall ? '<button id="pkCall">Mitgehen ' + chips(toCall) + "</button>" : '<button id="pkCheck">Schieben</button>') + "</div>";
      if (maxTo > s.currentBet) {
        h += (maxTo > minTo ? '<input type="range" class="ph-slider" id="pkSlider" min="' + minTo + '" max="' + maxTo + '" step="' + Math.max(1, s.bigBlind / 2) + '" value="' + raiseVal + '">' : "") +
          '<div class="ph-row"><button class="ghost" id="pkRaise">Erhöhen auf <span id="pkRV">' + chips(raiseVal) + "</span></button>" +
          '<button class="ghost" id="pkAll">All-in ' + chips(p.chips) + "</button></div>";
      }
      h += "</div>";
    } else {
      var cp = playerById(s, s.cur);
      h += '<div class="ecard2">' + (cp ? esc(cp.name) + " ist dran …" : "") + "</div>";
    }
    h += '<div class="dpchat">' + (s.log || []).slice(-4).reverse().map(function (l) { return "<div>" + fmtLog(s, l.slice(l.indexOf("|") + 1)) + "</div>"; }).join("") + "</div>";
    $("pokerScr").innerHTML = h;
    var A = window.estateAct, on = function (id, f) { var x = $(id); if (x) x.onclick = f; };
    on("pkCards", function () { hide = !hide; renderPhone(S, false); });
    on("pkFold", function () { A("fold"); }); on("pkCheck", function () { A("check"); }); on("pkCall", function () { A("call"); });
    on("pkRaise", function () { A("raise", { to: raiseVal }); }); on("pkAll", function () { if (confirm("Wirklich all-in?")) A("allin"); });
    on("pkNext", function () { A("next"); }); on("pkMenu", function () { openSheet(); });
    var sl = $("pkSlider");
    if (sl) sl.oninput = function () { raiseVal = +sl.value; $("pkRV").textContent = chips(raiseVal); };
  }

  return { renderBoard: renderBoard, renderPhone: renderPhone, card: card };
})();
