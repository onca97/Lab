/* Werwolf – Beamer (Erzähler mit Stimme) und Handy */
var Werewolf = (function () {
  function $(id) { return document.getElementById(id); }
  var ROLES = {
    wolf: { n: "Werwolf", ic: "🐺", d: "Nachts wählst du mit den anderen Werwölfen ein Opfer. Tagsüber tust du unschuldig." },
    villager: { n: "Dorfbewohner", ic: "🧑‍🌾", d: "Du hast keine besonderen Fähigkeiten. Finde mit den anderen die Werwölfe!" },
    seer: { n: "Seherin", ic: "🔮", d: "Jede Nacht darfst du bei einer Person sehen, ob sie ein Werwolf ist." },
    witch: { n: "Hexe", ic: "🧪", d: "Du hast einen Heiltrank (rettet das Opfer der Nacht) und einen Gifttrank (tötet jemanden). Jeder Trank nur einmal." },
    hunter: { n: "Jäger", ic: "🏹", d: "Wenn du stirbst, nimmst du mit deinem letzten Schuss jemanden mit in den Tod." },
    cupid: { n: "Amor", ic: "💘", d: "In der ersten Nacht verliebst du zwei Personen. Stirbt eine, stirbt die andere vor Kummer." }
  };
  var NIGHT = { cupid: 1, wolves: 1, seer: 1, seerResult: 1, witch: 1 };

  // ---------- Sprachausgabe ----------
  var voiceOn = true;
  try { voiceOn = localStorage.getItem("wwVoice") !== "0"; } catch (e) {}
  function speak(text) {
    if (!voiceOn || !text) return;
    try {
      if (window.Android && window.Android.speak) { if (window.Android.speak(text)) return; }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        var u = new SpeechSynthesisUtterance(text); u.lang = "de-DE"; u.rate = 0.95;
        window.speechSynthesis.speak(u);
      }
    } catch (e) {}
  }
  function stopSpeak() { try { if (window.Android && window.Android.stopSpeak) window.Android.stopSpeak(); if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) {} }

  // ---------- Beamer ----------
  var lastSay = -1, prevAlive = {};
  function renderBoard(s, fresh) {
    var w = $("werewolf");
    var night = NIGHT[s.st] || s.st === "intro";
    w.classList.toggle("night", !!night || s.st === "hunter");
    w.classList.toggle("day", !night && s.st !== "hunter");
    var sky = s.phase === "FINISHED" ? (s.side === "wolves" ? "🐺" : s.side === "lovers" ? "💞" : "🏆") : night ? "🌙" : s.st === "hunter" ? "🏹" : s.st === "verdict" ? "⚖️" : "☀️";
    var h = '<div class="wstars">' + (night ? stars() : "") + '</div><div class="wsky">' + sky + "</div>" +
      '<div class="wsay' + (s.saySeq !== lastSay ? " new" : "") + '">' + esc(s.say) + "</div>";
    if (s.st === "intro") h += '<div class="winfo">' + s.ready + " von " + s.players.length + " sind bereit · Rollen: " + roleSummary(s) + "</div>";
    if (s.st === "day") h += '<div class="winfo">' + s.voted + " von " + s.alive + " haben abgestimmt</div>";
    if ((s.st === "verdict" || s.phase === "FINISHED") && s.votes) {
      var lines = [];
      Object.keys(s.votes).forEach(function (k) {
        var from = playerById(s, +k), to = s.votes[k] >= 0 ? playerById(s, s.votes[k]) : null;
        if (from) lines.push(esc(from.name) + " → " + (to ? esc(to.name) : "Enthaltung"));
      });
      if (lines.length && s.st === "verdict") h += '<div class="wvotes">' + lines.join(" · ") + "</div>";
    }
    h += '<div class="wgrid">';
    s.players.forEach(function (p) {
      var died = prevAlive[p.id] === true && !p.alive;
      h += '<div class="wp' + (p.alive ? "" : " dead") + (p.hasVoted ? " voted" : "") + (died ? " justdied" : "") + '"><div class="nm"><span class="sw" style="background:' + p.color + '"></span>' +
        esc(p.name) + '</div><div class="rl">' + (p.role ? ROLES[p.role].ic + " " + ROLES[p.role].n : p.ready && s.st === "intro" ? "✔ bereit" : "") + "</div></div>";
    });
    h += '</div><div class="wbtns"><button class="ghost" id="wVoice">🔊 Stimme: ' + (voiceOn ? "an" : "aus") + '</button><button class="ghost" id="wSkip">Weiter / überspringen</button><button class="ghost" id="wEnd">Zur Lobby</button></div>';
    w.innerHTML = h;
    $("wVoice").onclick = function () { voiceOn = !voiceOn; try { localStorage.setItem("wwVoice", voiceOn ? "1" : "0"); } catch (e) {} if (!voiceOn) stopSpeak(); else speak(s.say); renderBoard(S, false); };
    $("wSkip").onclick = function () { boardAct("skip"); };
    $("wEnd").onclick = function () { if (confirm("Spiel abbrechen und zurück zur Lobby?")) boardAct("lobby"); };
    if (fresh && s.saySeq !== lastSay) speak(s.say);
    lastSay = s.saySeq;
    s.players.forEach(function (p) { prevAlive[p.id] = p.alive; });
    return 0;
  }
  var starHtml = null;
  function stars() {
    if (starHtml) return starHtml;
    var h = ""; for (var i = 0; i < 60; i++) h += '<i style="left:' + (Math.random() * 100) + "%;top:" + (Math.random() * 60) + "%;animation-delay:" + (Math.random() * 3) + 's"></i>';
    return starHtml = h;
  }
  function roleSummary(s) {
    return Object.keys(s.roles || {}).map(function (r) { return s.roles[r] + "× " + ROLES[r].ic + " " + ROLES[r].n; }).join(", ");
  }

  // ---------- Handy ----------
  var hideRole = true, sel = null, lastStep = null;
  function list(s, filter, action, label, selected) {
    var h = '<div class="wlist">';
    s.players.forEach(function (p) {
      if (!filter(p)) return;
      h += '<button data-t="' + p.id + '" data-a="' + action + '"' + (selected === p.id ? ' class="sel"' : "") + '><span class="sw" style="background:' + p.color + '"></span>' + esc(p.name) +
        (label ? "<small>" + label(p) + "</small>" : "") + "</button>";
    });
    return h + "</div>";
  }

  function renderPhone(s, fresh) {
    var me = s.me, p = playerById(s, me.id), R = ROLES[me.role];
    if (s.st !== lastStep) { if (lastStep !== null) hideRole = true; lastStep = s.st; } // Rolle nach jedem Phasenwechsel wieder verdecken
    var h = '<div class="eptop"><span class="sw" style="background:' + p.color + '"></span><span class="nm">' + esc(p.name) + "</span>" +
      (me.host ? '<button class="ghost menuBtn" id="wwMenu">⋯</button>' : "") + "</div>";
    var roleCard = '<div class="wrole' + (hideRole ? " hidden" : "") + '" id="wwRole"><div class="ic">' + R.ic + '</div><div class="rn">' + R.n + "</div>" +
      '<div class="ds">' + (hideRole ? "Antippen zum Anzeigen – niemand darf mitsehen!" : R.d) + "</div>" +
      (!hideRole && me.lover >= 0 ? '<div class="ds" style="color:#f48fb1;margin-top:6px">💘 Du bist verliebt in ' + esc((playerById(s, me.lover) || {}).name) + "</div>" : "") +
      (!hideRole && me.pack && me.pack.length > 1 ? '<div class="ds" style="margin-top:6px">🐺 Dein Rudel: ' + me.pack.map(function (id) { return esc(playerById(s, id).name); }).join(", ") + "</div>" : "") +
      (!hideRole && me.seen && me.seen.length ? '<div class="ds" style="margin-top:6px">🔮 Gesehen: ' + me.seen.map(function (x) { var a = x.split("|"); return esc(playerById(s, +a[0]).name) + (a[1] === "1" ? " 🐺" : " ✔"); }).join(", ") + "</div>" : "") + "</div>";
    var body = "";
    var acting = false;
    if (s.st === "intro") {
      body = roleCard + (p.ready ? '<div class="ecard2">Warte auf die anderen … (' + s.ready + "/" + s.players.length + ")</div>" : '<button id="wwReady" class="bigbtn" style="width:100%;font-size:20px;padding:15px">Ich habe meine Rolle gesehen – Bereit</button>');
    } else if (!me.alive && !me.shoot) {
      body = '<div class="wnight"><div class="moon">💀</div>Du bist tot.<br><small>Bitte nicht mehr mitreden – du darfst aber zuschauen.</small></div>' + roleCard;
    } else if (me.shoot) {
      acting = true;
      body = '<div class="ecard2"><b>🏹 Dein letzter Schuss!</b><div class="hint">Wen nimmst du mit in den Tod?</div>' + list(s, function (x) { return x.alive; }, "shoot") + "</div>";
    } else if (NIGHT[s.st]) {
      if (s.st === "cupid" && me.role === "cupid" && !s.fake) {
        acting = true;
        body = '<div class="ecard2"><b>💘 Wähle zwei Verliebte</b><div class="hint">' + (me.cupidPick >= 0 ? "Jetzt die zweite Person …" : "Erste Person (du darfst dich auch selbst wählen)") + "</div>" +
          list(s, function (x) { return true; }, "cupid", null, me.cupidPick) + "</div>";
      } else if (s.st === "wolves" && me.role === "wolf") {
        acting = true;
        var wv = me.wolfVotes || {};
        body = '<div class="ecard2"><b>🐺 Wählt euer Opfer</b><div class="hint">Ihr müsst euch einig werden.</div>' +
          list(s, function (x) { return x.alive && me.pack.indexOf(x.id) < 0; }, "wolf", function (x) {
            return Object.keys(wv).filter(function (k) { return wv[k] === x.id; }).map(function (k) { return esc(playerById(s, +k).name); }).join(", ");
          }, wv[me.id]) + "</div>";
      } else if (s.st === "seer" && me.role === "seer" && !s.fake) {
        acting = true;
        body = '<div class="ecard2"><b>🔮 Wessen Gestalt willst du sehen?</b>' + list(s, function (x) { return x.alive && x.id !== me.id; }, "seer") + "</div>";
      } else if (s.st === "seerResult" && me.role === "seer") {
        acting = true;
        var last = me.seen[me.seen.length - 1].split("|"), who = playerById(s, +last[0]);
        body = '<div class="ecard2"><div style="font-size:60px">' + (last[1] === "1" ? "🐺" : "😇") + '</div><b style="font-size:22px">' + esc(who.name) + (last[1] === "1" ? " ist ein Werwolf!" : " ist kein Werwolf.") +
          '</b><button id="wwSeerOk">Verstanden – weiterschlafen</button></div>';
      } else if (s.st === "witch" && me.role === "witch" && !s.fake && me.victim !== undefined) {
        acting = true;
        var v = me.victim >= 0 ? playerById(s, me.victim) : null;
        body = '<div class="ecard2"><b>🧪 Du bist die Hexe</b><div style="margin:8px 0">' + (v ? "Opfer der Werwölfe: <b>" + esc(v.name) + "</b>" : "Heute gibt es kein Opfer.") + "</div>" +
          (v && !me.healUsed ? '<button id="wwHeal">💚 Heiltrank: ' + esc(v.name) + " retten</button>" : me.healed ? '<div class="hint">💚 Gerettet!</div>' : "") +
          (!me.poisonUsed ? '<div class="hint" style="margin-top:10px">☠️ Gifttrank auf jemanden:</div>' + list(s, function (x) { return x.alive && x.id !== me.id; }, "poison") : me.poisoned >= 0 ? '<div class="hint">☠️ Gift benutzt.</div>' : "") +
          '<button class="ghost" id="wwWitchDone">Fertig – weiterschlafen</button></div>';
      }
      if (!acting) body = '<div class="wnight"><div class="moon">🌙</div>Nacht ' + s.night + " – Augen zu!<br><small>Leg das Handy weg, bis der Erzähler euch weckt.</small></div>";
    } else if (s.st === "day") {
      body = '<div class="ecard2"><b>☀️ Wer ist ein Werwolf?</b><div class="hint">' + (me.vote !== -2 ? "Deine Stimme: " + (me.vote >= 0 ? esc(playerById(s, me.vote).name) : "Enthaltung") + " – du kannst sie noch ändern." : "Tippe auf die Person, die du verdächtigst.") +
        " (" + s.voted + "/" + s.alive + ")</div>" + list(s, function (x) { return x.alive && x.id !== me.id; }, "vote", null, me.vote) +
        '<button class="ghost" id="wwAbstain">Enthaltung</button></div>' + roleCard;
    } else {
      body = '<div class="ecard2">' + esc(s.say) + "</div>" + roleCard;
    }
    $("werewolfScr").innerHTML = h + body;
    var A = window.estateAct, on = function (id, f) { var x = $(id); if (x) x.onclick = f; };
    on("wwRole", function () { hideRole = !hideRole; renderPhone(S, false); });
    on("wwReady", function () { A("ready"); });
    on("wwSeerOk", function () { A("seerok"); });
    on("wwHeal", function () { A("heal"); });
    on("wwWitchDone", function () { A("witchdone"); });
    on("wwAbstain", function () { A("vote", { t: -1 }); });
    on("wwMenu", function () { openSheet(); });
    document.querySelectorAll("#werewolfScr [data-a]").forEach(function (b) {
      b.onclick = function () {
        var a = b.dataset.a, t = b.dataset.t;
        if (a === "poison" && !confirm("Gifttrank wirklich auf " + b.textContent.trim() + "?")) return;
        if (a === "shoot" && !confirm("Wirklich auf " + b.textContent.trim() + " schießen?")) return;
        A(a, { t: t });
      };
    });
    if (fresh && acting && navigator.vibrate) { try { navigator.vibrate(200); } catch (e) {} }
  }

  function sideText(s) {
    return s.side === "wolves" ? "Die Werwölfe gewinnen! 🐺" : s.side === "lovers" ? "Die Verliebten gewinnen! 💞" : s.side === "village" ? "Das Dorf gewinnt! 🏡" : "Niemand gewinnt.";
  }

  return { renderBoard: renderBoard, renderPhone: renderPhone, sideText: sideText, ROLES: ROLES, speak: speak };
})();
