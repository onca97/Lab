/* Zeichnen & Raten – Beamer und Handy */
var Draw = (function () {
  function $(id) { return document.getElementById(id); }
  var COLORS = ["#111111", "#e53935", "#fb8c00", "#fdd835", "#43a047", "#1e88e5", "#8e24aa", "#6d4c41", "#ffffff"];
  var SIZES = [4, 10, 22];

  /** Striche aus dem Server-Format auf ein Canvas malen. */
  function paint(cv, strokes) {
    var ctx = cv.getContext("2d"), W = cv.width;
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, W, cv.height);
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    (strokes || []).forEach(function (st) {
      var parts = st.split("|"); if (parts.length < 3) return;
      var pts = parts[2] ? parts[2].split(";") : [];
      ctx.strokeStyle = parts[0]; ctx.fillStyle = parts[0];
      ctx.lineWidth = (+parts[1]) * W / 500;
      if (pts.length === 1) { var q = pts[0].split(","); ctx.beginPath(); ctx.arc(q[0] * W / 1000, q[1] * W / 1000, ctx.lineWidth / 2, 0, 7); ctx.fill(); return; }
      ctx.beginPath();
      pts.forEach(function (pt, i) { var q = pt.split(","); var x = q[0] * W / 1000, y = q[1] * W / 1000; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
      ctx.stroke();
    });
  }

  function chatHtml(s, n) {
    return (s.chat || []).slice(-n).map(function (c) {
      var a = c.split("|"), t = a[1], p = playerById(s, +a[2]), txt = a.slice(3).join("|");
      if (t === "s") return '<div class="s">' + esc(txt) + "</div>";
      if (t === "c") return '<div class="c">✔ ' + esc(txt) + "</div>";
      return "<div><b style='color:" + (p ? p.color : "#fff") + "'>" + (p ? esc(p.name) : "?") + ":</b> " + esc(txt) + "</div>";
    }).join("");
  }

  var endsAt = 0, timerIv = null;
  function startTimer(s, elId) {
    endsAt = Date.now() + (s.left || 0);
    clearInterval(timerIv);
    var tick = function () {
      var el = $(elId); if (!el) return;
      var sec = Math.max(0, Math.ceil((endsAt - Date.now()) / 1000));
      el.textContent = s.st === "draw" ? sec : "";
      el.classList.toggle("low", s.st === "draw" && sec <= 10);
    };
    tick(); timerIv = setInterval(tick, 250);
  }

  // ---------- Beamer ----------
  var lastStrokeSeq = -1;
  function renderBoard(s, fresh) {
    var d = $("draw");
    if (!$("dCanvas")) {
      var size = Math.floor(Math.min(innerHeight * 0.92, innerWidth * 0.5));
      d.innerHTML = '<div class="dside" id="dPlayers"></div><canvas class="dcanvas" id="dCanvas" width="' + size + '" height="' + size + '"></canvas>' +
        '<div class="dside"><div class="dtimer" id="dTimer"></div><div id="dTop"></div><div class="dchat" id="dChat"></div>' +
        '<div class="row" style="display:flex;gap:1vh"><button class="ghost" id="dSkip" style="flex:1;font-size:1.8vh">Überspringen</button><button class="ghost" id="dEnd" style="flex:1;font-size:1.8vh">Zur Lobby</button></div></div>';
      $("dSkip").onclick = function () { boardAct("skip"); };
      $("dEnd").onclick = function () { if (confirm("Spiel abbrechen und zurück zur Lobby?")) boardAct("lobby"); };
      lastStrokeSeq = -1;
    }
    var drawer = playerById(s, s.drawer);
    var ps = s.players.slice().sort(function (a, b) { return b.score - a.score; });
    $("dPlayers").innerHTML = '<div style="font-size:2.2vh;color:var(--muted);text-align:center">Runde ' + s.round + " von " + s.rounds + "</div>" + ps.map(function (p) {
      return '<div class="dplayer' + (p.id === s.drawer ? " drawer" : "") + (p.guessed ? " ok" : "") + '"><span class="sw" style="background:' + p.color + '"></span>' +
        (p.id === s.drawer ? "✏️ " : p.guessed ? "✔ " : "") + esc(p.name) + (p.gained && (s.st === "reveal" || p.guessed) ? '<span class="gn">+' + p.gained + "</span>" : "") +
        '<span class="sc">' + p.score + "</span></div>";
    }).join("");
    var top = "";
    if (s.st === "choose") top = '<div class="dbig">✏️ <b>' + esc(drawer.name) + "</b> wählt einen Begriff …</div>";
    else if (s.st === "draw") top = '<div class="dhint">' + esc(s.hint) + '</div><div style="text-align:center;color:var(--muted);font-size:2vh">' + s.hint.replace(/[^_]/g, "").length + " Buchstaben fehlen</div>";
    else if (s.st === "reveal" || s.phase === "FINISHED") top = '<div style="text-align:center;color:var(--muted);font-size:2.2vh">Das Wort war</div><div class="dword">' + esc(s.word || "") + "</div>";
    $("dTop").innerHTML = top;
    $("dChat").innerHTML = chatHtml(s, 12);
    if (s.strokeSeq !== lastStrokeSeq) { paint($("dCanvas"), s.strokes); lastStrokeSeq = s.strokeSeq; }
    startTimer(s, "dTimer");
    return 0;
  }

  // ---------- Handy ----------
  var color = COLORS[0], size = SIZES[1], drawing = false, buf = [], newStroke = false, sending = false, localDirty = false;
  var phoneSeq = -1, lastDrawerTurn = null, chatInput = "";

  function flush() {
    if (sending || (!buf.length && !newStroke)) return;
    var pts = buf.splice(0, 60);
    var data = { a: "pts", token: token, p: pts.join(";") };
    if (newStroke) { data.n = "1"; data.c = color; data.w = size; newStroke = false; }
    sending = true;
    post("/api/act", data).then(function () { sending = false; flush(); }).catch(function () { sending = false; setTimeout(flush, 300); });
  }
  setInterval(flush, 90);

  function setupCanvas(cv) {
    var ctx = cv.getContext("2d"), last = null;
    function pos(e) { var r = cv.getBoundingClientRect(); var t = e.touches ? e.touches[0] : e; return [Math.round((t.clientX - r.left) / r.width * 1000), Math.round((t.clientY - r.top) / r.height * 1000)]; }
    function down(e) {
      e.preventDefault(); drawing = true; newStroke = true; last = pos(e); buf.push(last.join(","));
      ctx.fillStyle = color; ctx.beginPath(); ctx.arc(last[0] * cv.width / 1000, last[1] * cv.width / 1000, size * cv.width / 1000, 0, 7); ctx.fill();
    }
    function move(e) {
      if (!drawing) return; e.preventDefault();
      var p = pos(e); if (Math.abs(p[0] - last[0]) + Math.abs(p[1] - last[1]) < 6) return;
      ctx.strokeStyle = color; ctx.lineWidth = size * cv.width / 500; ctx.lineCap = "round"; ctx.lineJoin = "round";
      ctx.beginPath(); ctx.moveTo(last[0] * cv.width / 1000, last[1] * cv.width / 1000); ctx.lineTo(p[0] * cv.width / 1000, p[1] * cv.width / 1000); ctx.stroke();
      last = p; buf.push(p.join(","));
    }
    function up() { drawing = false; flush(); }
    cv.addEventListener("touchstart", down, { passive: false }); cv.addEventListener("touchmove", move, { passive: false }); cv.addEventListener("touchend", up);
    cv.addEventListener("mousedown", down); cv.addEventListener("mousemove", move); addEventListener("mouseup", up);
  }

  function renderPhone(s, fresh) {
    var me = s.me, p = playerById(s, me.id), isDrawer = s.drawer === me.id;
    var scr = $("drawScr");
    // Während man zeichnet oder tippt, die Seite nicht neu aufbauen
    if (drawing) return;
    var inp = $("dgIn");
    var hadFocus = inp && document.activeElement === inp;
    if (inp) chatInput = inp.value;
    var turnKey = s.drawer + "|" + s.round + "|" + s.st;
    if (isDrawer && s.st === "draw" && $("dpCanvas") && lastDrawerTurn === turnKey) {
      // nur Zeit/Chat aktualisieren; Zeichenfläche bleibt lokal
      $("dpChat").innerHTML = chatHtml(s, 3);
      if (localDirty) { paint($("dpCanvas"), s.strokes); localDirty = false; }
      return;
    }
    if (!isDrawer && s.st === "draw" && $("dpCanvas") && lastDrawerTurn === turnKey && !me.close && !p.guessed && document.activeElement === inp) {
      if (s.strokeSeq !== phoneSeq) { paint($("dpCanvas"), s.strokes); phoneSeq = s.strokeSeq; }
      $("dpHint").textContent = s.hint; $("dpChat").innerHTML = chatHtml(s, 3);
      return;
    }
    lastDrawerTurn = turnKey;
    var h = '<div class="eptop"><span class="sw" style="background:' + p.color + '"></span><span class="nm">' + esc(p.name) + '</span><span class="mo">' + p.score +
      ' P</span>' + (me.host ? '<button class="ghost menuBtn" id="dMenu">⋯</button>' : "") + "</div>";
    if (s.st === "choose") {
      if (isDrawer) {
        h += '<div class="ecard2"><b>Du bist dran! Wähle einen Begriff:</b>' + (me.choices || []).map(function (c, i) { return '<button data-pick="' + i + '">' + esc(c) + "</button>"; }).join("") + "</div>";
        if (fresh && navigator.vibrate) { try { navigator.vibrate([120, 60, 120]); } catch (e) {} }
      } else h += '<div class="ecard2">✏️ ' + esc(playerById(s, s.drawer).name) + " wählt einen Begriff …</div>";
    } else if (s.st === "draw") {
      if (isDrawer) {
        h += '<div class="ecard2" style="padding:8px">Zeichne: <b style="font-size:22px;color:var(--accent)">' + esc(me.word) + '</b> <span id="dpTimer" style="float:right;font-weight:900"></span></div>' +
          '<canvas class="dph-canvas" id="dpCanvas" width="700" height="700"></canvas><div class="dtools">' +
          COLORS.map(function (c) { return '<button class="col' + (c === color ? " sel" : "") + '" data-col="' + c + '" style="background:' + c + '"></button>'; }).join("") + "</div>" +
          '<div class="dtools">' + SIZES.map(function (z, i) { return '<button class="sz' + (z === size ? " sel" : "") + '" data-sz="' + z + '">' + ["fein", "mittel", "dick"][i] + "</button>"; }).join("") +
          '<button class="sz" id="dpUndo">↶ Zurück</button><button class="sz" id="dpClear">🗑 Alles löschen</button></div><div class="dpchat" id="dpChat"></div>';
      } else {
        h += '<div class="dphint" id="dpHint">' + esc(p.guessed ? me.word : s.hint) + '</div><div style="text-align:center"><span id="dpTimer" style="font-weight:900"></span></div>' +
          '<canvas class="dph-canvas" id="dpCanvas" width="700" height="700"></canvas>';
        if (p.guessed) h += '<div class="ecard2" style="background:rgba(76,175,80,.25)">✔ Richtig! +' + p.gained + " Punkte</div>";
        else h += '<div class="dguess"><input id="dgIn" placeholder="Dein Tipp …" autocomplete="off" autocapitalize="sentences" maxlength="40"><button id="dgSend">Raten</button></div>' +
          (me.close ? '<div class="hint" style="color:#ffb300;text-align:center;margin-top:6px">🔥 „' + esc(me.close) + '“ ist knapp dran!</div>' : "");
        h += '<div class="dpchat" id="dpChat"></div>';
      }
    } else {
      h += '<div class="ecard2"><div class="hint">Das Wort war</div><div style="font-size:30px;font-weight:900;color:var(--accent)">' + esc(s.word || "") + "</div>" +
        (p.gained ? "<div>+" + p.gained + " Punkte für dich</div>" : "") + "</div>";
    }
    scr.innerHTML = h;
    var cv = $("dpCanvas");
    if (cv) { paint(cv, s.strokes); phoneSeq = s.strokeSeq; if (isDrawer) setupCanvas(cv); }
    var ch = $("dpChat"); if (ch) ch.innerHTML = chatHtml(s, 3);
    startTimer(s, "dpTimer");
    var A = window.estateAct, on = function (id, f) { var x = $(id); if (x) x.onclick = f; };
    document.querySelectorAll("[data-pick]").forEach(function (b) { b.onclick = function () { A("pick", { i: b.dataset.pick }); }; });
    document.querySelectorAll("[data-col]").forEach(function (b) { b.onclick = function () { color = b.dataset.col; document.querySelectorAll("[data-col]").forEach(function (x) { x.classList.toggle("sel", x === b); }); }; });
    document.querySelectorAll("[data-sz]").forEach(function (b) { b.onclick = function () { size = +b.dataset.sz; document.querySelectorAll("[data-sz]").forEach(function (x) { x.classList.toggle("sel", x === b); }); }; });
    on("dpUndo", function () { buf = []; newStroke = false; A("undo").then(function () { localDirty = true; }); });
    on("dpClear", function () { if (confirm("Alles löschen?")) { buf = []; newStroke = false; A("clear").then(function () { localDirty = true; paint($("dpCanvas"), []); }); } });
    on("dMenu", function () { openSheet(); });
    var gi = $("dgIn");
    if (gi) {
      gi.value = chatInput;
      var send = function () { var v = gi.value.trim(); if (!v) return; chatInput = ""; gi.value = ""; A("guess", { text: v }); gi.focus(); };
      on("dgSend", send);
      gi.onkeydown = function (e) { if (e.key === "Enter") send(); };
      if (hadFocus) gi.focus();
    }
  }

  return { renderBoard: renderBoard, renderPhone: renderPhone, reset: function () { var c = $("dCanvas"); if (c) c.remove(); lastDrawerTurn = null; } };
})();
