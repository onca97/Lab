package de.onur.labyrinth;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import de.onur.labyrinth.core.Game;
import de.onur.labyrinth.core.GameServer;
import de.onur.labyrinth.core.NetUtil;
import de.onur.labyrinth.core.WebUpdater;

import java.io.File;
import java.io.InputStream;

public class MainActivity extends Activity {

    private static GameServer server;
    private static final int PICK_ZIP = 4711;
    private WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable ipCheck = new Runnable() {
        @Override public void run() {
            new Thread(() -> {
                String ip = NetUtil.lanIp();
                if (server != null) server.setJoinUrl(ip == null ? "" : "http://" + ip + ":" + GameServer.PORT + "/");
            }).start();
            handler.postDelayed(this, 8000);
        }
    };

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (server == null) {
            WebUpdater updater = new WebUpdater(new File(getFilesDir(), "web_override"));
            server = new GameServer(new Game(), path -> getAssets().open(path), BuildConfig.VERSION_NAME, updater);
            try {
                server.start(GameServer.PORT);
            } catch (Exception e) {
                Toast.makeText(this, "Server konnte nicht starten: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setBackgroundColor(0xFF14201A);
        setContentView(web);
        hideBars();
        // kurz warten, bis der Server-Thread lauscht
        handler.postDelayed(() -> web.loadUrl("http://127.0.0.1:" + GameServer.PORT + "/board"), 300);
    }

    /** Wird von board.html aufgerufen (Knopf "Update per ZIP"). */
    private class Bridge {
        @JavascriptInterface
        public void pickZip() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"});
                try {
                    startActivityForResult(i, PICK_ZIP);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Kein Dateimanager gefunden. Update über das Handy: Adresse/update", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_ZIP || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(() -> {
            String msg;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                int n = server.updater().install(in);
                server.webChanged();
                msg = "Update übernommen (" + n + " Dateien).";
            } catch (Exception e) {
                msg = "Update fehlgeschlagen: " + e.getMessage();
            }
            final String m = msg;
            runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
        }).start();
    }

    private void hideBars() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override protected void onResume() { super.onResume(); handler.post(ipCheck); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(ipCheck); }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            new AlertDialog.Builder(this)
                    .setTitle("Labyrinth beenden?")
                    .setMessage("Das laufende Spiel geht dabei verloren.")
                    .setPositiveButton("Beenden", (dlg, w) -> {
                        if (server != null) { server.stop(); server = null; }
                        finishAndRemoveTaskCompat();
                    })
                    .setNegativeButton("Weiterspielen", null)
                    .show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void finishAndRemoveTaskCompat() {
        if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask(); else finish();
    }

    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
