package de.onur.labyrinth.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Spiellogik "Das verrückte Labyrinth" (7x7, 24 Schätze, 2-4 Spieler).
 * Öffnungen als Bitmaske: N=1, E=2, S=4, W=8.
 * Alle öffentlichen Methoden sind synchronized; der Server ruft sie aus mehreren Threads.
 */
public class Game {
    public static final int N = 1, E = 2, S = 4, W = 8;
    public static final int SIZE = 7;
    public static final int MAX_PLAYERS = 4;
    public static final int TREASURES = 24;

    public static final String[] COLORS = {"#e53935", "#1e88e5", "#43a047", "#fdd835"};
    public static final String[] COLOR_NAMES = {"Rot", "Blau", "Grün", "Gelb"};
    // Startecken: Rot oben links, Blau oben rechts, Grün unten rechts, Gelb unten links
    static final int[][] START = {{0, 0}, {0, 6}, {6, 6}, {6, 0}};

    // Einschubstellen: Spalten 1,3,5 von oben (T) / unten (B), Zeilen 1,3,5 von links (L) / rechts (R)
    public static final String[] INSERTS = {"T1", "T3", "T5", "R1", "R3", "R5", "B5", "B3", "B1", "L5", "L3", "L1"};

    public enum Phase { LOBBY, PUSH, MOVE, FINISHED }

    public static class Tile {
        int mask; int treasure; boolean fixed;
        Tile(int mask, int treasure, boolean fixed) { this.mask = mask; this.treasure = treasure; this.fixed = fixed; }
    }

    public static class Player {
        int id; String name; String token; int color;
        int r, c, startR, startC;
        List<Integer> cards = new ArrayList<>();
        int found, total;
        long lastSeen;
    }

    private final Random rnd;
    private Tile[][] board = new Tile[SIZE][SIZE];
    private Tile spare;
    private final List<Player> players = new ArrayList<>();
    private Phase phase = Phase.LOBBY;
    private int cur = 0;
    private String lastPush = null;
    private int winner = -1;
    private int cardsPerPlayer = 0; // 0 = alle verteilen
    private String message = "";
    private int nextId = 1;
    private long version = 0;
    private int lastFoundTreasure = -1;
    private int lastFoundBy = -1;
    private long lastFoundAt = 0;

    public Game() { this(new Random()); }
    public Game(Random rnd) { this.rnd = rnd; generateBoard(); }

    // ---------- Aufbau ----------

    static int rot(int m) { return ((m << 1) | (m >> 3)) & 15; }

    private void generateBoard() {
        board = new Tile[SIZE][SIZE];
        // Feste Plättchen (Zeile und Spalte gerade)
        board[0][0] = new Tile(E | S, -1, true);
        board[0][6] = new Tile(S | W, -1, true);
        board[6][6] = new Tile(N | W, -1, true);
        board[6][0] = new Tile(N | E, -1, true);
        int t = 0;
        board[0][2] = new Tile(E | S | W, t++, true);
        board[0][4] = new Tile(E | S | W, t++, true);
        board[2][0] = new Tile(N | E | S, t++, true);
        board[4][0] = new Tile(N | E | S, t++, true);
        board[2][6] = new Tile(N | S | W, t++, true);
        board[4][6] = new Tile(N | S | W, t++, true);
        board[6][2] = new Tile(N | E | W, t++, true);
        board[6][4] = new Tile(N | E | W, t++, true);
        board[2][2] = new Tile(N | E | S, t++, true);
        board[2][4] = new Tile(E | S | W, t++, true);
        board[4][2] = new Tile(N | E | W, t++, true);
        board[4][4] = new Tile(N | S | W, t++, true);
        // 34 lose Plättchen: 12 Geraden, 10 leere Kurven, 6 Kurven mit Schatz, 6 T mit Schatz
        List<Tile> loose = new ArrayList<>();
        for (int i = 0; i < 12; i++) loose.add(new Tile(N | S, -1, false));
        for (int i = 0; i < 10; i++) loose.add(new Tile(N | E, -1, false));
        for (int i = 0; i < 6; i++) loose.add(new Tile(N | E, t++, false));
        for (int i = 0; i < 6; i++) loose.add(new Tile(N | E | S, t++, false));
        Collections.shuffle(loose, rnd);
        for (Tile tile : loose) { int k = rnd.nextInt(4); for (int i = 0; i < k; i++) tile.mask = rot(tile.mask); }
        int idx = 0;
        for (int r = 0; r < SIZE; r++)
            for (int c = 0; c < SIZE; c++)
                if (board[r][c] == null) board[r][c] = loose.get(idx++);
        spare = loose.get(idx);
    }

    // ---------- Lobby ----------

    /** Liefert Token oder wirft IllegalStateException mit deutscher Meldung. */
    public synchronized String join(String name, String existingToken) {
        if (existingToken != null) {
            Player p = byToken(existingToken);
            if (p != null) { if (name != null && !name.isEmpty() && phase == Phase.LOBBY) p.name = clean(name); touch(p); changed(); return p.token; }
        }
        if (phase != Phase.LOBBY) throw new IllegalStateException("Das Spiel läuft schon. Warte auf die nächste Runde.");
        if (players.size() >= MAX_PLAYERS) throw new IllegalStateException("Es können maximal 4 Personen mitspielen.");
        String n = clean(name);
        if (n.isEmpty()) throw new IllegalStateException("Bitte einen Namen eingeben.");
        Player p = new Player();
        p.id = nextId++;
        p.name = n;
        p.token = Long.toHexString(rnd.nextLong()) + Long.toHexString(System.nanoTime());
        p.color = freeColor();
        touch(p);
        players.add(p);
        message = n + " ist beigetreten.";
        changed();
        return p.token;
    }

    private int freeColor() {
        for (int col = 0; col < MAX_PLAYERS; col++) {
            boolean used = false;
            for (Player p : players) if (p.color == col) used = true;
            if (!used) return col;
        }
        return 0;
    }

    private static String clean(String s) {
        if (s == null) return "";
        s = s.replaceAll("[\\p{Cntrl}<>]", "").trim();
        if (s.length() > 16) s = s.substring(0, 16);
        return s;
    }

    public synchronized void leave(String token) {
        Player p = byToken(token);
        if (p == null) return;
        if (phase == Phase.LOBBY) { players.remove(p); message = p.name + " hat die Lobby verlassen."; changed(); }
    }

    public synchronized void kick(int playerId) {
        if (phase != Phase.LOBBY) return;
        players.removeIf(p -> p.id == playerId);
        changed();
    }

    public synchronized void setCardsPerPlayer(int n) {
        if (phase != Phase.LOBBY) return;
        cardsPerPlayer = Math.max(0, Math.min(12, n));
        changed();
    }

    public synchronized void start() {
        if (phase != Phase.LOBBY && phase != Phase.FINISHED) return;
        if (players.isEmpty()) throw new IllegalStateException("Es ist noch niemand beigetreten.");
        generateBoard();
        // Spieler nach Farbe sortieren (Rot beginnt)
        players.sort((a, b) -> a.color - b.color);
        List<Integer> deck = new ArrayList<>();
        for (int i = 0; i < TREASURES; i++) deck.add(i);
        Collections.shuffle(deck, rnd);
        int per = TREASURES / players.size();
        if (cardsPerPlayer > 0) per = Math.min(per, cardsPerPlayer);
        int k = 0;
        for (Player p : players) {
            p.cards.clear();
            for (int i = 0; i < per; i++) p.cards.add(deck.get(k++));
            p.found = 0; p.total = per;
            p.startR = START[p.color][0]; p.startC = START[p.color][1];
            p.r = p.startR; p.c = p.startC;
        }
        cur = 0; lastPush = null; winner = -1; lastFoundTreasure = -1; lastFoundBy = -1;
        phase = Phase.PUSH;
        message = players.get(0).name + " beginnt.";
        changed();
    }

    public synchronized void toLobby() {
        phase = Phase.LOBBY; winner = -1; message = "Neue Runde – wer mitspielen will, scannt den QR-Code.";
        changed();
    }

    // ---------- Zug ----------

    private Player current() { return players.isEmpty() ? null : players.get(cur); }

    private void requireTurn(String token, Phase need) {
        Player p = byToken(token);
        if (p == null) throw new IllegalStateException("Unbekannter Spieler. Bitte neu beitreten.");
        touch(p);
        if (phase != need) throw new IllegalStateException(need == Phase.PUSH ? "Jetzt wird nicht geschoben." : "Jetzt wird nicht gezogen.");
        if (current() != p) throw new IllegalStateException("Du bist nicht dran.");
    }

    public synchronized void rotate(String token, int dir) {
        requireTurn(token, Phase.PUSH);
        int times = dir < 0 ? 3 : 1;
        for (int i = 0; i < times; i++) spare.mask = rot(spare.mask);
        changed();
    }

    public static String opposite(String ins) {
        char s = ins.charAt(0);
        char o = s == 'T' ? 'B' : s == 'B' ? 'T' : s == 'L' ? 'R' : 'L';
        return o + ins.substring(1);
    }

    public synchronized void push(String token, String ins) {
        requireTurn(token, Phase.PUSH);
        boolean valid = false;
        for (String s : INSERTS) if (s.equals(ins)) valid = true;
        if (!valid) throw new IllegalStateException("Ungültige Einschubstelle.");
        if (lastPush != null && ins.equals(opposite(lastPush)))
            throw new IllegalStateException("Der letzte Schub darf nicht direkt rückgängig gemacht werden.");
        doPush(ins);
        lastPush = ins;
        phase = Phase.MOVE;
        message = current().name + " hat geschoben und zieht jetzt.";
        changed();
    }

    private void doPush(String ins) {
        char side = ins.charAt(0);
        int line = ins.charAt(1) - '0';
        Tile in = spare;
        Tile out;
        if (side == 'T') { // nach unten schieben
            out = board[SIZE - 1][line];
            for (int r = SIZE - 1; r > 0; r--) board[r][line] = board[r - 1][line];
            board[0][line] = in;
            for (Player p : players) if (p.c == line) p.r = p.r == SIZE - 1 ? 0 : p.r + 1;
        } else if (side == 'B') {
            out = board[0][line];
            for (int r = 0; r < SIZE - 1; r++) board[r][line] = board[r + 1][line];
            board[SIZE - 1][line] = in;
            for (Player p : players) if (p.c == line) p.r = p.r == 0 ? SIZE - 1 : p.r - 1;
        } else if (side == 'L') { // nach rechts schieben
            out = board[line][SIZE - 1];
            for (int c = SIZE - 1; c > 0; c--) board[line][c] = board[line][c - 1];
            board[line][0] = in;
            for (Player p : players) if (p.r == line) p.c = p.c == SIZE - 1 ? 0 : p.c + 1;
        } else {
            out = board[line][0];
            for (int c = 0; c < SIZE - 1; c++) board[line][c] = board[line][c + 1];
            board[line][SIZE - 1] = in;
            for (Player p : players) if (p.r == line) p.c = p.c == 0 ? SIZE - 1 : p.c - 1;
        }
        spare = out;
    }

    /** Erreichbare Felder vom Spieler aus (BFS). */
    boolean[][] reachable(int sr, int sc) {
        boolean[][] seen = new boolean[SIZE][SIZE];
        ArrayDeque<int[]> q = new ArrayDeque<>();
        q.add(new int[]{sr, sc}); seen[sr][sc] = true;
        int[] dr = {-1, 0, 1, 0}, dc = {0, 1, 0, -1}, bit = {N, E, S, W}, back = {S, W, N, E};
        while (!q.isEmpty()) {
            int[] p = q.poll();
            int m = board[p[0]][p[1]].mask;
            for (int d = 0; d < 4; d++) {
                if ((m & bit[d]) == 0) continue;
                int nr = p[0] + dr[d], nc = p[1] + dc[d];
                if (nr < 0 || nc < 0 || nr >= SIZE || nc >= SIZE || seen[nr][nc]) continue;
                if ((board[nr][nc].mask & back[d]) == 0) continue;
                seen[nr][nc] = true; q.add(new int[]{nr, nc});
            }
        }
        return seen;
    }

    public synchronized void move(String token, int r, int c) {
        requireTurn(token, Phase.MOVE);
        Player p = current();
        if (r < 0 || c < 0 || r >= SIZE || c >= SIZE || !reachable(p.r, p.c)[r][c])
            throw new IllegalStateException("Dieses Feld ist von dir aus nicht erreichbar.");
        p.r = r; p.c = c;
        Tile t = board[r][c];
        String msg = null;
        if (!p.cards.isEmpty() && t.treasure == p.cards.get(0)) {
            p.cards.remove(0); p.found++;
            lastFoundTreasure = t.treasure; lastFoundBy = p.id; lastFoundAt = System.currentTimeMillis();
            msg = p.name + " hat einen Schatz gefunden! (" + p.found + "/" + p.total + ")";
        }
        if (p.cards.isEmpty() && r == p.startR && c == p.startC) {
            phase = Phase.FINISHED; winner = p.id;
            message = p.name + " hat gewonnen!";
            changed();
            return;
        }
        cur = (cur + 1) % players.size();
        phase = Phase.PUSH;
        message = (msg != null ? msg + " " : "") + current().name + " ist dran.";
        changed();
    }

    /** Falls jemand weg ist: aktuellen Spieler überspringen (vom Beamer aus). */
    public synchronized void skip() {
        if (phase != Phase.PUSH && phase != Phase.MOVE) return;
        cur = (cur + 1) % players.size();
        phase = Phase.PUSH;
        message = "Zug übersprungen. " + current().name + " ist dran.";
        changed();
    }

    // ---------- Hilfen ----------

    private Player byToken(String token) {
        if (token == null) return null;
        for (Player p : players) if (p.token.equals(token)) return p;
        return null;
    }

    private void touch(Player p) { p.lastSeen = System.currentTimeMillis(); }

    public synchronized boolean isHost(String token) { return byTokenIsFirstJoined(token); }

    private boolean byTokenIsFirstJoined(String token) {
        Player first = null;
        for (Player p : players) if (first == null || p.id < first.id) first = p;
        return first != null && first.token.equals(token);
    }

    public synchronized boolean hasPlayer(String token) { return byToken(token) != null; }

    private void changed() { version++; notifyAll(); }

    /** Ansicht neu senden (z. B. wenn sich die WLAN-Adresse ändert). */
    public synchronized void bump() { changed(); }

    public synchronized long version() { return version; }

    /** Wartet bis zu ms Millisekunden auf eine Änderung. */
    public synchronized long awaitChange(long known, long ms) throws InterruptedException {
        long end = System.currentTimeMillis() + ms;
        while (version == known) {
            long left = end - System.currentTimeMillis();
            if (left <= 0) break;
            wait(left);
        }
        return version;
    }

    // ---------- Ansicht als JSON ----------

    public synchronized boolean isIdle() { return phase == Phase.LOBBY || phase == Phase.FINISHED; }

    public synchronized String view(String token, String joinUrl, String appVersion) { return view(token, joinUrl, appVersion, 0, false); }

    public synchronized String view(String token, String joinUrl, String appVersion, long webStamp, boolean webUpdated) {
        Player me = byToken(token);
        Json j = new Json().obj();
        j.kv("v", version).kv("app", appVersion).kv("web", webStamp).kv("webUpd", webUpdated).kv("phase", phase.name()).kv("url", joinUrl)
         .kv("msg", message).kv("cur", current() == null ? -1 : current().id)
         .kv("winner", winner).kv("lastPush", lastPush).kv("cardsPerPlayer", cardsPerPlayer)
         .kv("forbidden", lastPush == null ? null : opposite(lastPush));
        if (lastFoundBy >= 0 && System.currentTimeMillis() - lastFoundAt < 6000)
            j.key("found").obj().kv("by", lastFoundBy).kv("t", lastFoundTreasure).kv("at", lastFoundAt).end();
        j.key("players").arr();
        for (Player p : players) {
            j.obj().kv("id", p.id).kv("name", p.name).kv("color", COLORS[p.color]).kv("colorName", COLOR_NAMES[p.color])
             .kv("r", p.r).kv("c", p.c).kv("sr", p.startR).kv("sc", p.startC)
             .kv("found", p.found).kv("total", p.total).end();
        }
        j.end();
        j.key("board").arr();
        for (int r = 0; r < SIZE; r++) for (int c = 0; c < SIZE; c++) {
            Tile t = board[r][c];
            j.arr().val(t.mask).val(t.treasure).val(t.fixed ? 1 : 0).end();
        }
        j.end();
        j.key("spare").arr().val(spare.mask).val(spare.treasure).val(0).end();
        if (phase == Phase.MOVE && current() != null) {
            boolean[][] re = reachable(current().r, current().c);
            j.key("reach").arr();
            for (int r = 0; r < SIZE; r++) for (int c = 0; c < SIZE; c++) if (re[r][c]) j.val(r * SIZE + c);
            j.end();
        }
        if (me != null) {
            j.key("me").obj().kv("id", me.id).kv("host", byTokenIsFirstJoined(token))
             .kv("target", me.cards.isEmpty() ? -1 : me.cards.get(0))
             .kv("left", me.cards.size()).end();
        }
        j.end();
        return j.toString();
    }
}
