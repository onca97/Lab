/* Labyrinth – gemeinsamer Code für Beamer und Handy */
var APP_VERSION = "1.1.0";

var TREASURES = [
  ["💎", "Diamant"], ["👑", "Krone"], ["🗝️", "Schlüssel"], ["💰", "Geldsack"],
  ["📜", "Schriftrolle"], ["🦉", "Eule"], ["🐉", "Drache"], ["🦇", "Fledermaus"],
  ["🕷️", "Spinne"], ["🦎", "Eidechse"], ["🐀", "Ratte"], ["🦋", "Schmetterling"],
  ["🧪", "Zaubertrank"], ["🗡️", "Schwert"], ["🛡️", "Schild"], ["🔔", "Glocke"],
  ["🕯️", "Kerze"], ["🍄", "Pilz"], ["🏺", "Vase"], ["💍", "Ring"],
  ["📖", "Zauberbuch"], ["🧭", "Kompass"], ["🎁", "Geschenk"], ["👻", "Geist"]
];

var INSERT_POS = {}; // Einschub -> [gridRow, gridCol, Pfeil]
[1, 3, 5].forEach(function (k) {
  INSERT_POS["T" + k] = [0, k + 1, "▼"];
  INSERT_POS["B" + k] = [8, k + 1, "▲"];
  INSERT_POS["L" + k] = [k + 1, 0, "▶"];
  INSERT_POS["R" + k] = [k + 1, 8, "◀"];
});

function el(tag, cls, html) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
}

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}

/** Ein Plättchen als DOM-Element. t = [maske, schatz, fest] */
function tileEl(t) {
  var d = el("div", "tile" + (t[2] ? " fixed" : ""));
  var m = t[0];
  d.appendChild(el("div", "p pc"));
  if (m & 1) d.appendChild(el("div", "p pn"));
  if (m & 2) d.appendChild(el("div", "p pe"));
  if (m & 4) d.appendChild(el("div", "p ps"));
  if (m & 8) d.appendChild(el("div", "p pw"));
  if (t[1] >= 0) d.appendChild(el("div", "tr", TREASURES[t[1]][0]));
  return d;
}

/**
 * Zeichnet das Brett (9x9-Raster inkl. Pfeilring).
 * opts: { me, canPush, canMove, onPush(ins), onCell(r,c), anim }
 */
function renderBoard(host, s, opts) {
  opts = opts || {};
  host.innerHTML = "";
  var g = el("div", "board");
  var reach = {};
  (s.reach || []).forEach(function (i) { reach[i] = true; });
  var players = s.players || [];
  for (var r = 0; r < 7; r++) {
    for (var c = 0; c < 7; c++) {
      var t = s.board[r * 7 + c];
      var d = tileEl(t);
      d.style.gridRow = (r + 2);
      d.style.gridColumn = (c + 2);
      d.dataset.r = r; d.dataset.c = c;
      // Startecken markieren
      players.forEach(function (p) {
        if (p.sr === r && p.sc === c) { d.style.boxShadow = "inset 0 0 0 calc(var(--t) * .07) " + p.color; }
      });
      if (s.phase === "MOVE" && reach[r * 7 + c]) {
        d.classList.add("reach");
        if (opts.canMove) {
          d.classList.add("click");
          (function (rr, cc) { d.onclick = function () { opts.onCell(rr, cc); }; })(r, c);
        }
      }
      // Spielfiguren
      var here = players.filter(function (p) { return p.r === r && p.c === c; });
      here.forEach(function (p, i) {
        var tok = el("div", "pawn pawn" + i + (p.id === s.cur && s.phase !== "LOBBY" ? " active" : ""));
        tok.style.background = p.color;
        tok.title = p.name;
        tok.textContent = p.name.charAt(0).toUpperCase();
        d.appendChild(tok);
      });
      g.appendChild(d);
    }
  }
  // Pfeile
  Object.keys(INSERT_POS).forEach(function (ins) {
    var pos = INSERT_POS[ins];
    var a = el("div", "arrow", pos[2]);
    a.style.gridRow = pos[0] + 1;
    a.style.gridColumn = pos[1] + 1;
    if (ins === s.forbidden) { a.classList.add("forbidden"); a.textContent = "✕"; }
    else if (s.phase === "PUSH" && opts.canPush) {
      a.classList.add("click");
      a.onclick = function () { opts.onPush(ins); };
    }
    if (s.phase === "MOVE" && ins === s.lastPush) a.classList.add("last");
    g.appendChild(a);
  });
  host.appendChild(g);
  if (opts.anim) animatePush(g, opts.anim);
  return g;
}

/** Lässt die geschobene Reihe vom Rand hereingleiten. */
function animatePush(g, ins) {
  var side = ins.charAt(0), line = parseInt(ins.charAt(1), 10);
  var tiles = g.querySelectorAll(".tile");
  var dx = 0, dy = 0;
  if (side === "T") dy = -1; if (side === "B") dy = 1;
  if (side === "L") dx = -1; if (side === "R") dx = 1;
  var moved = [];
  tiles.forEach(function (t) {
    var r = +t.dataset.r, c = +t.dataset.c;
    if ((side === "T" || side === "B") && c === line || (side === "L" || side === "R") && r === line) {
      t.style.transition = "none";
      t.style.transform = "translate(calc(var(--t) * " + dx + "), calc(var(--t) * " + dy + "))";
      moved.push(t);
    }
  });
  requestAnimationFrame(function () {
    requestAnimationFrame(function () {
      moved.forEach(function (t) {
        t.style.transition = "transform .45s cubic-bezier(.2,.8,.3,1)";
        t.style.transform = "none";
      });
    });
  });
}

/** Long-Polling auf den Spielstand. */
function startPolling(getToken, onState, onConn) {
  var v = -1, gen = 0, webSeen = null;
  function loop(g) {
    if (g !== gen) return;
    var url = "/api/state?v=" + v + "&token=" + encodeURIComponent(getToken() || "") + "&_=" + Date.now();
    fetch(url, { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (s) {
      if (g !== gen) return; // veraltete Anfrage (z. B. nach Beitritt)
      if (onConn) onConn(true);
      // Nach einem ZIP-Update neue Seiten laden
      if (s.web) { if (webSeen && s.web !== webSeen) { location.reload(); return; } webSeen = s.web; }
      if (s.v !== v) { v = s.v; onState(s); }
      setTimeout(function () { loop(g); }, 30);
    }).catch(function () {
      if (g !== gen) return;
      if (onConn) onConn(false);
      setTimeout(function () { loop(g); }, 1500);
    });
  }
  loop(gen);
  // Nach dem Aufwachen des Handys sofort neu laden
  document.addEventListener("visibilitychange", function () { if (!document.hidden) { gen++; v = -1; loop(gen); } });
  return { reset: function () { gen++; v = -1; loop(gen); } };
}

function post(path, data) {
  var body = new URLSearchParams();
  Object.keys(data).forEach(function (k) { if (data[k] != null) body.append(k, data[k]); });
  return fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString()
  }).then(function (r) { return r.json(); });
}

function playerById(s, id) {
  for (var i = 0; i < (s.players || []).length; i++) if (s.players[i].id === id) return s.players[i];
  return null;
}

/** Versionsanzeige: Web-Version und (falls abweichend) App-Version. */
function versionText(s) {
  var t = "v" + APP_VERSION;
  if (s && s.app && s.app !== APP_VERSION) t += " · App " + s.app;
  if (s && s.webUpd) t += " · ZIP-Update";
  return t;
}

function progressDots(p) {
  var h = "";
  for (var i = 0; i < p.total; i++) h += '<span class="dot' + (i < p.found ? " on" : "") + '"></span>';
  return h;
}

function qrSvg(text) {
  var q = new QRCode(-1, QRErrorCorrectLevel.M);
  q.addData(text); q.make();
  var n = q.getModuleCount(), m = 2, size = n + m * 2, path = "";
  for (var r = 0; r < n; r++) for (var c = 0; c < n; c++)
    if (q.isDark(r, c)) path += "M" + (c + m) + " " + (r + m) + "h1v1h-1z";
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + size + " " + size +
    '" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="' + path + '" fill="#000"/></svg>';
}
