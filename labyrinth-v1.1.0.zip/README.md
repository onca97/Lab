# Labyrinth (v1.1.0)

Das verrückte Labyrinth für den Beamer. Mitgespielt wird mit dem Handy im Browser.

## So läuft's
1. App auf dem Beamer bzw. Android-Gerät am Beamer starten. Es erscheint ein QR-Code.
2. Jeder scannt den QR-Code (gleiches WLAN!), gibt seinen Namen ein → max. 4 Spieler.
3. Wer zuerst beigetreten ist, startet das Spiel am Handy (oder per Fernbedienung am Beamer).
4. Wer dran ist: Karte drehen (↺ ↻), gelben Pfeil antippen → einschieben, dann auf ein gelbes Feld ziehen.
5. Alle Schätze gefunden → zurück zur eigenen Startecke = gewonnen.

## APK bauen
Diesen Ordner in ein privates GitHub-Repo hochladen. GitHub Actions baut automatisch
`labyrinth-vX.Y.Z.apk` (unter Actions → letzter Lauf → Artifacts).

Technik: Die App startet einen kleinen Webserver auf Port 8080, kein Internet nötig.

## Update per ZIP (ab v1.1.0)
Den Web-Teil (board.html, phone.html, common.js, style.css …) ohne neue APK tauschen:
- am Beamer in der Lobby: „Update per ZIP“, oder
- am Handy: `<Beamer-Adresse>:8080/update` öffnen und die ZIP hochladen.

Geht nur, solange kein Spiel läuft. Beamer und Handys laden danach automatisch neu.
„Original wiederherstellen“ entfernt das Update. Änderungen am Java-Teil gehen weiter über GitHub.
