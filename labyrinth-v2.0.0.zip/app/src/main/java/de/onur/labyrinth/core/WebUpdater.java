package de.onur.labyrinth.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Spielt den Web-Teil (HTML/JS/CSS) aus einer ZIP ein.
 * Dateien aus der ZIP liegen in einem eigenen Ordner und haben Vorrang vor den eingebauten.
 * Fehlende Dateien kommen weiterhin aus der App.
 */
public class WebUpdater {
    private static final String[] ALLOWED = {".html", ".js", ".css", ".svg", ".png", ".json", ".txt"};
    private static final long MAX_TOTAL = 10L * 1024 * 1024;

    private final File dir;

    public WebUpdater(File dir) { this.dir = dir; }

    /** Öffnet zuerst die eingespielte Datei, sonst null. path z. B. "web/board.html". */
    public InputStream open(String path) throws IOException {
        if (!path.startsWith("web/")) return null;
        File f = new File(dir, path.substring(4));
        if (f.isFile() && f.getCanonicalPath().startsWith(dir.getCanonicalPath() + File.separator))
            return new FileInputStream(f);
        return null;
    }

    public boolean hasUpdate() {
        String[] l = dir.list();
        return l != null && l.length > 0;
    }

    /** Liefert die Anzahl übernommener Dateien. */
    public synchronized int install(InputStream zip) throws IOException {
        File tmp = new File(dir.getParentFile(), dir.getName() + "_tmp");
        deleteTree(tmp);
        if (!tmp.mkdirs()) throw new IOException("Ordner konnte nicht angelegt werden.");
        int count = 0;
        long total = 0;
        try (ZipInputStream zin = new ZipInputStream(zip)) {
            ZipEntry e;
            byte[] buf = new byte[8192];
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                String name = e.getName().replace('\\', '/');
                // "web/xyz.js", "assets/web/xyz.js" oder nur "xyz.js" akzeptieren
                int w = name.lastIndexOf("web/");
                if (w >= 0) name = name.substring(w + 4);
                else if (name.contains("/")) name = name.substring(name.lastIndexOf('/') + 1);
                if (name.isEmpty() || name.startsWith(".") || name.contains("..") || name.startsWith("__MACOSX")) continue;
                if (!allowed(name)) continue;
                File out = new File(tmp, name);
                if (!out.getCanonicalPath().startsWith(tmp.getCanonicalPath() + File.separator)) continue;
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int r;
                    while ((r = zin.read(buf)) > 0) {
                        total += r;
                        if (total > MAX_TOTAL) throw new IOException("ZIP ist zu groß (max. 10 MB).");
                        os.write(buf, 0, r);
                    }
                }
                count++;
            }
        } catch (IOException ex) {
            deleteTree(tmp);
            throw ex;
        }
        if (count == 0) {
            deleteTree(tmp);
            throw new IOException("In der ZIP waren keine Web-Dateien (.html, .js, .css …).");
        }
        deleteTree(dir);
        if (!tmp.renameTo(dir)) throw new IOException("Update konnte nicht übernommen werden.");
        return count;
    }

    /** Zurück zu den in der App eingebauten Dateien. */
    public synchronized void reset() { deleteTree(dir); }

    private static boolean allowed(String n) {
        String l = n.toLowerCase();
        for (String a : ALLOWED) if (l.endsWith(a)) return true;
        return false;
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }
}
