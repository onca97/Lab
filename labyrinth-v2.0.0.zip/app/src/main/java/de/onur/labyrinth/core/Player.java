package de.onur.labyrinth.core;

/** Ein Mitspieler in der Lobby (gilt für alle Spiele). */
public class Player {
    public int id;
    public String name;
    public String token;
    public int color;      // Index in Hub.COLORS
    public boolean local;  // spielt auf dem Gerät, auf dem die App läuft (Host-Handy)
    public long lastSeen;
}
