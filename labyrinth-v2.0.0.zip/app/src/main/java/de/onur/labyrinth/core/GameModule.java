package de.onur.labyrinth.core;

import java.util.List;
import java.util.Map;
import java.util.Random;

/** Ein Spiel der Sammlung. Aufrufe kommen immer synchronisiert über den Hub. */
public interface GameModule {
    String id();
    int minPlayers();
    int maxPlayers();

    /** Neue Partie. players ist bereits in Spielreihenfolge. */
    void start(List<Player> players, Map<String, String> options, Random rnd);

    /** Spielzug; wirft IllegalStateException mit deutscher Meldung bei ungültigen Aktionen. */
    void act(Player p, String action, Map<String, String> params);

    boolean finished();

    /** Host überspringt den aktuellen Zug (jemand ist weg). */
    void skip();

    /** Felder der Ansicht auf oberster Ebene, mindestens "phase", "cur", "winner", "msg". */
    void writeView(Json j);

    /** Zusätzliche Felder je Spieler im "players"-Array. */
    void writePlayer(Json j, Player p);

    /** Zusätzliche, evtl. geheime Felder im "me"-Objekt. */
    void writeMe(Json j, Player me);
}
