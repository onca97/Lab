package de.onur.labyrinth.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Speichert selbst erstellte Editionen (JSON) auf dem Gerät. */
public class Editions {
    private final File dir;

    public Editions(File dir) { this.dir = dir; }

    static String cleanId(String id) {
        if (id == null) return null;
        id = id.toLowerCase().replaceAll("[^a-z0-9-]", "");
        if (id.isEmpty() || id.length() > 40) return null;
        return id;
    }

    /** Liste als JSON-Array: [{"id":"c-xyz","title":"..."}] */
    public synchronized String list() {
        Json j = new Json().arr();
        File[] files = dir.listFiles();
        if (files != null) {
            java.util.Arrays.sort(files);
            for (File f : files) {
                String n = f.getName();
                if (!n.endsWith(".json")) continue;
                String id = n.substring(0, n.length() - 5);
                String title = id;
                try {
                    String s = read(id);
                    int i = s.indexOf("\"title\"");
                    if (i >= 0) {
                        int a = s.indexOf('"', s.indexOf(':', i) + 1), b = s.indexOf('"', a + 1);
                        if (a > 0 && b > a) title = s.substring(a + 1, b);
                    }
                } catch (IOException ignored) { }
                j.obj().kv("id", id).kv("title", title).end();
            }
        }
        j.end();
        return j.toString();
    }

    public synchronized String read(String id) throws IOException {
        id = cleanId(id);
        if (id == null) throw new IOException("Ungültige Edition.");
        File f = new File(dir, id + ".json");
        if (!f.isFile()) throw new IOException("Edition nicht gefunden.");
        byte[] b = new byte[(int) f.length()];
        try (InputStream in = new FileInputStream(f)) { int r = 0; while (r < b.length) { int k = in.read(b, r, b.length - r); if (k < 0) break; r += k; } }
        return new String(b, StandardCharsets.UTF_8);
    }

    public synchronized void save(String id, byte[] json) throws IOException {
        id = cleanId(id);
        if (id == null || !id.startsWith("c-")) throw new IOException("Ungültiger Name für die Edition.");
        if (json.length > 128 * 1024) throw new IOException("Edition ist zu groß.");
        String s = new String(json, StandardCharsets.UTF_8).trim();
        if (!s.startsWith("{") || !s.endsWith("}")) throw new IOException("Das ist kein gültiges Editions-Format.");
        dir.mkdirs();
        try (OutputStream o = new FileOutputStream(new File(dir, id + ".json"))) { o.write(s.getBytes(StandardCharsets.UTF_8)); }
    }

    public synchronized void delete(String id) {
        id = cleanId(id);
        if (id == null) return;
        new File(dir, id + ".json").delete();
    }
}
