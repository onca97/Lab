package de.onur.labyrinth.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Grundstücks-Handelsspiel (klassische Regeln, 2–6 Spieler).
 * Die Namen der Felder kommen aus der Edition (Oberfläche); der Server kennt nur Nummern.
 * Logtexte enthalten Platzhalter: {p3} = Spieler 3, {f12} = Feld 12, {m200} = Betrag 200.
 */
public class EstateGame implements GameModule {

    // ---------- Spielbrett ----------
    public static final int START = 0, STREET = 1, STATION = 2, UTILITY = 3, TAX = 4, CHANCE = 5, CHEST = 6,
            JAIL = 7, PARKING = 8, GOTOJAIL = 9;
    static final int JAIL_POS = 10;
    public static final int[] TYPE = new int[40];
    public static final int[] PRICE = new int[40];
    public static final int[] GROUP = new int[40];       // 0-7 Farben, 8 Bahnhöfe, 9 Werke, -1 sonst
    public static final int[] HOUSE_COST = new int[40];
    public static final int[][] RENT = new int[40][];
    public static final int[] TAX_AMOUNT = new int[40];
    static final List<List<Integer>> GROUPS = new ArrayList<>();

    static {
        for (int i = 0; i < 40; i++) { GROUP[i] = -1; }
        TYPE[0] = START; TYPE[10] = JAIL; TYPE[20] = PARKING; TYPE[30] = GOTOJAIL;
        for (int i : new int[]{2, 17, 33}) TYPE[i] = CHEST;
        for (int i : new int[]{7, 22, 36}) TYPE[i] = CHANCE;
        TYPE[4] = TAX; TAX_AMOUNT[4] = 200; TYPE[38] = TAX; TAX_AMOUNT[38] = 100;
        for (int i : new int[]{5, 15, 25, 35}) { TYPE[i] = STATION; PRICE[i] = 200; GROUP[i] = 8; }
        for (int i : new int[]{12, 28}) { TYPE[i] = UTILITY; PRICE[i] = 150; GROUP[i] = 9; }
        street(1, 0, 60, 50, 2, 10, 30, 90, 160, 250);
        street(3, 0, 60, 50, 4, 20, 60, 180, 320, 450);
        street(6, 1, 100, 50, 6, 30, 90, 270, 400, 550);
        street(8, 1, 100, 50, 6, 30, 90, 270, 400, 550);
        street(9, 1, 120, 50, 8, 40, 100, 300, 450, 600);
        street(11, 2, 140, 100, 10, 50, 150, 450, 625, 750);
        street(13, 2, 140, 100, 10, 50, 150, 450, 625, 750);
        street(14, 2, 160, 100, 12, 60, 180, 500, 700, 900);
        street(16, 3, 180, 100, 14, 70, 200, 550, 750, 950);
        street(18, 3, 180, 100, 14, 70, 200, 550, 750, 950);
        street(19, 3, 200, 100, 16, 80, 220, 600, 800, 1000);
        street(21, 4, 220, 150, 18, 90, 250, 700, 875, 1050);
        street(23, 4, 220, 150, 18, 90, 250, 700, 875, 1050);
        street(24, 4, 240, 150, 20, 100, 300, 750, 925, 1100);
        street(26, 5, 260, 150, 22, 110, 330, 800, 975, 1150);
        street(27, 5, 260, 150, 22, 110, 330, 800, 975, 1150);
        street(29, 5, 280, 150, 24, 120, 360, 850, 1025, 1200);
        street(31, 6, 300, 200, 26, 130, 390, 900, 1100, 1275);
        street(32, 6, 300, 200, 26, 130, 390, 900, 1100, 1275);
        street(34, 6, 320, 200, 28, 150, 450, 1000, 1200, 1400);
        street(37, 7, 350, 200, 35, 175, 500, 1100, 1300, 1500);
        street(39, 7, 400, 200, 50, 200, 600, 1400, 1700, 2000);
        for (int g = 0; g < 10; g++) GROUPS.add(new ArrayList<>());
        for (int i = 0; i < 40; i++) if (GROUP[i] >= 0) GROUPS.get(GROUP[i]).add(i);
    }

    private static void street(int f, int g, int price, int house, int... rent) {
        TYPE[f] = STREET; GROUP[f] = g; PRICE[f] = price; HOUSE_COST[f] = house; RENT[f] = rent;
    }

    static boolean ownable(int f) { return TYPE[f] == STREET || TYPE[f] == STATION || TYPE[f] == UTILITY; }

    // ---------- Karten ----------
    // Jede Karte: Art + Wert. Texte stehen in der Oberfläche (je Edition).
    static final int C_MOVE = 1, C_BACK3 = 2, C_NEAR_UTIL = 3, C_NEAR_STATION = 4, C_GET = 5, C_PAY = 6,
            C_JAILFREE = 7, C_GOJAIL = 8, C_REPAIR = 9, C_PAY_EACH = 10, C_GET_EACH = 11;
    // {art, wert, wert2}
    static final int[][] CHANCE_CARDS = {
            {C_MOVE, 0, 0}, {C_MOVE, 24, 0}, {C_MOVE, 11, 0}, {C_NEAR_UTIL, 0, 0}, {C_NEAR_STATION, 0, 0},
            {C_NEAR_STATION, 0, 0}, {C_GET, 50, 0}, {C_JAILFREE, 0, 0}, {C_BACK3, 0, 0}, {C_GOJAIL, 0, 0},
            {C_REPAIR, 25, 100}, {C_PAY, 15, 0}, {C_MOVE, 5, 0}, {C_MOVE, 39, 0}, {C_PAY_EACH, 50, 0}, {C_GET, 150, 0}};
    static final int[][] CHEST_CARDS = {
            {C_MOVE, 0, 0}, {C_GET, 200, 0}, {C_PAY, 50, 0}, {C_GET, 50, 0}, {C_JAILFREE, 0, 0}, {C_GOJAIL, 0, 0},
            {C_GET, 100, 0}, {C_GET, 20, 0}, {C_GET_EACH, 10, 0}, {C_GET, 100, 0}, {C_PAY, 100, 0}, {C_PAY, 50, 0},
            {C_GET, 25, 0}, {C_REPAIR, 40, 115}, {C_GET, 10, 0}, {C_GET, 100, 0}};

    // ---------- Zustand ----------
    static class Seat {
        Player p;
        int money, pos;
        boolean inJail, bankrupt;
        int jailTurns;
        int jailCards; // Anzahl "Gefängnis frei"-Karten
    }

    static class Debt { int debtor, creditor, amount; String reason; Debt(int d, int c, int a, String r) { debtor = d; creditor = c; amount = a; reason = r; } }

    static class Auction {
        int field, high, highBidder = -1;
        List<Integer> active = new ArrayList<>();
        int turn; // Index in active
    }

    static class Trade {
        int id, from, to, giveMoney, getMoney, giveJail, getJail;
        List<Integer> giveProps = new ArrayList<>(), getProps = new ArrayList<>();
    }

    private Random rnd = new Random();
    final List<Seat> seats = new ArrayList<>();
    final Map<Integer, Seat> byId = new HashMap<>();
    final int[] owner = new int[40];
    final int[] houses = new int[40];
    final boolean[] mortgaged = new boolean[40];
    int bankHouses = 32, bankHotels = 12;
    int cur = 0;
    String state = "roll"; // roll, buy, auction, debt, end
    private String resumeState = "end";
    private int[] dice = {0, 0};
    private int doubles = 0;
    private boolean rollAgain = false;
    private long rollSeq = 0;
    final ArrayDeque<Debt> debts = new ArrayDeque<>();
    Auction auction;
    Trade trade;
    private int tradeSeq = 0;
    List<Integer> chanceDeck = new ArrayList<>(), chestDeck = new ArrayList<>();
    private boolean chanceJailOut = false, chestJailOut = false; // Karte gerade bei einem Spieler
    private int[] lastCard = null; // {deck(0=Ereignis,1=Gemeinschaft), index, playerId, seq}
    private int cardSeq = 0;
    private int[] lastMove = null; // {playerId, from, to, kind(0=laufen,1=springen), seq}
    private int moveSeq = 0;
    int startMoney = 1500, roundLimit = 0, round = 1;
    private boolean potRule = false;
    int pot = 0;
    boolean finished = false;
    int winner = -1;
    private final ArrayDeque<String> log = new ArrayDeque<>();
    private int logSeq = 0;

    @Override public String id() { return "estate"; }
    @Override public int minPlayers() { return 2; }
    @Override public int maxPlayers() { return 6; }
    @Override public boolean finished() { return finished; }

    // ---------- Start ----------

    @Override
    public void start(List<Player> players, Map<String, String> options, Random rnd) {
        this.rnd = rnd;
        startMoney = clamp(parse(options.get("money"), 1500), 500, 5000);
        roundLimit = clamp(parse(options.get("rounds"), 0), 0, 200);
        potRule = "1".equals(options.get("pot"));
        for (int i = 0; i < 40; i++) { owner[i] = -1; houses[i] = 0; mortgaged[i] = false; }
        bankHouses = 32; bankHotels = 12; pot = 0;
        seats.clear(); byId.clear(); debts.clear(); auction = null; trade = null; log.clear();
        for (Player p : players) {
            Seat s = new Seat(); s.p = p; s.money = startMoney;
            seats.add(s); byId.put(p.id, s);
        }
        chanceDeck = shuffled(16); chestDeck = shuffled(16);
        chanceJailOut = chestJailOut = false;
        cur = 0; state = "roll"; doubles = 0; rollAgain = false; dice = new int[]{0, 0};
        round = 1; finished = false; winner = -1; lastCard = null; lastMove = null;
        log("Das Spiel beginnt. {p" + seats.get(0).p.id + "} würfelt zuerst.");
    }

    private List<Integer> shuffled(int n) {
        List<Integer> l = new ArrayList<>();
        for (int i = 0; i < n; i++) l.add(i);
        Collections.shuffle(l, rnd);
        return l;
    }

    // ---------- Aktionen ----------

    @Override
    public void act(Player pl, String a, Map<String, String> q) {
        if (finished) throw new IllegalStateException("Das Spiel ist vorbei.");
        Seat s = byId.get(pl.id);
        if (s == null) throw new IllegalStateException("Du spielst in dieser Runde nicht mit.");
        if (s.bankrupt) throw new IllegalStateException("Du bist pleite und schaust nur noch zu.");
        int f = parse(q.get("f"), -1);
        switch (a) {
            case "roll": roll(s); break;
            case "buy": buy(s); break;
            case "decline": decline(s); break;
            case "bid": bid(s, parse(q.get("amount"), 0)); break;
            case "pass": passAuction(s); break;
            case "end": endTurn(s); break;
            case "build": build(s, f); break;
            case "sell": sellHouse(s, f); break;
            case "mortgage": mortgage(s, f); break;
            case "unmortgage": unmortgage(s, f); break;
            case "jailpay": jailPay(s); break;
            case "jailcard": jailCard(s); break;
            case "pay": payDebt(s); break;
            case "bankrupt": declareBankrupt(s); break;
            case "trade": proposeTrade(s, q); break;
            case "tradeaccept": acceptTrade(s); break;
            case "tradedecline": declineTrade(s); break;
            case "tradecancel": cancelTrade(s); break;
            default: throw new IllegalStateException("Unbekannte Aktion.");
        }
    }

    private Seat current() { return seats.get(cur); }

    private void needTurn(Seat s, String... states) {
        if (current() != s) throw new IllegalStateException("Du bist nicht dran.");
        for (String st : states) if (st.equals(state)) return;
        throw new IllegalStateException(stateHint());
    }

    private String stateHint() {
        switch (state) {
            case "buy": return "Erst entscheiden: kaufen oder versteigern.";
            case "auction": return "Gerade läuft eine Versteigerung.";
            case "debt": return "Erst müssen offene Schulden bezahlt werden.";
            case "roll": return "Erst würfeln.";
            default: return "Das geht gerade nicht.";
        }
    }

    // ---------- Würfeln & Bewegen ----------

    void roll(Seat s) {
        needTurn(s, "roll");
        dice = new int[]{1 + rnd.nextInt(6), 1 + rnd.nextInt(6)};
        rollSeq++;
        int sum = dice[0] + dice[1];
        boolean dbl = dice[0] == dice[1];
        if (s.inJail) {
            if (dbl) {
                s.inJail = false; s.jailTurns = 0;
                log("{p" + s.p.id + "} würfelt einen Pasch und kommt aus dem Gefängnis.");
                rollAgain = false;
                moveBy(s, sum);
                afterAction();
                return;
            }
            s.jailTurns++;
            if (s.jailTurns >= 3) {
                log("{p" + s.p.id + "} hat dreimal keinen Pasch – zahlt {m50} und zieht.");
                s.inJail = false; s.jailTurns = 0;
                rollAgain = false;
                charge(s, -1, 50, "Gefängnis");
                if (!"debt".equals(state)) moveBy(s, sum); else pendingMove = sum;
                afterAction();
                return;
            }
            log("{p" + s.p.id + "} würfelt keinen Pasch und bleibt im Gefängnis.");
            state = "end";
            return;
        }
        if (dbl) {
            doubles++;
            if (doubles >= 3) {
                log("{p" + s.p.id + "} würfelt den dritten Pasch – ab ins Gefängnis!");
                sendToJail(s);
                rollAgain = false;
                state = "end";
                return;
            }
            rollAgain = true;
        } else rollAgain = false;
        moveBy(s, sum);
        afterAction();
    }

    private int pendingMove = 0; // Zug nach Gefängnis-Zahlung, falls erst Geld besorgt werden muss

    private void moveBy(Seat s, int steps) {
        int from = s.pos;
        int to = (from + steps) % 40;
        if (from + steps >= 40) passStart(s);
        s.pos = to;
        lastMove = new int[]{s.p.id, from, to, 0, ++moveSeq};
        land(s, steps, false);
    }

    private void moveTo(Seat s, int to, boolean collectStart) {
        int from = s.pos;
        if (collectStart && to < from) passStart(s);
        if (collectStart && to == 0 && from == 0) passStart(s);
        s.pos = to;
        lastMove = new int[]{s.p.id, from, to, 0, ++moveSeq};
    }

    private void passStart(Seat s) {
        s.money += 200;
        log("{p" + s.p.id + "} kommt über {f0} und bekommt {m200}.");
    }

    private void sendToJail(Seat s) {
        int from = s.pos;
        s.pos = JAIL_POS; s.inJail = true; s.jailTurns = 0;
        doubles = 0;
        lastMove = new int[]{s.p.id, from, JAIL_POS, 1, ++moveSeq};
    }

    /** Feld auswerten. special: 0 normal, 1 = doppelte Bahnhofsmiete, 2 = Werk 10x neu würfeln */
    private void land(Seat s, int steps, boolean fromCard) { land(s, steps, 0); }

    private void land(Seat s, int steps, int special) {
        int f = s.pos;
        switch (TYPE[f]) {
            case STREET: case STATION: case UTILITY: {
                if (owner[f] < 0) {
                    state = "buy";
                    log("{p" + s.p.id + "} landet auf {f" + f + "}.");
                    return;
                }
                if (owner[f] == s.p.id) { log("{p" + s.p.id + "} landet auf eigenem Besitz {f" + f + "}."); return; }
                if (mortgaged[f]) { log("{f" + f + "} ist belastet – keine Miete."); return; }
                int rent = rentFor(f, steps, special);
                log("{p" + s.p.id + "} zahlt {m" + rent + "} Miete an {p" + owner[f] + "} für {f" + f + "}.");
                charge(s, owner[f], rent, "Miete");
                return;
            }
            case TAX:
                log("{p" + s.p.id + "} zahlt {m" + TAX_AMOUNT[f] + "} für {f" + f + "}.");
                charge(s, -1, TAX_AMOUNT[f], "Steuer");
                return;
            case CHANCE: drawCard(s, 0); return;
            case CHEST: drawCard(s, 1); return;
            case GOTOJAIL:
                log("{p" + s.p.id + "} muss ins Gefängnis!");
                sendToJail(s);
                rollAgain = false;
                return;
            case PARKING:
                if (potRule && pot > 0) {
                    log("{p" + s.p.id + "} bekommt die Kasse von {f20}: {m" + pot + "}.");
                    s.money += pot; pot = 0;
                }
                return;
            default:
        }
    }

    int rentFor(int f, int steps, int special) {
        int o = owner[f];
        if (TYPE[f] == STREET) {
            if (houses[f] > 0) return RENT[f][houses[f]];
            return ownsGroup(o, GROUP[f]) ? RENT[f][0] * 2 : RENT[f][0];
        }
        if (TYPE[f] == STATION) {
            int n = 0;
            for (int x : GROUPS.get(8)) if (owner[x] == o) n++;
            int r = 25 << (n - 1);
            return special == 1 ? r * 2 : r;
        }
        if (TYPE[f] == UTILITY) {
            if (special == 2) {
                int a = 1 + rnd.nextInt(6), b = 1 + rnd.nextInt(6);
                dice = new int[]{a, b}; rollSeq++;
                return 10 * (a + b);
            }
            int n = 0;
            for (int x : GROUPS.get(9)) if (owner[x] == o) n++;
            return (n == 2 ? 10 : 4) * steps;
        }
        return 0;
    }

    boolean ownsGroup(int pid, int g) {
        for (int x : GROUPS.get(g)) if (owner[x] != pid) return false;
        return true;
    }

    // ---------- Karten ----------

    private void drawCard(Seat s, int deck) {
        List<Integer> d = deck == 0 ? chanceDeck : chestDeck;
        int[][] cards = deck == 0 ? CHANCE_CARDS : CHEST_CARDS;
        int idx = d.remove(0);
        // "Gefängnis frei" liegt beim Spieler, bis sie benutzt wird
        boolean isJailCard = cards[idx][0] == C_JAILFREE;
        if (!isJailCard) d.add(idx);
        lastCard = new int[]{deck, idx, s.p.id, ++cardSeq};
        log("{p" + s.p.id + "} zieht eine Karte: {c" + deck + "_" + idx + "}");
        int[] c = cards[idx];
        switch (c[0]) {
            case C_MOVE:
                moveTo(s, c[1], true);
                if (c[1] != 0) land(s, 0, 0);
                break;
            case C_BACK3: {
                int from = s.pos;
                s.pos = (s.pos + 37) % 40;
                lastMove = new int[]{s.p.id, from, s.pos, 1, ++moveSeq};
                land(s, 0, 0);
                break;
            }
            case C_NEAR_STATION: {
                int t = s.pos;
                do { t = (t + 1) % 40; } while (TYPE[t] != STATION);
                moveTo(s, t, true);
                land(s, 0, 1);
                break;
            }
            case C_NEAR_UTIL: {
                int t = s.pos;
                do { t = (t + 1) % 40; } while (TYPE[t] != UTILITY);
                moveTo(s, t, true);
                land(s, 0, 2);
                break;
            }
            case C_GET: s.money += c[1]; break;
            case C_PAY: charge(s, -1, c[1], "Karte"); break;
            case C_JAILFREE:
                s.jailCards++;
                if (deck == 0) chanceJailOut = true; else chestJailOut = true;
                break;
            case C_GOJAIL:
                sendToJail(s); rollAgain = false;
                break;
            case C_REPAIR: {
                int cost = 0;
                for (int i = 0; i < 40; i++) if (owner[i] == s.p.id) cost += houses[i] == 5 ? c[2] : houses[i] * c[1];
                if (cost > 0) charge(s, -1, cost, "Reparatur");
                else log("{p" + s.p.id + "} hat keine Gebäude – nichts zu zahlen.");
                break;
            }
            case C_PAY_EACH:
                for (Seat o : seats) if (o != s && !o.bankrupt) charge(s, o.p.id, c[1], "Karte");
                break;
            case C_GET_EACH:
                for (Seat o : seats) if (o != s && !o.bankrupt) charge(o, s.p.id, c[1], "Karte");
                break;
            default:
        }
    }

    // ---------- Geld & Schulden ----------

    /** Zahlung; reicht das Bargeld nicht, entsteht eine Schuld, die erst beglichen werden muss. creditor -1 = Bank */
    private void charge(Seat debtor, int creditor, int amount, String reason) {
        if (amount <= 0) return;
        if (debts.isEmpty() && debtor.money >= amount) {
            transfer(debtor, creditor, amount);
            return;
        }
        debts.add(new Debt(debtor.p.id, creditor, amount, reason));
        if (!"debt".equals(state)) { resumeState = state; state = "debt"; }
        log("{p" + debtor.p.id + "} fehlen {m" + (amount - Math.max(0, debtor.money)) + "} – erst Geld besorgen (Häuser verkaufen, Hypothek, Handel) oder aufgeben.");
    }

    private void transfer(Seat debtor, int creditor, int amount) {
        debtor.money -= amount;
        if (creditor >= 0) { Seat c = byId.get(creditor); if (c != null) c.money += amount; }
        else if (potRule) pot += amount;
    }

    void payDebt(Seat s) {
        Debt d = debts.peek();
        if (d == null || d.debtor != s.p.id) throw new IllegalStateException("Du hast gerade keine offene Zahlung.");
        if (s.money < d.amount) throw new IllegalStateException("Noch nicht genug Geld. Es fehlen " + (d.amount - s.money) + ".");
        transfer(s, d.creditor, d.amount);
        debts.poll();
        log("{p" + s.p.id + "} bezahlt {m" + d.amount + "}" + (d.creditor >= 0 ? " an {p" + d.creditor + "}" : "") + ".");
        resolveDebts();
    }

    /** Nächste Schuld automatisch bezahlen, wenn möglich; sonst weiter warten. */
    private void resolveDebts() {
        while (!debts.isEmpty()) {
            Debt d = debts.peek();
            Seat s = byId.get(d.debtor);
            if (s == null || s.bankrupt) { debts.poll(); continue; }
            if (s.money >= d.amount) { transfer(s, d.creditor, d.amount); debts.poll(); continue; }
            return;
        }
        if ("debt".equals(state)) {
            state = resumeState;
            if (pendingMove > 0) {
                int m = pendingMove; pendingMove = 0;
                Seat c = current();
                if (!c.bankrupt) { moveBy(c, m); afterAction(); return; }
            }
            if (current().bankrupt) { nextPlayer(); return; }
            afterAction();
        }
    }

    /** Nach einer Aktion des Spielers am Zug: in den passenden Zustand wechseln. */
    private void afterAction() {
        if ("debt".equals(state)) { resumeState = resumeAfter(); return; }
        if ("buy".equals(state) || "auction".equals(state)) return;
        state = resumeAfter();
    }

    private String resumeAfter() {
        Seat c = current();
        if (c.bankrupt) return "end";
        return rollAgain && !c.inJail ? "roll" : "end";
    }

    // ---------- Kaufen & Versteigern ----------

    void buy(Seat s) {
        needTurn(s, "buy");
        int f = s.pos;
        if (s.money < PRICE[f]) throw new IllegalStateException("Nicht genug Geld. Du kannst Geld besorgen oder versteigern lassen.");
        s.money -= PRICE[f];
        owner[f] = s.p.id;
        log("{p" + s.p.id + "} kauft {f" + f + "} für {m" + PRICE[f] + "}.");
        state = rollAgain && !s.inJail ? "roll" : "end";
    }

    void decline(Seat s) {
        needTurn(s, "buy");
        startAuction(s.pos);
    }

    private void startAuction(int f) {
        auction = new Auction();
        auction.field = f;
        // Reihenfolge beginnt beim Spieler am Zug
        for (int i = 0; i < seats.size(); i++) {
            Seat o = seats.get((cur + i) % seats.size());
            if (!o.bankrupt) auction.active.add(o.p.id);
        }
        auction.turn = 0;
        state = "auction";
        log("{f" + f + "} wird versteigert.");
    }

    void bid(Seat s, int amount) {
        if (!"auction".equals(state) || auction == null) throw new IllegalStateException("Gerade läuft keine Versteigerung.");
        if (auction.active.get(auction.turn) != s.p.id) throw new IllegalStateException("Warte, bis du mit Bieten dran bist.");
        if (amount <= auction.high) throw new IllegalStateException("Das Gebot muss höher als " + auction.high + " sein.");
        if (amount > s.money) throw new IllegalStateException("So viel Bargeld hast du nicht.");
        auction.high = amount; auction.highBidder = s.p.id;
        log("{p" + s.p.id + "} bietet {m" + amount + "}.");
        auction.turn = (auction.turn + 1) % auction.active.size();
        checkAuctionEnd();
    }

    void passAuction(Seat s) {
        if (!"auction".equals(state) || auction == null) throw new IllegalStateException("Gerade läuft keine Versteigerung.");
        if (auction.active.get(auction.turn) != s.p.id) throw new IllegalStateException("Warte, bis du dran bist.");
        auction.active.remove(auction.turn);
        log("{p" + s.p.id + "} steigt aus.");
        if (!auction.active.isEmpty()) auction.turn %= auction.active.size();
        checkAuctionEnd();
    }

    private void checkAuctionEnd() {
        Auction a = auction;
        boolean done = a.active.isEmpty() || (a.active.size() == 1 && a.highBidder == a.active.get(0));
        if (!done) return;
        if (a.highBidder >= 0) {
            Seat w = byId.get(a.highBidder);
            w.money -= a.high;
            owner[a.field] = w.p.id;
            log("{p" + w.p.id + "} ersteigert {f" + a.field + "} für {m" + a.high + "}.");
        } else log("Niemand wollte {f" + a.field + "} – bleibt bei der Bank.");
        auction = null;
        Seat c = current();
        state = rollAgain && !c.inJail && !c.bankrupt ? "roll" : "end";
    }

    // ---------- Zug beenden ----------

    void endTurn(Seat s) {
        needTurn(s, "end");
        if (trade != null && (trade.from == s.p.id)) { /* offener Handel bleibt bestehen */ }
        nextPlayer();
    }

    private void nextPlayer() {
        if (checkWinner()) return;
        int n = seats.size();
        for (int i = 1; i <= n; i++) {
            int idx = (cur + i) % n;
            if (idx <= cur) { /* über den Anfang hinaus = neue Runde */ }
            if (!seats.get(idx).bankrupt) {
                if (idx <= cur) {
                    round++;
                    if (roundLimit > 0 && round > roundLimit) { finishByWealth(); return; }
                }
                cur = idx;
                break;
            }
        }
        doubles = 0; rollAgain = false;
        state = "roll";
        Seat c = current();
        log("{p" + c.p.id + "} ist dran" + (c.inJail ? " (im Gefängnis)" : "") + ".");
    }

    @Override
    public void skip() {
        if (finished) return;
        if ("auction".equals(state) || "debt".equals(state)) {
            // Versteigerung abbrechen bzw. Schulden des Abwesenden durch Aufgabe lösen ist zu hart –
            // wir beenden nur Versteigerungen; bei Schulden muss der Spieler selbst handeln.
            if ("auction".equals(state)) { auction = null; }
            else return;
        }
        log("Zug von {p" + current().p.id + "} übersprungen.");
        rollAgain = false;
        nextPlayer();
    }

    // ---------- Gefängnis ----------

    void jailPay(Seat s) {
        needTurn(s, "roll");
        if (!s.inJail) throw new IllegalStateException("Du bist nicht im Gefängnis.");
        if (s.money < 50) throw new IllegalStateException("Nicht genug Geld (50 nötig).");
        transfer(s, -1, 50);
        s.inJail = false; s.jailTurns = 0;
        log("{p" + s.p.id + "} zahlt {m50} und ist frei.");
    }

    void jailCard(Seat s) {
        needTurn(s, "roll");
        if (!s.inJail) throw new IllegalStateException("Du bist nicht im Gefängnis.");
        if (s.jailCards <= 0) throw new IllegalStateException("Du hast keine Gefängnis-frei-Karte.");
        s.jailCards--;
        returnJailCard();
        s.inJail = false; s.jailTurns = 0;
        log("{p" + s.p.id + "} nutzt die Gefängnis-frei-Karte.");
    }

    private void returnJailCard() {
        // Karte zurück unter den passenden Stapel
        if (chanceJailOut) { chanceJailOut = false; chanceDeck.add(7); }
        else if (chestJailOut) { chestJailOut = false; chestDeck.add(4); }
    }

    // ---------- Bauen & Hypotheken ----------

    /** Verwalten ist erlaubt: am eigenen Zug (außer Versteigerung) oder wenn man Schulden hat. */
    private void needManage(Seat s) {
        if ("auction".equals(state)) throw new IllegalStateException("Während der Versteigerung geht das nicht.");
        boolean myDebt = !debts.isEmpty() && debts.peek().debtor == s.p.id;
        if (current() != s && !myDebt) throw new IllegalStateException("Das geht nur, wenn du dran bist.");
    }

    void build(Seat s, int f) {
        needManage(s);
        if (f < 0 || f >= 40 || TYPE[f] != STREET) throw new IllegalStateException("Hier kann man nicht bauen.");
        if (owner[f] != s.p.id) throw new IllegalStateException("Das gehört dir nicht.");
        int g = GROUP[f];
        if (!ownsGroup(s.p.id, g)) throw new IllegalStateException("Du brauchst alle Straßen dieser Farbe.");
        for (int x : GROUPS.get(g)) if (mortgaged[x]) throw new IllegalStateException("Eine Straße der Farbe ist belastet.");
        if (houses[f] >= 5) throw new IllegalStateException("Hier steht schon ein Hotel.");
        int min = 9;
        for (int x : GROUPS.get(g)) min = Math.min(min, houses[x]);
        if (houses[f] > min) throw new IllegalStateException("Gleichmäßig bauen: erst auf den anderen Straßen der Farbe.");
        if (s.money < HOUSE_COST[f]) throw new IllegalStateException("Nicht genug Geld.");
        if (houses[f] == 4) {
            if (bankHotels <= 0) throw new IllegalStateException("Die Bank hat keine Hotels mehr.");
            bankHotels--; bankHouses += 4;
        } else {
            if (bankHouses <= 0) throw new IllegalStateException("Die Bank hat keine Häuser mehr.");
            bankHouses--;
        }
        s.money -= HOUSE_COST[f];
        houses[f]++;
        log("{p" + s.p.id + "} baut " + (houses[f] == 5 ? "ein Hotel" : "ein Haus") + " auf {f" + f + "}.");
    }

    void sellHouse(Seat s, int f) {
        needManage(s);
        if (f < 0 || f >= 40 || owner[f] != s.p.id || houses[f] == 0) throw new IllegalStateException("Hier gibt es nichts zu verkaufen.");
        int max = 0;
        for (int x : GROUPS.get(GROUP[f])) max = Math.max(max, houses[x]);
        if (houses[f] < max) throw new IllegalStateException("Gleichmäßig verkaufen: erst auf den Straßen mit mehr Häusern.");
        int half = HOUSE_COST[f] / 2;
        if (houses[f] == 5 && bankHouses < 4) {
            // Bank hat zu wenig Häuser zum Zurückgeben: alle Gebäude dieser Farbe werden verkauft
            int refund = 0;
            for (int x : GROUPS.get(GROUP[f])) {
                if (houses[x] == 5) { bankHotels++; refund += HOUSE_COST[x] / 2 * 5; }
                else { bankHouses += houses[x]; refund += HOUSE_COST[x] / 2 * houses[x]; }
                houses[x] = 0;
            }
            s.money += refund;
            log("Die Bank hat zu wenig Häuser – {p" + s.p.id + "} verkauft alle Gebäude dieser Farbe ({m" + refund + "}).");
        } else if (houses[f] == 5) {
            bankHotels++;
            bankHouses -= 4;
            houses[f] = 4;
            s.money += half;
            log("{p" + s.p.id + "} verkauft das Hotel auf {f" + f + "}.");
        } else {
            houses[f]--; bankHouses++;
            s.money += half;
            log("{p" + s.p.id + "} verkauft ein Haus auf {f" + f + "}.");
        }
        resolveDebts();
    }

    void mortgage(Seat s, int f) {
        needManage(s);
        if (f < 0 || f >= 40 || !ownable(f) || owner[f] != s.p.id) throw new IllegalStateException("Das gehört dir nicht.");
        if (mortgaged[f]) throw new IllegalStateException("Schon belastet.");
        if (TYPE[f] == STREET) for (int x : GROUPS.get(GROUP[f])) if (houses[x] > 0) throw new IllegalStateException("Erst alle Häuser dieser Farbe verkaufen.");
        mortgaged[f] = true;
        s.money += PRICE[f] / 2;
        log("{p" + s.p.id + "} nimmt eine Hypothek auf {f" + f + "} ({m" + PRICE[f] / 2 + "}).");
        resolveDebts();
    }

    static int unmortgageCost(int f) { return (PRICE[f] / 2) * 11 / 10; }

    void unmortgage(Seat s, int f) {
        needManage(s);
        if (f < 0 || f >= 40 || owner[f] != s.p.id || !mortgaged[f]) throw new IllegalStateException("Hier gibt es keine Hypothek.");
        int cost = unmortgageCost(f);
        if (s.money < cost) throw new IllegalStateException("Nicht genug Geld (" + cost + " nötig).");
        s.money -= cost;
        mortgaged[f] = false;
        log("{p" + s.p.id + "} löst die Hypothek auf {f" + f + "} ({m" + cost + "}).");
    }

    // ---------- Pleite ----------

    void declareBankrupt(Seat s) {
        boolean myDebt = !debts.isEmpty() && debts.peek().debtor == s.p.id;
        int creditor = myDebt ? debts.peek().creditor : -1;
        // Gebäude zum halben Preis an die Bank
        for (int i = 0; i < 40; i++) if (owner[i] == s.p.id && houses[i] > 0) {
            if (houses[i] == 5) { bankHotels++; s.money += HOUSE_COST[i] / 2 * 5; }
            else { bankHouses += houses[i]; s.money += HOUSE_COST[i] / 2 * houses[i]; }
            houses[i] = 0;
        }
        Seat c = creditor >= 0 ? byId.get(creditor) : null;
        if (c != null && !c.bankrupt) {
            c.money += Math.max(0, s.money);
            for (int i = 0; i < 40; i++) if (owner[i] == s.p.id) owner[i] = c.p.id;
            c.jailCards += s.jailCards;
            log("{p" + s.p.id + "} ist pleite! Alles geht an {p" + c.p.id + "}.");
        } else {
            for (int i = 0; i < 40; i++) if (owner[i] == s.p.id) { owner[i] = -1; mortgaged[i] = false; }
            for (int k = 0; k < s.jailCards; k++) returnJailCard();
            log("{p" + s.p.id + "} ist pleite! Der Besitz geht zurück an die Bank.");
        }
        s.money = 0; s.jailCards = 0; s.bankrupt = true; s.inJail = false;
        // offene Schulden dieses Spielers verfallen, Handel abbrechen
        debts.removeIf(d -> d.debtor == s.p.id);
        if (trade != null && (trade.from == s.p.id || trade.to == s.p.id)) trade = null;
        if (auction != null) auction.active.remove((Integer) s.p.id);
        if (checkWinner()) return;
        if (current() == s) {
            debts.clear();
            if ("debt".equals(state)) state = "end";
            if (auction != null) { auction = null; }
            rollAgain = false;
            pendingMove = 0;
            nextPlayer();
        } else resolveDebts();
    }

    private boolean checkWinner() {
        List<Seat> alive = new ArrayList<>();
        for (Seat s : seats) if (!s.bankrupt) alive.add(s);
        if (alive.size() == 1) {
            finished = true; winner = alive.get(0).p.id; state = "end";
            log("{p" + winner + "} hat gewonnen!");
            return true;
        }
        return false;
    }

    int netWorth(Seat s) {
        int w = s.money;
        for (int i = 0; i < 40; i++) if (owner[i] == s.p.id) {
            w += mortgaged[i] ? PRICE[i] / 2 : PRICE[i];
            if (TYPE[i] == STREET) w += houses[i] * HOUSE_COST[i];
        }
        return w;
    }

    private void finishByWealth() {
        Seat best = null;
        for (Seat s : seats) if (!s.bankrupt && (best == null || netWorth(s) > netWorth(best))) best = s;
        finished = true; winner = best.p.id; state = "end"; round = roundLimit;
        log("Rundenlimit erreicht. {p" + winner + "} ist am reichsten und gewinnt!");
    }

    // ---------- Handel ----------

    void proposeTrade(Seat s, Map<String, String> q) {
        if (trade != null) throw new IllegalStateException("Es läuft schon ein Handelsangebot.");
        if ("auction".equals(state)) throw new IllegalStateException("Während der Versteigerung kann nicht gehandelt werden.");
        Seat to = byId.get(parse(q.get("to"), -1));
        if (to == null || to == s || to.bankrupt) throw new IllegalStateException("Ungültiger Handelspartner.");
        Trade t = new Trade();
        t.id = ++tradeSeq; t.from = s.p.id; t.to = to.p.id;
        t.giveProps = parseList(q.get("give"));
        t.getProps = parseList(q.get("get"));
        t.giveMoney = Math.max(0, parse(q.get("giveMoney"), 0));
        t.getMoney = Math.max(0, parse(q.get("getMoney"), 0));
        t.giveJail = Math.max(0, parse(q.get("giveJail"), 0));
        t.getJail = Math.max(0, parse(q.get("getJail"), 0));
        if (t.giveProps.isEmpty() && t.getProps.isEmpty() && t.giveMoney == 0 && t.getMoney == 0 && t.giveJail == 0 && t.getJail == 0)
            throw new IllegalStateException("Das Angebot ist leer.");
        validateTrade(t);
        trade = t;
        log("{p" + s.p.id + "} macht {p" + to.p.id + "} ein Handelsangebot.");
    }

    private void validateTrade(Trade t) {
        Seat a = byId.get(t.from), b = byId.get(t.to);
        Set<Integer> seen = new HashSet<>();
        for (int f : t.giveProps) checkTradeProp(f, a, seen);
        for (int f : t.getProps) checkTradeProp(f, b, seen);
        if (a.money < t.giveMoney) throw new IllegalStateException("So viel Geld hat " + a.p.name + " nicht.");
        if (b.money < t.getMoney) throw new IllegalStateException("So viel Geld hat " + b.p.name + " nicht.");
        if (a.jailCards < t.giveJail || b.jailCards < t.getJail) throw new IllegalStateException("Gefängnis-frei-Karten fehlen.");
    }

    private void checkTradeProp(int f, Seat who, Set<Integer> seen) {
        if (f < 0 || f >= 40 || !ownable(f) || owner[f] != who.p.id) throw new IllegalStateException("Ein Feld im Angebot gehört nicht " + who.p.name + ".");
        if (!seen.add(f)) throw new IllegalStateException("Ein Feld ist doppelt im Angebot.");
        if (TYPE[f] == STREET) for (int x : GROUPS.get(GROUP[f])) if (houses[x] > 0)
            throw new IllegalStateException("Straßen mit Häusern in der Farbe können nicht gehandelt werden.");
    }

    void acceptTrade(Seat s) {
        Trade t = trade;
        if (t == null || t.to != s.p.id) throw new IllegalStateException("Es gibt kein Angebot für dich.");
        validateTrade(t);
        Seat a = byId.get(t.from), b = byId.get(t.to);
        for (int f : t.giveProps) owner[f] = b.p.id;
        for (int f : t.getProps) owner[f] = a.p.id;
        a.money += t.getMoney - t.giveMoney;
        b.money += t.giveMoney - t.getMoney;
        a.jailCards += t.getJail - t.giveJail;
        b.jailCards += t.giveJail - t.getJail;
        trade = null;
        log("{p" + b.p.id + "} nimmt das Angebot von {p" + a.p.id + "} an.");
        resolveDebts();
    }

    void declineTrade(Seat s) {
        if (trade == null || trade.to != s.p.id) throw new IllegalStateException("Es gibt kein Angebot für dich.");
        log("{p" + s.p.id + "} lehnt das Angebot von {p" + trade.from + "} ab.");
        trade = null;
    }

    void cancelTrade(Seat s) {
        if (trade == null || trade.from != s.p.id) throw new IllegalStateException("Du hast kein offenes Angebot.");
        trade = null;
        log("{p" + s.p.id + "} zieht das Angebot zurück.");
    }

    // ---------- Ansicht ----------

    private void log(String s) {
        logSeq++;
        log.addLast(logSeq + "|" + s);
        while (log.size() > 12) log.removeFirst();
    }

    @Override
    public void writeView(Json j) {
        Seat c = current();
        String last = log.isEmpty() ? "" : log.peekLast().substring(log.peekLast().indexOf('|') + 1);
        j.kv("phase", finished ? "FINISHED" : "PLAY").kv("st", state).kv("msg", last)
         .kv("cur", c.p.id).kv("winner", winner).kv("round", round).kv("roundLimit", roundLimit)
         .kv("pot", pot).kv("potRule", potRule).kv("bankHouses", bankHouses).kv("bankHotels", bankHotels)
         .kv("rollSeq", rollSeq).kv("rollAgain", rollAgain);
        j.key("dice").arr().val(dice[0]).val(dice[1]).end();
        j.key("fields").arr();
        for (int i = 0; i < 40; i++) j.arr().val(owner[i]).val(houses[i]).val(mortgaged[i] ? 1 : 0).end();
        j.end();
        if (lastMove != null) j.key("move").arr().val(lastMove[0]).val(lastMove[1]).val(lastMove[2]).val(lastMove[3]).val(lastMove[4]).end();
        if (lastCard != null) j.key("card").arr().val(lastCard[0]).val(lastCard[1]).val(lastCard[2]).val(lastCard[3]).end();
        if (auction != null) {
            j.key("auction").obj().kv("f", auction.field).kv("high", auction.high).kv("bidder", auction.highBidder)
             .kv("turn", auction.active.isEmpty() ? -1 : auction.active.get(auction.turn));
            j.key("active").arr(); for (int id : auction.active) j.val(id); j.end();
            j.end();
        }
        Debt d = debts.peek();
        if (d != null) j.key("debt").obj().kv("debtor", d.debtor).kv("creditor", d.creditor).kv("amount", d.amount).kv("reason", d.reason).end();
        if (trade != null) {
            Trade t = trade;
            j.key("trade").obj().kv("id", t.id).kv("from", t.from).kv("to", t.to).kv("giveMoney", t.giveMoney).kv("getMoney", t.getMoney)
             .kv("giveJail", t.giveJail).kv("getJail", t.getJail);
            j.key("give").arr(); for (int f : t.giveProps) j.val(f); j.end();
            j.key("get").arr(); for (int f : t.getProps) j.val(f); j.end();
            j.end();
        }
        j.key("log").arr();
        for (String l : log) j.val(l);
        j.end();
    }

    @Override
    public void writePlayer(Json j, Player p) {
        Seat s = byId.get(p.id);
        if (s == null) return;
        j.kv("money", s.money).kv("pos", s.pos).kv("jail", s.inJail).kv("jailTurns", s.jailTurns)
         .kv("jailCards", s.jailCards).kv("bankrupt", s.bankrupt).kv("worth", netWorth(s));
    }

    @Override
    public void writeMe(Json j, Player me) { }

    // ---------- Hilfen ----------

    static int parse(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; } }
    static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    static List<Integer> parseList(String s) {
        List<Integer> l = new ArrayList<>();
        if (s == null || s.isEmpty()) return l;
        for (String x : s.split(",")) { int v = parse(x, -1); if (v >= 0) l.add(v); }
        return l;
    }

    // Für Tests
    int stateOwner(int f) { return owner[f]; }
    String state() { return state; }
}
