package de.onur.labyrinth.core;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class NetUtil {
    /** Sucht die WLAN/LAN-IPv4-Adresse des Geräts (bevorzugt 192.168.x.x). */
    public static String lanIp() {
        String best = null;
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName().toLowerCase();
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress()) continue;
                    String ip = a.getHostAddress();
                    boolean site = a.isSiteLocalAddress();
                    if (site && ip.startsWith("192.168.")) return ip;
                    if (site && (n.startsWith("wlan") || n.startsWith("eth"))) best = ip;
                    else if (best == null && site) best = ip;
                    else if (best == null) best = ip;
                }
            }
        } catch (Exception ignored) { }
        return best;
    }
}
