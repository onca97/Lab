package de.onur.labyrinth.core;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Kleiner HTTP-Server (ohne Bibliotheken) mit Long-Polling für den Spielstand. */
public class GameServer {

    public interface AssetSource { InputStream open(String path) throws IOException; }

    public static final int PORT = 8080;

    private final Hub game;
    private final AssetSource assets;
    private final String appVersion;
    private volatile String joinUrl = "";
    private ServerSocket server;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running;
    private final WebUpdater updater;
    private volatile Editions editions;
    public void setEditions(Editions e) { editions = e; }
    private volatile long webStamp = System.currentTimeMillis();
    /** Wird nach einem ZIP-Update aufgerufen (z. B. damit der Beamer neu lädt). */
    public volatile Runnable onWebChanged;

    public GameServer(Hub game, AssetSource assets, String appVersion, WebUpdater updater) {
        this.game = game; this.assets = assets; this.appVersion = appVersion; this.updater = updater;
    }

    public WebUpdater updater() { return updater; }

    /** Alle Browser laden die Seiten neu. */
    public void webChanged() {
        webStamp = System.currentTimeMillis();
        game.bump();
        Runnable r = onWebChanged;
        if (r != null) r.run();
    }

    public Hub game() { return game; }
    public void setJoinUrl(String url) {
        if (url == null) url = "";
        if (!url.equals(joinUrl)) { joinUrl = url; game.bump(); }
    }
    public String joinUrl() { return joinUrl; }

    public void start(int port) throws IOException {
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(port));
        running = true;
        Thread t = new Thread(() -> {
            while (running) {
                try {
                    Socket s = server.accept();
                    pool.execute(() -> handle(s));
                } catch (IOException e) {
                    if (!running) break;
                }
            }
        }, "labyrinth-http");
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        pool.shutdownNow();
    }

    // ---------- Anfrage ----------

    private void handle(Socket s) {
        try (Socket sock = s) {
            sock.setSoTimeout(40000);
            InputStream in = new BufferedInputStream(sock.getInputStream());
            OutputStream out = sock.getOutputStream();
            // Keep-Alive: mehrere Anfragen pro Verbindung
            for (int n = 0; n < 100; n++) {
                String line = readLine(in);
                if (line == null || line.isEmpty()) return;
                String[] parts = line.split(" ");
                if (parts.length < 2) return;
                String method = parts[0];
                String target = parts[1];
                Map<String, String> headers = new HashMap<>();
                String h;
                while ((h = readLine(in)) != null && !h.isEmpty()) {
                    int i = h.indexOf(':');
                    if (i > 0) headers.put(h.substring(0, i).trim().toLowerCase(), h.substring(i + 1).trim());
                }
                int len = 0;
                try { len = Integer.parseInt(headers.getOrDefault("content-length", "0")); } catch (NumberFormatException ignored) { }
                boolean upload = target.startsWith("/api/update") || target.equals("/api/edition") || target.startsWith("/api/edition?");
                if (len > (upload ? 11 * 1024 * 1024 : 65536)) return;
                byte[] body = new byte[len];
                int read = 0;
                while (read < len) { int r = in.read(body, read, len - read); if (r < 0) return; read += r; }
                String path = target, query = "";
                int q = target.indexOf('?');
                if (q >= 0) { path = target.substring(0, q); query = target.substring(q + 1); }
                Map<String, String> params = parseForm(query);
                if (!upload) params.putAll(parseForm(new String(body, StandardCharsets.UTF_8)));
                boolean local = isLocal(sock.getInetAddress());
                boolean keep = !"close".equalsIgnoreCase(headers.get("connection"));
                if (upload && path.equals("/api/edition")) { edition(method, body, params, local, out, keep); out.flush(); if (!keep) return; continue; }
                if (upload) { upload(method, body, params, local, out, keep); out.flush(); if (!keep) return; continue; }
                route(method, path, params, local, out, keep);
                out.flush();
                if (!keep) return;
            }
        } catch (Exception ignored) {
        }
    }

    private static boolean isLocal(InetAddress a) { return a.isLoopbackAddress(); }

    private void route(String method, String path, Map<String, String> p, boolean local, OutputStream out, boolean keep) throws IOException, InterruptedException {
        switch (path) {
            case "/":
            case "/index.html":
                file(out, "phone.html", keep); return;
            case "/board":
                file(out, "board.html", keep); return;
            case "/api/editions":
                json(out, editions == null ? "[]" : editions.list(), keep); return;
            case "/editor":
                file(out, "editor.html", keep); return;
            case "/update":
                builtin(out, "update.html", keep); return;
            case "/api/state": {
                long known = parseLong(p.get("v"), -1);
                game.awaitChange(known, 25000);
                send(out, 200, "application/json; charset=utf-8", game.view(p.get("token"), joinUrl, appVersion, webStamp, updater != null && updater.hasUpdate(), local).getBytes(StandardCharsets.UTF_8), keep);
                return;
            }
            case "/api/join": {
                if (!"POST".equals(method)) { send(out, 405, "text/plain", "POST".getBytes(), keep); return; }
                try {
                    String tok = game.join(p.get("name"), p.get("token"), local);
                    json(out, "{\"ok\":true,\"token\":" + Json.quote(tok) + "}", keep);
                } catch (IllegalStateException e) { error(out, e.getMessage(), keep); }
                return;
            }
            case "/api/act": {
                if (!"POST".equals(method)) { send(out, 405, "text/plain", "POST".getBytes(), keep); return; }
                try {
                    act(p, local);
                    json(out, "{\"ok\":true}", keep);
                } catch (IllegalStateException e) { error(out, e.getMessage(), keep); }
                return;
            }
            default:
                String f = path.startsWith("/") ? path.substring(1) : path;
                if (f.contains("..") || f.isEmpty()) { send(out, 404, "text/plain", "404".getBytes(), keep); return; }
                file(out, f, keep);
        }
    }

    private void act(Map<String, String> p, boolean local) {
        String a = p.getOrDefault("a", "");
        String tok = p.get("token");
        boolean admin = local || game.isHost(tok);
        switch (a) {
            case "leave": game.leave(tok); break;
            case "start": need(admin); game.start(); break;
            case "lobby": need(admin); game.toLobby(); break;
            case "cards": need(admin); game.setOption("cards", String.valueOf(parseInt(p.get("n"), 0))); break;
            case "game": need(admin); game.selectGame(p.getOrDefault("id", "")); break;
            case "opt": need(admin); game.setOption(p.get("k"), p.get("v")); break;
            case "kick": need(admin); game.kick(parseInt(p.get("id"), -1)); break;
            case "skip": need(admin); game.skip(); break;
            case "editiondelete":
                need(admin);
                if (editions != null) editions.delete(p.get("id"));
                game.bump();
                break;
            case "webreset":
                needUpdateAllowed(local);
                if (updater != null) { updater.reset(); webChanged(); }
                break;
            default: game.act(tok, a, p); // Spielzug an das laufende Spiel
        }
    }

    /** GET liest eine eigene Edition, POST speichert sie (Host oder App-Gerät). */
    private void edition(String method, byte[] body, Map<String, String> p, boolean local, OutputStream out, boolean keep) throws IOException {
        if (editions == null) { error(out, "Editionen werden hier nicht unterstützt.", keep); return; }
        try {
            if ("GET".equals(method)) {
                send(out, 200, "application/json; charset=utf-8", editions.read(p.get("id")).getBytes(StandardCharsets.UTF_8), keep);
                return;
            }
            if (!local && !game.isHost(p.get("token")) && game.hasAnyPlayer())
                throw new IllegalStateException("Eigene Editionen speichern darf nur der Host.");
            editions.save(p.get("id"), body);
            game.bump();
            json(out, "{\"ok\":true}", keep);
        } catch (IOException e) {
            error(out, e.getMessage(), keep);
        } catch (IllegalStateException e) {
            error(out, e.getMessage(), keep);
        }
    }

    private void needUpdateAllowed(boolean local) {
        if (!local && !game.isIdle())
            throw new IllegalStateException("Updates gehen nur, solange kein Spiel läuft (Lobby oder Spielende).");
    }

    private void upload(String method, byte[] body, Map<String, String> p, boolean local, OutputStream out, boolean keep) throws IOException {
        if (!"POST".equals(method)) { send(out, 405, "text/plain", "POST".getBytes(), keep); return; }
        try {
            needUpdateAllowed(local);
            if (updater == null) throw new IllegalStateException("Updates werden hier nicht unterstützt.");
            if (body.length == 0) throw new IllegalStateException("Keine Datei empfangen.");
            int n;
            try { n = updater.install(new java.io.ByteArrayInputStream(body)); }
            catch (IOException e) { throw new IllegalStateException(e.getMessage() == null ? "ZIP konnte nicht gelesen werden." : e.getMessage()); }
            webChanged();
            json(out, "{\"ok\":true,\"files\":" + n + "}", keep);
        } catch (IllegalStateException e) { error(out, e.getMessage(), keep); }
    }

    private static void need(boolean admin) {
        if (!admin) throw new IllegalStateException("Das darf nur der Host.");
    }

    // ---------- Antworten ----------

    private void file(OutputStream out, String name, boolean keep) throws IOException {
        InputStream is = null;
        if (updater != null) { try { is = updater.open("web/" + name); } catch (IOException e) { is = null; } }
        if (is == null) { try { is = assets.open("web/" + name); } catch (IOException e) { is = null; } }
        stream(out, name, is, keep);
    }

    /** Immer die eingebaute Datei (damit die Update-Seite auch nach einem kaputten Update geht). */
    private void builtin(OutputStream out, String name, boolean keep) throws IOException {
        InputStream is;
        try { is = assets.open("web/" + name); } catch (IOException e) { is = null; }
        stream(out, name, is, keep);
    }

    private void stream(OutputStream out, String name, InputStream is, boolean keep) throws IOException {
        if (is == null) { send(out, 404, "text/plain", "Nicht gefunden".getBytes(), keep); return; }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int r;
        try (InputStream i = is) { while ((r = i.read(buf)) > 0) bo.write(buf, 0, r); }
        send(out, 200, mime(name), bo.toByteArray(), keep);
    }

    private static String mime(String n) {
        if (n.endsWith(".html")) return "text/html; charset=utf-8";
        if (n.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (n.endsWith(".css")) return "text/css; charset=utf-8";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    private static void json(OutputStream out, String body, boolean keep) throws IOException {
        send(out, 200, "application/json; charset=utf-8", body.getBytes(StandardCharsets.UTF_8), keep);
    }

    private static void error(OutputStream out, String msg, boolean keep) throws IOException {
        json(out, "{\"ok\":false,\"error\":" + Json.quote(msg == null ? "Fehler" : msg) + "}", keep);
    }

    private static void send(OutputStream out, int code, String type, byte[] body, boolean keep) throws IOException {
        String status = code == 200 ? "OK" : code == 404 ? "Not Found" : code == 405 ? "Method Not Allowed" : "Error";
        String head = "HTTP/1.1 " + code + " " + status + "\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: " + (keep ? "keep-alive" : "close") + "\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.ISO_8859_1));
        out.write(body);
    }

    // ---------- Parser ----------

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 8192) return null;
        }
        if (c < 0 && b.size() == 0) return null;
        return b.toString("UTF-8");
    }

    static Map<String, String> parseForm(String s) {
        Map<String, String> m = new HashMap<>();
        if (s == null || s.isEmpty()) return m;
        for (String kv : s.split("&")) {
            int i = kv.indexOf('=');
            try {
                if (i < 0) m.put(URLDecoder.decode(kv, "UTF-8"), "");
                else m.put(URLDecoder.decode(kv.substring(0, i), "UTF-8"), URLDecoder.decode(kv.substring(i + 1), "UTF-8"));
            } catch (Exception ignored) { }
        }
        return m;
    }

    private static int parseInt(String s, int d) { try { return Integer.parseInt(s); } catch (Exception e) { return d; } }
    private static long parseLong(String s, long d) { try { return Long.parseLong(s); } catch (Exception e) { return d; } }
}
