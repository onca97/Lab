package de.onur.labyrinth.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Labyrinth-Spiel (7x7, 24 Schätze, 1-4 Spieler).
 * Öffnungen als Bitmaske: N=1, E=2, S=4, W=8.
 */
public class LabyrinthGame implements GameModule {
    public static final int N = 1, E = 2, S = 4, W = 8;
    public static final int SIZE = 7;
    public static final int TREASURES = 24;
    static final int[][] START = {{0, 0}, {0, 6}, {6, 6}, {6, 0}};
    public static final String[] INSERTS = {"T1", "T3", "T5", "R1", "R3", "R5", "B5", "B3", "B1", "L5", "L3", "L1"};

    static class Tile {
        int mask; int treasure; boolean fixed;
        Tile(int mask, int treasure, boolean fixed) { this.mask = mask; this.treasure = treasure; this.fixed = fixed; }
    }

    static class Seat {
        Player p;
        int r, c, startR, startC;
        List<Integer> cards = new ArrayList<>();
        int found, total;
    }

    private Random rnd = new Random();
    private Tile[][] board;
    private Tile spare;
    private final List<Seat> seats = new ArrayList<>();
    private final Map<Integer, Seat> byId = new HashMap<>();
    private String phase = "PUSH"; // PUSH, MOVE, FINISHED
    private int cur = 0;
    private String lastPush = null;
    private int winner = -1;
    private String message = "";
    private int lastFoundTreasure = -1, lastFoundBy = -1;
    private long lastFoundAt = 0;

    public LabyrinthGame() { generateBoard(); }

    @Override public String id() { return "labyrinth"; }
    @Override public int minPlayers() { return 1; }
    @Override public int maxPlayers() { return 4; }

    static int rot(int m) { return ((m << 1) | (m >> 3)) & 15; }

    private void generateBoard() {
        board = new Tile[SIZE][SIZE];
        board[0][0] = new Tile(E | S, -1, true);
        board[0][6] = new Tile(S | W, -1, true);
        board[6][6] = new Tile(N | W, -1, true);
        board[6][0] = new Tile(N | E, -1, true);
        int t = 0;
        board[0][2] = new Tile(E | S | W, t++, true);
        board[0][4] = new Tile(E | S | W, t++, true);
        board[2][0] = new Tile(N | E | S, t++, true);
        board[4][0] = new Tile(N | E | S, t++, true);
        board[2][6] = new Tile(N | S | W, t++, true);
        board[4][6] = new Tile(N | S | W, t++, true);
        board[6][2] = new Tile(N | E | W, t++, true);
        board[6][4] = new Tile(N | E | W, t++, true);
        board[2][2] = new Tile(N | E | S, t++, true);
        board[2][4] = new Tile(E | S | W, t++, true);
        board[4][2] = new Tile(N | E | W, t++, true);
        board[4][4] = new Tile(N | S | W, t++, true);
        List<Tile> loose = new ArrayList<>();
        for (int i = 0; i < 12; i++) loose.add(new Tile(N | S, -1, false));
        for (int i = 0; i < 10; i++) loose.add(new Tile(N | E, -1, false));
        for (int i = 0; i < 6; i++) loose.add(new Tile(N | E, t++, false));
        for (int i = 0; i < 6; i++) loose.add(new Tile(N | E | S, t++, false));
        Collections.shuffle(loose, rnd);
        for (Tile tile : loose) { int k = rnd.nextInt(4); for (int i = 0; i < k; i++) tile.mask = rot(tile.mask); }
        int idx = 0;
        for (int r = 0; r < SIZE; r++)
            for (int c = 0; c < SIZE; c++)
                if (board[r][c] == null) board[r][c] = loose.get(idx++);
        spare = loose.get(idx);
    }

    @Override
    public void start(List<Player> players, Map<String, String> options, Random rnd) {
        this.rnd = rnd;
        generateBoard();
        seats.clear(); byId.clear();
        int cardsPerPlayer = 0;
        try { cardsPerPlayer = Integer.parseInt(options.getOrDefault("cards", "0")); } catch (NumberFormatException ignored) { }
        List<Integer> deck = new ArrayList<>();
        for (int i = 0; i < TREASURES; i++) deck.add(i);
        Collections.shuffle(deck, rnd);
        int per = TREASURES / players.size();
        if (cardsPerPlayer > 0) per = Math.min(per, cardsPerPlayer);
        int k = 0, i = 0;
        for (Player pl : players) {
            Seat s = new Seat();
            s.p = pl;
            for (int n = 0; n < per; n++) s.cards.add(deck.get(k++));
            s.total = per;
            s.startR = START[i][0]; s.startC = START[i][1];
            s.r = s.startR; s.c = s.startC;
            seats.add(s); byId.put(pl.id, s);
            i++;
        }
        cur = 0; lastPush = null; winner = -1; lastFoundTreasure = -1; lastFoundBy = -1;
        phase = "PUSH";
        message = seats.get(0).p.name + " beginnt.";
    }

    @Override public boolean finished() { return "FINISHED".equals(phase); }

    private Seat current() { return seats.isEmpty() ? null : seats.get(cur); }

    private Seat requireTurn(Player p, String need) {
        Seat s = byId.get(p.id);
        if (s == null) throw new IllegalStateException("Du spielst in dieser Runde nicht mit.");
        if (!phase.equals(need)) throw new IllegalStateException("PUSH".equals(need) ? "Jetzt wird nicht geschoben." : "Jetzt wird nicht gezogen.");
        if (current() != s) throw new IllegalStateException("Du bist nicht dran.");
        return s;
    }

    @Override
    public void act(Player p, String a, Map<String, String> params) {
        switch (a) {
            case "rotate": rotate(p, parseInt(params.get("dir"), 1)); break;
            case "push": push(p, params.getOrDefault("at", "")); break;
            case "move": move(p, parseInt(params.get("r"), -1), parseInt(params.get("c"), -1)); break;
            default: throw new IllegalStateException("Unbekannte Aktion.");
        }
    }

    void rotate(Player p, int dir) {
        requireTurn(p, "PUSH");
        int times = dir < 0 ? 3 : 1;
        for (int i = 0; i < times; i++) spare.mask = rot(spare.mask);
    }

    public static String opposite(String ins) {
        char s = ins.charAt(0);
        char o = s == 'T' ? 'B' : s == 'B' ? 'T' : s == 'L' ? 'R' : 'L';
        return o + ins.substring(1);
    }

    void push(Player p, String ins) {
        requireTurn(p, "PUSH");
        boolean valid = false;
        for (String s : INSERTS) if (s.equals(ins)) valid = true;
        if (!valid) throw new IllegalStateException("Ungültige Einschubstelle.");
        if (lastPush != null && ins.equals(opposite(lastPush)))
            throw new IllegalStateException("Der letzte Schub darf nicht direkt rückgängig gemacht werden.");
        doPush(ins);
        lastPush = ins;
        phase = "MOVE";
        message = current().p.name + " hat geschoben und zieht jetzt.";
    }

    private void doPush(String ins) {
        char side = ins.charAt(0);
        int line = ins.charAt(1) - '0';
        Tile in = spare, out;
        if (side == 'T') {
            out = board[SIZE - 1][line];
            for (int r = SIZE - 1; r > 0; r--) board[r][line] = board[r - 1][line];
            board[0][line] = in;
            for (Seat s : seats) if (s.c == line) s.r = s.r == SIZE - 1 ? 0 : s.r + 1;
        } else if (side == 'B') {
            out = board[0][line];
            for (int r = 0; r < SIZE - 1; r++) board[r][line] = board[r + 1][line];
            board[SIZE - 1][line] = in;
            for (Seat s : seats) if (s.c == line) s.r = s.r == 0 ? SIZE - 1 : s.r - 1;
        } else if (side == 'L') {
            out = board[line][SIZE - 1];
            for (int c = SIZE - 1; c > 0; c--) board[line][c] = board[line][c - 1];
            board[line][0] = in;
            for (Seat s : seats) if (s.r == line) s.c = s.c == SIZE - 1 ? 0 : s.c + 1;
        } else {
            out = board[line][0];
            for (int c = 0; c < SIZE - 1; c++) board[line][c] = board[line][c + 1];
            board[line][SIZE - 1] = in;
            for (Seat s : seats) if (s.r == line) s.c = s.c == 0 ? SIZE - 1 : s.c - 1;
        }
        spare = out;
    }

    boolean[][] reachable(int sr, int sc) {
        boolean[][] seen = new boolean[SIZE][SIZE];
        ArrayDeque<int[]> q = new ArrayDeque<>();
        q.add(new int[]{sr, sc}); seen[sr][sc] = true;
        int[] dr = {-1, 0, 1, 0}, dc = {0, 1, 0, -1}, bit = {N, E, S, W}, back = {S, W, N, E};
        while (!q.isEmpty()) {
            int[] p = q.poll();
            int m = board[p[0]][p[1]].mask;
            for (int d = 0; d < 4; d++) {
                if ((m & bit[d]) == 0) continue;
                int nr = p[0] + dr[d], nc = p[1] + dc[d];
                if (nr < 0 || nc < 0 || nr >= SIZE || nc >= SIZE || seen[nr][nc]) continue;
                if ((board[nr][nc].mask & back[d]) == 0) continue;
                seen[nr][nc] = true; q.add(new int[]{nr, nc});
            }
        }
        return seen;
    }

    void move(Player pl, int r, int c) {
        Seat p = requireTurn(pl, "MOVE");
        if (r < 0 || c < 0 || r >= SIZE || c >= SIZE || !reachable(p.r, p.c)[r][c])
            throw new IllegalStateException("Dieses Feld ist von dir aus nicht erreichbar.");
        p.r = r; p.c = c;
        Tile t = board[r][c];
        String msg = null;
        if (!p.cards.isEmpty() && t.treasure == p.cards.get(0)) {
            p.cards.remove(0); p.found++;
            lastFoundTreasure = t.treasure; lastFoundBy = p.p.id; lastFoundAt = System.currentTimeMillis();
            msg = p.p.name + " hat einen Schatz gefunden! (" + p.found + "/" + p.total + ")";
        }
        if (p.cards.isEmpty() && r == p.startR && c == p.startC) {
            phase = "FINISHED"; winner = p.p.id;
            message = p.p.name + " hat gewonnen!";
            return;
        }
        cur = (cur + 1) % seats.size();
        phase = "PUSH";
        message = (msg != null ? msg + " " : "") + current().p.name + " ist dran.";
    }

    @Override
    public void skip() {
        if (!"PUSH".equals(phase) && !"MOVE".equals(phase)) return;
        cur = (cur + 1) % seats.size();
        phase = "PUSH";
        message = "Zug übersprungen. " + current().p.name + " ist dran.";
    }

    @Override
    public void writeView(Json j) {
        j.kv("phase", phase).kv("msg", message).kv("cur", current() == null ? -1 : current().p.id)
         .kv("winner", winner).kv("lastPush", lastPush)
         .kv("forbidden", lastPush == null ? null : opposite(lastPush));
        if (lastFoundBy >= 0 && System.currentTimeMillis() - lastFoundAt < 6000)
            j.key("found").obj().kv("by", lastFoundBy).kv("t", lastFoundTreasure).kv("at", lastFoundAt).end();
        j.key("board").arr();
        for (int r = 0; r < SIZE; r++) for (int c = 0; c < SIZE; c++) {
            Tile t = board[r][c];
            j.arr().val(t.mask).val(t.treasure).val(t.fixed ? 1 : 0).end();
        }
        j.end();
        j.key("spare").arr().val(spare.mask).val(spare.treasure).val(0).end();
        if ("MOVE".equals(phase) && current() != null) {
            boolean[][] re = reachable(current().r, current().c);
            j.key("reach").arr();
            for (int r = 0; r < SIZE; r++) for (int c = 0; c < SIZE; c++) if (re[r][c]) j.val(r * SIZE + c);
            j.end();
        }
    }

    @Override
    public void writePlayer(Json j, Player pl) {
        Seat s = byId.get(pl.id);
        if (s == null) return;
        j.kv("r", s.r).kv("c", s.c).kv("sr", s.startR).kv("sc", s.startC).kv("found", s.found).kv("total", s.total);
    }

    @Override
    public void writeMe(Json j, Player me) {
        Seat s = byId.get(me.id);
        if (s == null) return;
        j.kv("target", s.cards.isEmpty() ? -1 : s.cards.get(0)).kv("left", s.cards.size());
    }

    static int parseInt(String s, int d) { try { return Integer.parseInt(s); } catch (Exception e) { return d; } }
}
