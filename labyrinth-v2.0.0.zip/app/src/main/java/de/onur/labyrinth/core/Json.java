package de.onur.labyrinth.core;

import java.util.ArrayDeque;

/** Minimaler JSON-Builder ohne Abhängigkeiten. */
public class Json {
    private final StringBuilder sb = new StringBuilder();
    private final ArrayDeque<boolean[]> first = new ArrayDeque<>();
    private final ArrayDeque<Character> close = new ArrayDeque<>();
    private boolean afterKey = false;

    private void sep() {
        if (afterKey) { afterKey = false; return; }
        if (!first.isEmpty()) {
            boolean[] f = first.peek();
            if (!f[0]) sb.append(','); else f[0] = false;
        }
    }

    public Json obj() { sep(); sb.append('{'); first.push(new boolean[]{true}); close.push('}'); return this; }
    public Json arr() { sep(); sb.append('['); first.push(new boolean[]{true}); close.push(']'); return this; }
    public Json end() {
        first.pop(); sb.append(close.pop()); return this;
    }

    public Json key(String k) { sep(); str(k); sb.append(':'); afterKey = true; return this; }

    public Json val(Object v) {
        sep();
        if (v == null) sb.append("null");
        else if (v instanceof Number || v instanceof Boolean) sb.append(v);
        else str(v.toString());
        return this;
    }

    public Json kv(String k, Object v) { return key(k).val(v); }

    private void str(String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (ch < 0x20) sb.append(String.format("\\u%04x", (int) ch));
                    else sb.append(ch);
            }
        }
        sb.append('"');
    }

    @Override public String toString() { return sb.toString(); }

    public static String quote(String s) { Json j = new Json(); j.str(s); return j.toString(); }
}
