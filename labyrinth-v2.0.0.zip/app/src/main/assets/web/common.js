/* Labyrinth – gemeinsamer Code für Beamer und Handy */
var APP_VERSION = "2.0.0";

var TREASURES = [
  ["💎", "Diamant"], ["👑", "Krone"], ["🗝️", "Schlüssel"], ["💰", "Geldsack"],
  ["📜", "Schriftrolle"], ["🦉", "Eule"], ["🐉", "Drache"], ["🦇", "Fledermaus"],
  ["🕷️", "Spinne"], ["🦎", "Eidechse"], ["🐀", "Ratte"], ["🦋", "Schmetterling"],
  ["🧪", "Zaubertrank"], ["🗡️", "Schwert"], ["🛡️", "Schild"], ["🔔", "Glocke"],
  ["🕯️", "Kerze"], ["🍄", "Pilz"], ["🏺", "Vase"], ["💍", "Ring"],
  ["📖", "Zauberbuch"], ["🧭", "Kompass"], ["🎁", "Geschenk"], ["👻", "Geist"]
];

var INSERT_POS = {}; // Einschub -> [gridRow, gridCol, Pfeil]
[1, 3, 5].forEach(function (k) {
  INSERT_POS["T" + k] = [0, k + 1, "▼"];
  INSERT_POS["B" + k] = [8, k + 1, "▲"];
  INSERT_POS["L" + k] = [k + 1, 0, "▶"];
  INSERT_POS["R" + k] = [k + 1, 8, "◀"];
});

function el(tag, cls, html) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
}

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}

/** Ein Plättchen als DOM-Element. t = [maske, schatz, fest] */
function tileEl(t) {
  var d = el("div", "tile" + (t[2] ? " fixed" : ""));
  var m = t[0];
  d.appendChild(el("div", "p pc"));
  if (m & 1) d.appendChild(el("div", "p pn"));
  if (m & 2) d.appendChild(el("div", "p pe"));
  if (m & 4) d.appendChild(el("div", "p ps"));
  if (m & 8) d.appendChild(el("div", "p pw"));
  if (t[1] >= 0) { var tr = el("div", "tr", TREASURES[t[1]][0]); tr.style.setProperty("--i", t[1]); d.appendChild(tr); }
  return d;
}

/**
 * Zeichnet das Brett (9x9-Raster inkl. Pfeilring).
 * opts: { me, canPush, canMove, onPush(ins), onCell(r,c), anim }
 */
function renderBoard(host, s, opts) {
  opts = opts || {};
  host.innerHTML = "";
  var g = el("div", "board");
  var reach = {};
  (s.reach || []).forEach(function (i) { reach[i] = true; });
  var players = s.players || [];
  var dist = null;
  if (s.phase === "MOVE") { var cp = playerById(s, s.cur); if (cp) dist = bfs(s.board, cp.r, cp.c).dist; }
  for (var r = 0; r < 7; r++) {
    for (var c = 0; c < 7; c++) {
      var t = s.board[r * 7 + c];
      var d = tileEl(t);
      d.style.gridRow = (r + 2);
      d.style.gridColumn = (c + 2);
      d.dataset.r = r; d.dataset.c = c;
      // Startecken markieren
      players.forEach(function (p) {
        if (p.sr === r && p.sc === c) { d.style.boxShadow = "inset 0 0 0 calc(var(--t) * .07) " + p.color; }
      });
      if (s.phase === "MOVE" && reach[r * 7 + c]) {
        d.classList.add("reach");
        if (dist && dist[r * 7 + c] != null) d.style.setProperty("--d", dist[r * 7 + c]);
        if (opts.canMove) {
          d.classList.add("click");
          (function (rr, cc) { d.onclick = function () { opts.onCell(rr, cc); }; })(r, c);
        }
      }
      // Spielfiguren
      var here = players.filter(function (p) { return p.r === r && p.c === c; });
      here.forEach(function (p, i) {
        var tok = el("div", "pawn pawn" + i + (p.id === s.cur && s.phase !== "LOBBY" ? " active" : ""));
        tok.dataset.id = p.id;
        tok.style.background = p.color;
        tok.title = p.name;
        tok.textContent = p.name.charAt(0).toUpperCase();
        d.appendChild(tok);
      });
      g.appendChild(d);
    }
  }
  // Pfeile
  Object.keys(INSERT_POS).forEach(function (ins) {
    var pos = INSERT_POS[ins];
    var a = el("div", "arrow", pos[2]);
    a.style.gridRow = pos[0] + 1;
    a.style.gridColumn = pos[1] + 1;
    if (ins === s.forbidden) { a.classList.add("forbidden"); a.textContent = "✕"; }
    else if (s.phase === "PUSH" && opts.canPush) {
      a.classList.add("click");
      a.onclick = function () { opts.onPush(ins); };
    }
    if (s.phase === "MOVE" && ins === s.lastPush) a.classList.add("last");
    g.appendChild(a);
  });
  host.appendChild(g);
  if (opts.anim) animatePush(g, opts.anim, opts.ejected);
  return g;
}

/** Breitensuche über die Gänge: Abstand und Vorgänger je Feld. */
function bfs(board, sr, sc) {
  var dist = {}, prev = {}, q = [sr * 7 + sc];
  dist[sr * 7 + sc] = 0;
  var dr = [-1, 0, 1, 0], dc = [0, 1, 0, -1], bit = [1, 2, 4, 8], back = [4, 8, 1, 2];
  while (q.length) {
    var i = q.shift(), r = Math.floor(i / 7), c = i % 7, m = board[i][0];
    for (var d = 0; d < 4; d++) {
      if (!(m & bit[d])) continue;
      var nr = r + dr[d], nc = c + dc[d];
      if (nr < 0 || nc < 0 || nr > 6 || nc > 6) continue;
      var j = nr * 7 + nc;
      if (dist[j] != null || !(board[j][0] & back[d])) continue;
      dist[j] = dist[i] + 1; prev[j] = i; q.push(j);
    }
  }
  return { dist: dist, prev: prev };
}

function findPath(board, from, to) {
  var b = bfs(board, Math.floor(from / 7), from % 7);
  if (b.dist[to] == null) return null;
  var path = [to];
  while (path[0] !== from) path.unshift(b.prev[path[0]]);
  return path;
}

function is3d() { return document.body && document.body.classList.contains("td"); }

function tileSize() {
  return parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--t")) || 60;
}

/** Figur läuft Feld für Feld. Liefert die Dauer in ms. */
function animateWalk(g, path, player) {
  if (!path || path.length < 2) return 0;
  var real = g.querySelector('.pawn[data-id="' + player.id + '"]');
  if (!real) return 0;
  var T = tileSize();
  var step = Math.max(80, Math.min(170, 2600 / path.length));
  var w = el("div", "walker");
  var bb = el("div", "bb");
  var inner = el("div", "pawn walking", real.textContent);
  inner.style.background = player.color;
  bb.appendChild(inner);
  w.appendChild(bb);
  function pos(i) { var r = Math.floor(i / 7), c = i % 7; return "translate(" + ((c + 1.31) * T) + "px," + ((r + 1.31) * T) + "px)"; }
  w.style.transform = pos(path[0]);
  w.style.width = w.style.height = (T * 0.38) + "px";
  g.appendChild(w);
  real.style.visibility = "hidden";
  var k = 0;
  function next() {
    k++;
    if (k >= path.length || !w.isConnected) {
      if (w.isConnected) { w.remove(); real.style.visibility = ""; }
      return;
    }
    w.style.transition = "transform " + step + "ms linear";
    w.style.transform = pos(path[k]);
    setTimeout(next, step);
  }
  setTimeout(next, 30);
  return path.length * step + 60;
}

/** Funkenregen an einem Feld. */
function burst(g, idx, color) {
  var T = tileSize(), r = Math.floor(idx / 7), c = idx % 7;
  var cx = (c + 1.5) * T, cy = (r + 1.5) * T;
  var cols = [color || "#ffb300", "#ffe082", "#fff", "#ffb300"];
  for (var i = 0; i < 26; i++) {
    var p = el("div", "spark");
    var a = Math.random() * Math.PI * 2, d = T * (0.8 + Math.random() * 1.6);
    p.style.background = cols[i % cols.length];
    p.style.left = cx + "px"; p.style.top = cy + "px";
    g.appendChild(p);
    (function (p, a, d) {
      requestAnimationFrame(function () { requestAnimationFrame(function () {
        p.style.transform = "translate(" + Math.cos(a) * d + "px," + Math.sin(a) * d + "px) scale(.2)";
        p.style.opacity = "0";
      }); });
      setTimeout(function () { p.remove(); }, 1000);
    })(p, a, d);
  }
  var ring = el("div", "ring");
  ring.style.left = cx + "px"; ring.style.top = cy + "px";
  g.appendChild(ring);
  setTimeout(function () { ring.remove(); }, 900);
}

/** Lässt ein Element (z. B. Schiebekarte) sichtbar weiterdrehen. */
function rotateAnim(tileElement, prevMask, newMask) {
  var cw = ((prevMask << 1) | (prevMask >> 3)) & 15, ccw = ((prevMask >> 1) | ((prevMask & 1) << 3)) & 15;
  var from = newMask === cw ? -90 : newMask === ccw ? 90 : 0;
  if (!from) return;
  tileElement.style.transition = "none";
  tileElement.style.transform = "rotate(" + from + "deg)";
  requestAnimationFrame(function () { requestAnimationFrame(function () {
    tileElement.style.transition = "transform .32s cubic-bezier(.3,1.4,.5,1)";
    tileElement.style.transform = "none";
  }); });
}

/** Lässt die geschobene Reihe vom Rand hereingleiten; die herausgeschobene Karte gleitet raus. */
function animatePush(g, ins, ejected) {
  var side = ins.charAt(0), line = parseInt(ins.charAt(1), 10);
  var tiles = g.querySelectorAll(".tile");
  var dx = 0, dy = 0;
  if (side === "T") dy = -1; if (side === "B") dy = 1;
  if (side === "L") dx = -1; if (side === "R") dx = 1;
  var moved = [];
  tiles.forEach(function (t) {
    var r = +t.dataset.r, c = +t.dataset.c;
    if ((side === "T" || side === "B") && c === line || (side === "L" || side === "R") && r === line) {
      t.style.transition = "none";
      t.style.transform = "translate(calc(var(--t) * " + dx + "), calc(var(--t) * " + dy + "))" + (is3d() ? " translateZ(calc(var(--t) * .35))" : "");
      moved.push(t);
    }
  });
  var ghost = null;
  if (ejected) {
    // Position der herausfallenden Karte: am gegenüberliegenden Ende der Reihe
    var gr = side === "T" ? 6 : side === "B" ? 0 : line, gc = side === "L" ? 6 : side === "R" ? 0 : line;
    ghost = tileEl(ejected);
    ghost.classList.add("ghost");
    ghost.style.gridRow = gr + 2; ghost.style.gridColumn = gc + 2;
    ghost.style.transition = "none";
    ghost.style.transform = "translate(calc(var(--t) * " + dx + "), calc(var(--t) * " + dy + "))";
    g.appendChild(ghost);
  }
  requestAnimationFrame(function () {
    requestAnimationFrame(function () {
      moved.forEach(function (t) {
        t.style.transition = "transform " + (is3d() ? ".75s" : ".55s") + " cubic-bezier(.2,.8,.3,1)";
        t.style.transform = "";
      });
      if (ghost) {
        ghost.style.transition = "transform .55s cubic-bezier(.2,.8,.3,1), opacity .55s ease-in";
        ghost.style.transform = is3d()
          ? "translate(calc(var(--t) * " + (-dx * 1.4) + "), calc(var(--t) * " + (-dy * 1.4) + ")) translateZ(calc(var(--t) * -1.2)) rotateX(" + (dy ? -dy * 75 : 25) + "deg) rotateY(" + (dx ? dx * 75 : 15) + "deg)"
          : "translate(calc(var(--t) * " + (-dx) + "), calc(var(--t) * " + (-dy) + ")) rotate(" + (dx + dy > 0 ? -8 : 8) + "deg) scale(.9)";
        ghost.style.opacity = "0";
        setTimeout(function () { if (ghost.isConnected) ghost.remove(); }, 650);
      }
    });
  });
}

/** Die Karte, die beim Schub herausfällt (aus dem Zustand vor dem Schub). */
function ejectedTile(prevBoard, ins) {
  var side = ins.charAt(0), line = parseInt(ins.charAt(1), 10);
  var r = side === "T" ? 6 : side === "B" ? 0 : line, c = side === "L" ? 6 : side === "R" ? 0 : line;
  return prevBoard[r * 7 + c];
}

/** Long-Polling auf den Spielstand. */
function startPolling(getToken, onState, onConn) {
  var v = -1, gen = 0, webSeen = null;
  function loop(g) {
    if (g !== gen) return;
    var url = "/api/state?v=" + v + "&token=" + encodeURIComponent(getToken() || "") + "&_=" + Date.now();
    fetch(url, { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (s) {
      if (g !== gen) return; // veraltete Anfrage (z. B. nach Beitritt)
      if (onConn) onConn(true);
      // Nach einem ZIP-Update neue Seiten laden
      if (s.web) { if (webSeen && s.web !== webSeen) { location.reload(); return; } webSeen = s.web; }
      if (s.v !== v) { v = s.v; onState(s); }
      setTimeout(function () { loop(g); }, 30);
    }).catch(function () {
      if (g !== gen) return;
      if (onConn) onConn(false);
      setTimeout(function () { loop(g); }, 1500);
    });
  }
  loop(gen);
  // Nach dem Aufwachen des Handys sofort neu laden
  document.addEventListener("visibilitychange", function () { if (!document.hidden) { gen++; v = -1; loop(gen); } });
  return { reset: function () { gen++; v = -1; loop(gen); } };
}

function post(path, data) {
  var body = new URLSearchParams();
  Object.keys(data).forEach(function (k) { if (data[k] != null) body.append(k, data[k]); });
  return fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString()
  }).then(function (r) { return r.json(); });
}

function playerById(s, id) {
  for (var i = 0; i < (s.players || []).length; i++) if (s.players[i].id === id) return s.players[i];
  return null;
}

/** Versionsanzeige: Web-Version und (falls abweichend) App-Version. */
function versionText(s) {
  var t = "v" + APP_VERSION;
  if (s && s.app && s.app !== APP_VERSION) t += " · App " + s.app;
  if (s && s.webUpd) t += " · ZIP-Update";
  return t;
}

/** Modus-Auswahl (nur in der App, ab v1.3.0). */
function hasModeBridge() { return !!(window.Android && window.Android.setMode && window.Android.getMode); }

function showModePicker() {
  if (document.getElementById("modePick")) return;
  var o = el("div", "modepick");
  o.id = "modePick";
  o.innerHTML = '<div class="mp-in"><h2>Wie wollt ihr spielen?</h2>' +
    '<button class="mp-btn" data-m="board"><span class="mp-ic">📽️</span><span><b>Beamer / Fernseher</b>' +
    '<small>Dieses Gerät zeigt das Spielbrett. Alle spielen mit dem Handy.</small></span></button>' +
    '<button class="mp-btn" data-m="phone"><span class="mp-ic">📱</span><span><b>Auf diesem Handy hosten</b>' +
    '<small>Du spielst hier selbst mit und bist Host. Die anderen scannen deinen QR-Code.</small></span></button>' +
    '<div class="mp-hint">Später änderbar über „Modus wechseln“.</div></div>';
  document.body.appendChild(o);
  o.querySelectorAll(".mp-btn").forEach(function (b) {
    b.onclick = function () { window.Android.setMode(b.dataset.m); };
  });
  var first = o.querySelector(".mp-btn"); if (first) first.focus();
}

function progressDots(p) {
  var h = "";
  for (var i = 0; i < p.total; i++) h += '<span class="dot' + (i < p.found ? " on" : "") + '"></span>';
  return h;
}

function qrSvg(text) {
  var q = new QRCode(-1, QRErrorCorrectLevel.M);
  q.addData(text); q.make();
  var n = q.getModuleCount(), m = 2, size = n + m * 2, path = "";
  for (var r = 0; r < n; r++) for (var c = 0; c < n; c++)
    if (q.isDark(r, c)) path += "M" + (c + m) + " " + (r + m) + "h1v1h-1z";
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + size + " " + size +
    '" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="' + path + '" fill="#000"/></svg>';
}
