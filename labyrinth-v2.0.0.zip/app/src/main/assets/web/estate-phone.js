/* Stadtbaron – Handy-Steuerung */
var EstatePhone = (function () {
  var tab = "own", lastEdition = null, tradeDraft = null, wasMyTurn = false, lastCardSeq = -1;

  function $(id) { return document.getElementById(id); }
  function money(n) { return EST.money(n); }
  function fname(i) { return esc(EST.fieldName(i)); }

  function chip(i) {
    var c = EST.color(i);
    return c ? '<span class="echip" style="background:' + c + '"></span>' : '<span class="eic">' + EST.icon(i) + "</span>";
  }

  function housesTxt(n) { return n === 5 ? "🏨" : n > 0 ? new Array(n + 1).join("🏠") : ""; }

  // ---------- Aktionsbereich ----------
  function actionCard(s, me) {
    var p = playerById(s, me.id);
    var h = "", cur = playerById(s, s.cur), myTurn = s.cur === me.id;
    var diceTxt = s.dice[0] ? "🎲 " + s.dice[0] + " + " + s.dice[1] + " = " + (s.dice[0] + s.dice[1]) + (s.dice[0] === s.dice[1] ? " (Pasch!)" : "") : "";
    if (p.bankrupt) return '<div class="ecard2">Du bist pleite und schaust zu. 👀</div>';

    if (s.debt) {
      var d = s.debt;
      if (d.debtor === me.id) {
        var enough = p.money >= d.amount;
        return '<div class="ecard2 danger"><b>Du musst ' + money(d.amount) + " zahlen</b>" +
          (d.creditor >= 0 ? EST.fmt(" an {p" + d.creditor + "}", s) : "") + "<br>Bargeld: " + money(p.money) +
          (enough ? "" : '<div class="hint">Es fehlen ' + money(d.amount - p.money) + ". Verkaufe Häuser oder nimm Hypotheken (unten unter „Besitz“) oder handle.</div>") +
          '<button id="epPay"' + (enough ? "" : " disabled") + ">Bezahlen</button>" +
          '<button class="ghost" id="epBankrupt">Aufgeben (pleite)</button></div>';
      }
      return '<div class="ecard2">' + EST.fmt("{p" + d.debtor + "} muss erst {m" + d.amount + "} bezahlen …", s) + "</div>";
    }

    if (s.auction) {
      var a = s.auction, mine = a.turn === me.id;
      h = '<div class="ecard2"><div class="sub">Versteigerung</div><b class="bigname">' + fname(a.f) + "</b>" +
        "<div>Höchstgebot: <b>" + (a.bidder >= 0 ? money(a.high) + EST.fmt(" ({p" + a.bidder + "})", s) : "noch keins") + "</b></div>";
      if (mine) {
        var start = a.high + 10;
        h += '<div class="bidrow"><button class="ghost" data-bid="' + (a.high + 10) + '">+10</button><button class="ghost" data-bid="' + (a.high + 50) +
          '">+50</button><button class="ghost" data-bid="' + (a.high + 100) + '">+100</button></div>' +
          '<div class="bidrow"><input id="epBidIn" type="number" inputmode="numeric" value="' + start + '" min="' + start + '"><button id="epBid">Bieten</button></div>' +
          '<button class="ghost" id="epPass">Aussteigen</button><div class="hint">Dein Bargeld: ' + money(p.money) + "</div>";
      } else h += '<div class="hint">' + EST.fmt("{p" + a.turn + "} ist mit Bieten dran …", s) + "</div>";
      return h + "</div>";
    }

    if (!myTurn) return '<div class="ecard2">' + EST.fmt("{p" + s.cur + "} ist dran", s) + (diceTxt ? "<div class='hint'>" + diceTxt + "</div>" : "") + "</div>";

    if (s.st === "roll") {
      if (p.jail) {
        return '<div class="ecard2"><b>Du bist im ' + esc(EST.get().jail) + "</b> (Versuch " + (p.jailTurns + 1) + "/3)" +
          '<button id="epRoll">🎲 Pasch versuchen</button>' +
          '<button class="ghost" id="epJailPay"' + (p.money < 50 ? " disabled" : "") + ">" + money(50) + " zahlen & frei</button>" +
          (p.jailCards ? '<button class="ghost" id="epJailCard">Frei-Karte nutzen</button>' : "") + "</div>";
      }
      return '<div class="ecard2">' + (s.rollAgain ? "<b>Pasch! Du darfst nochmal würfeln.</b>" : "<b>Du bist dran!</b>") +
        (diceTxt && s.rollAgain ? "<div class='hint'>" + diceTxt + "</div>" : "") +
        '<button id="epRoll" class="bigbtn">🎲 Würfeln</button></div>';
    }
    if (s.st === "buy") {
      var f = p.pos, x = EST.F[f];
      return '<div class="ecard2"><div class="hint">' + diceTxt + "</div>" + EstateBoard.deedHtml(f, s, EST.get()) +
        '<button id="epBuy"' + (p.money < x.price ? " disabled" : "") + ">Kaufen für " + money(x.price) + "</button>" +
        '<button class="ghost" id="epDecline">Nicht kaufen – versteigern</button>' +
        (p.money < x.price ? '<div class="hint">Zu wenig Bargeld – du kannst erst Geld besorgen (Besitz) oder versteigern lassen.</div>' : "") + "</div>";
    }
    if (s.st === "end") {
      return '<div class="ecard2"><div>' + diceTxt + "</div><div class='hint'>" + EST.fmt(s.msg, s) + "</div>" +
        '<button id="epEnd" class="bigbtn">Zug beenden</button><div class="hint">Vorher kannst du bauen, Hypotheken lösen oder handeln.</div></div>';
    }
    return '<div class="ecard2">' + EST.fmt(s.msg, s) + "</div>";
  }

  function tradeCard(s, me) {
    var t = s.trade;
    if (!t || (t.to !== me.id && t.from !== me.id)) return "";
    var e = EST.get();
    var part = function (props, m, j) {
      var l = props.map(function (f) { return chip(f) + fname(f); });
      if (m) l.push("💶 " + money(m)); if (j) l.push(j + "× " + esc(e.jail) + "-frei-Karte");
      return l.length ? l.join("<br>") : "nichts";
    };
    var other = playerById(s, t.to === me.id ? t.from : t.to);
    if (t.to === me.id) {
      return '<div class="ecard2 trade"><b>' + EST.fmt("Angebot von {p" + t.from + "}", s) + "</b>" +
        '<div class="tgrid"><div><div class="sub">Du bekommst</div>' + part(t.give, t.giveMoney, t.giveJail) + "</div>" +
        '<div><div class="sub">Du gibst</div>' + part(t.get, t.getMoney, t.getJail) + "</div></div>" +
        '<button id="epTAcc">Annehmen</button><button class="ghost" id="epTDec">Ablehnen</button></div>';
    }
    return '<div class="ecard2 trade">Dein Angebot an <b style="color:' + other.color + '">' + esc(other.name) + "</b> wartet auf Antwort …" +
      '<button class="ghost" id="epTCan">Zurückziehen</button></div>';
  }

  // ---------- Tabs ----------
  function ownTab(s, me) {
    var p = playerById(s, me.id), e = EST.get();
    var mine = [];
    for (var i = 0; i < 40; i++) if (s.fields[i][0] === me.id) mine.push(i);
    var canManage = s.cur === me.id || (s.debt && s.debt.debtor === me.id);
    var h = '<div class="eown-sum">Vermögen: <b>' + money(p.worth) + "</b>" + (p.jailCards ? " · " + p.jailCards + "× " + esc(e.jail) + "-frei-Karte" : "") + "</div>";
    if (!mine.length) h += '<div class="hint">Du besitzt noch nichts.</div>';
    if (!canManage && mine.length) h += '<div class="hint">Bauen und Hypotheken gehen, wenn du dran bist.</div>';
    mine.forEach(function (i) {
      var x = EST.F[i], fl = s.fields[i];
      var full = x.group != null && EST.GROUPS[x.group].every(function (k) { return s.fields[k][0] === me.id; });
      var rent = EST.rentInfo(s, i);
      h += '<div class="erow' + (fl[2] ? " mort" : "") + '" data-deed="' + i + '">' + chip(i) +
        '<div class="ertxt"><b>' + fname(i) + "</b><small>" + (fl[2] ? "Hypothek – keine Miete" : (rent < 0 ? "Miete: 4×/10× Wurf" : "Miete " + money(rent))) +
        " " + housesTxt(fl[1]) + "</small></div><div class='erbtn'>";
      if (canManage) {
        if (x.type === EST.T.STREET && full && !fl[2] && fl[1] < 5) h += '<button data-a="build" data-f="' + i + '" title="bauen">+🏠 ' + money(x.house) + "</button>";
        if (fl[1] > 0) h += '<button class="ghost" data-a="sell" data-f="' + i + '">−🏠</button>';
        if (!fl[2] && fl[1] === 0) h += '<button class="ghost" data-a="mortgage" data-f="' + i + '">Hypothek +' + money(x.price / 2) + "</button>";
        if (fl[2]) h += '<button class="ghost" data-a="unmortgage" data-f="' + i + '">Lösen ' + money(Math.floor(x.price / 2 * 11 / 10)) + "</button>";
      }
      h += "</div></div>";
    });
    h += '<button class="ghost danger2" id="epGiveUp">Aufgeben</button>';
    return h;
  }

  function tradeTab(s, me) {
    if (s.trade) return '<div class="hint">Es läuft gerade ein Handelsangebot. Erst wenn es erledigt ist, kann ein neues gemacht werden.</div>';
    if (s.auction) return '<div class="hint">Während der Versteigerung kann nicht gehandelt werden.</div>';
    var others = s.players.filter(function (p) { return p.id !== me.id && !p.bankrupt; });
    if (!others.length) return '<div class="hint">Niemand zum Handeln da.</div>';
    var d = tradeDraft || (tradeDraft = { to: others[0].id, give: {}, get: {}, gm: 0, tm: 0, gj: 0, tj: 0 });
    if (!playerById(s, d.to) || playerById(s, d.to).bankrupt) d.to = others[0].id;
    var tradable = function (pid) {
      var l = [];
      for (var i = 0; i < 40; i++) if (s.fields[i][0] === pid) {
        var x = EST.F[i];
        var built = x.type === EST.T.STREET && EST.GROUPS[x.group].some(function (k) { return s.fields[k][1] > 0; });
        if (!built) l.push(i);
      }
      return l;
    };
    var me2 = playerById(s, me.id), part = playerById(s, d.to);
    var h = '<label class="erow2">Mit wem? <select id="epTo">' + others.map(function (p) {
      return '<option value="' + p.id + '"' + (p.id === d.to ? " selected" : "") + ">" + esc(p.name) + "</option>"; }).join("") + "</select></label>";
    var col = function (title, props, sel, key, moneyKey, maxMoney, jailKey, maxJail) {
      var c = '<div class="tcol"><div class="sub">' + title + "</div>";
      if (!props.length) c += '<div class="hint">keine handelbaren Felder</div>';
      props.forEach(function (i) {
        c += '<label class="tchk"><input type="checkbox" data-k="' + key + '" data-f="' + i + '"' + (sel[i] ? " checked" : "") + ">" + chip(i) + fname(i) + "</label>";
      });
      c += '<label class="tm">Geld <input type="number" inputmode="numeric" min="0" max="' + maxMoney + '" data-m="' + moneyKey + '" value="' + (d[moneyKey] || 0) + '"></label>';
      if (maxJail) c += '<label class="tm">Frei-Karten <input type="number" min="0" max="' + maxJail + '" data-j="' + jailKey + '" value="' + (d[jailKey] || 0) + '"></label>';
      return c + "</div>";
    };
    h += '<div class="tgrid">' + col("Ich gebe", tradable(me.id), d.give, "give", "gm", me2.money, "gj", me2.jailCards) +
      col(esc(part.name) + " gibt", tradable(d.to), d.get, "get", "tm", part.money, "tj", part.jailCards) + "</div>";
    h += '<button id="epTSend">Angebot senden</button>';
    return h;
  }

  function boardTab(s) {
    var h = "";
    for (var i = 0; i < 40; i++) {
      var x = EST.F[i], fl = s.fields[i];
      var o = fl[0] >= 0 ? playerById(s, fl[0]) : null;
      var here = s.players.filter(function (p) { return p.pos === i && !p.bankrupt; })
        .map(function (p) { return '<span class="pdot" style="background:' + p.color + '">' + esc(p.name.charAt(0)) + "</span>"; }).join("");
      h += '<div class="erow small' + (fl[2] ? " mort" : "") + '"' + (x.price ? ' data-deed="' + i + '"' : "") + ">" + chip(i) +
        '<div class="ertxt"><b>' + fname(i) + "</b><small>" + (x.price ? (o ? '<span style="color:' + o.color + '">● ' + esc(o.name) + "</span> " + housesTxt(fl[1]) : money(x.price)) : x.tax ? money(x.tax) : "") +
        "</small></div>" + here + "</div>";
    }
    return h;
  }

  function logTab(s) {
    return EST.logLines(s, 12).reverse().map(function (l) { return '<div class="elogline">' + l.html + "</div>"; }).join("");
  }

  // ---------- Rendern ----------
  function render(s, fresh, prevS) {
    var me = s.me;
    var edId = (s.options && s.options.edition) || "stuttgart";
    if (lastEdition !== edId) {
      EST.use(edId, function () { lastEdition = edId; if (S) render(S, false, null); });
      $("epAction").innerHTML = '<div class="ecard2">Lade Edition …</div>';
      return;
    }
    var p = playerById(s, me.id);
    $("epSw").style.background = p.color;
    $("epName").textContent = p.name;
    var mo = $("epMoney");
    if (prevS && prevS.players) {
      var pp = playerById(prevS, me.id);
      if (pp && pp.money !== p.money) { mo.classList.remove("flashp", "flashm"); void mo.offsetWidth; mo.classList.add(p.money > pp.money ? "flashp" : "flashm"); }
    }
    mo.textContent = money(p.money);
    $("epTitle").textContent = EST.get().title;

    var myTurn = s.cur === me.id && s.phase === "PLAY";
    var needMe = myTurn || (s.auction && s.auction.turn === me.id) || (s.debt && s.debt.debtor === me.id) || (s.trade && s.trade.to === me.id);
    if (fresh && needMe && !wasMyTurn && navigator.vibrate) { try { navigator.vibrate([120, 60, 120]); } catch (e) {} }
    wasMyTurn = !!needMe;

    // Karte gezogen -> kurz anzeigen
    if (fresh && s.card && s.card[3] !== lastCardSeq && lastCardSeq !== -1 && s.card[2] === me.id) {
      var e = EST.get();
      showToastInfo((s.card[0] === 0 ? e.chance : e.chest) + ": " + EST.cardText(s.card[0], s.card[1], e));
    }
    lastCardSeq = s.card ? s.card[3] : 0;

    $("epAction").innerHTML = actionCard(s, me) + tradeCard(s, me);
    document.querySelectorAll("#epTabs button").forEach(function (b) { b.classList.toggle("sel", b.dataset.t === tab); });
    var body = $("epBody");
    // Handelsformular nicht neu aufbauen, solange man darin tippt (sonst gehen Eingaben verloren)
    var typing = document.activeElement && body.contains(document.activeElement) && /INPUT|SELECT/.test(document.activeElement.tagName);
    if (tab === "trade" && body.dataset.tab === "trade" && typing && !s.trade) { wire(s); return; }
    var html = tab === "own" ? ownTab(s, me) : tab === "trade" ? tradeTab(s, me) : tab === "board" ? boardTab(s) : logTab(s);
    body.innerHTML = html;
    body.dataset.tab = tab;
    wire(s);
  }

  function wire(s) {
    var A = window.estateAct;
    var on = function (id, fn) { var x = $(id); if (x) x.onclick = fn; };
    on("epRoll", function () { A("roll"); });
    on("epBuy", function () { A("buy"); });
    on("epDecline", function () { A("decline"); });
    on("epEnd", function () { A("end"); });
    on("epPay", function () { A("pay"); });
    on("epBankrupt", function () { if (confirm("Wirklich aufgeben? Dein Besitz geht an den Gläubiger bzw. die Bank.")) A("bankrupt"); });
    on("epGiveUp", function () { if (confirm("Wirklich aufgeben und ausscheiden?")) A("bankrupt"); });
    on("epJailPay", function () { A("jailpay"); });
    on("epJailCard", function () { A("jailcard"); });
    on("epPass", function () { A("pass"); });
    on("epBid", function () { A("bid", { amount: $("epBidIn").value }); });
    document.querySelectorAll("[data-bid]").forEach(function (b) { b.onclick = function () { A("bid", { amount: b.dataset.bid }); }; });
    on("epTAcc", function () { A("tradeaccept"); });
    on("epTDec", function () { A("tradedecline"); });
    on("epTCan", function () { A("tradecancel"); });
    document.querySelectorAll("#epBody [data-a]").forEach(function (b) {
      b.onclick = function (ev) { ev.stopPropagation(); A(b.dataset.a, { f: b.dataset.f }); };
    });
    document.querySelectorAll("[data-deed]").forEach(function (r) {
      r.onclick = function (ev) { if (ev.target.tagName === "BUTTON") return; showDeed(+r.dataset.deed, s); };
    });
    // Handel
    var d = tradeDraft;
    var to = $("epTo");
    if (to) to.onchange = function () { d.to = +this.value; d.get = {}; d.tm = 0; d.tj = 0; render(S, false, null); };
    document.querySelectorAll("#epBody input[data-k]").forEach(function (c) {
      c.onchange = function () { d[c.dataset.k][c.dataset.f] = c.checked; };
    });
    document.querySelectorAll("#epBody input[data-m]").forEach(function (c) { c.oninput = function () { d[c.dataset.m] = +c.value || 0; }; });
    document.querySelectorAll("#epBody input[data-j]").forEach(function (c) { c.oninput = function () { d[c.dataset.j] = +c.value || 0; }; });
    on("epTSend", function () {
      var keys = function (o) { return Object.keys(o).filter(function (k) { return o[k]; }).join(","); };
      A("trade", { to: d.to, give: keys(d.give), get: keys(d.get), giveMoney: d.gm, getMoney: d.tm, giveJail: d.gj, getJail: d.tj })
        .then(function (r) { if (r && r.ok) { tradeDraft = null; tab = "own"; render(S, false, null); } });
    });
  }

  function showDeed(i, s) {
    var m = $("epDeed");
    m.querySelector(".in").innerHTML = EstateBoard.deedHtml(i, s, EST.get()) + '<button id="epDeedClose" style="margin-top:12px">Schließen</button>';
    m.classList.add("on");
    $("epDeedClose").onclick = function () { m.classList.remove("on"); };
    m.onclick = function (ev) { if (ev.target === m) m.classList.remove("on"); };
  }

  function showToastInfo(t) {
    var e = $("epInfo");
    e.textContent = t; e.classList.add("show");
    clearTimeout(showToastInfo.tm); showToastInfo.tm = setTimeout(function () { e.classList.remove("show"); }, 5000);
  }

  function init() {
    document.querySelectorAll("#epTabs button").forEach(function (b) {
      b.onclick = function () { tab = b.dataset.t; if (S) render(S, false, null); };
    });
  }

  function reset() { lastEdition = null; tradeDraft = null; lastCardSeq = -1; tab = "own"; }

  return { render: render, init: init, reset: reset };
})();
