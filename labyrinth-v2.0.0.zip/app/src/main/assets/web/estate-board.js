/* Stadtbaron – Beamer-Ansicht */
var EstateBoard = (function () {
  var pawnEls = {}, animating = {}, lastMoveSeq = -1, lastRollSeq = -1, lastCardSeq = -1, lastLogSeq = 0;
  var cardTimer = null, built = false, lastEdition = null, prevMoney = {}, prevCur = null, bannerTimer = null;

  function $(id) { return document.getElementById(id); }

  function size() {
    var B = Math.min(innerHeight * 0.97, innerWidth * 0.58);
    document.documentElement.style.setProperty("--u", (B / 12.2) + "px");
  }

  function build(e) {
    var bd = $("estBoard");
    bd.innerHTML = "";
    for (var i = 0; i < 40; i++) {
      var gp = EST.gridPos(i), sd = EST.side(i);
      var c = el("div", "ef" + (sd < 0 ? " corner" : " s" + sd));
      c.id = "ef" + i;
      c.style.gridRow = gp[0] + 1; c.style.gridColumn = gp[1] + 1;
      bd.appendChild(c);
    }
    var center = el("div", "ecenter");
    center.innerHTML = '<div class="title" id="estTitle"></div><div class="round" id="estRound"></div>' +
      '<div class="dice"><div class="die" id="die0"></div><div class="die" id="die1"></div></div>' +
      '<div class="estatus" id="estStatus"></div><div class="epanel" id="estPanel" style="display:none"></div>' +
      '<div class="elog" id="estLog"></div><div class="ecard" id="estCard"></div>';
    bd.appendChild(center);
    for (var d = 0; d < 2; d++) for (var k = 0; k < 9; k++) $("die" + d).appendChild(el("i"));
    built = true;
  }

  var PIPS = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8] };
  function setDie(d, n) {
    var pips = $("die" + d).children;
    for (var k = 0; k < 9; k++) pips[k].classList.toggle("on", (PIPS[n] || []).indexOf(k) >= 0);
  }

  function fieldHtml(i, s, e) {
    var x = EST.F[i], fl = s.fields[i];
    var h = "";
    var col = EST.color(i, e);
    if (col) {
      var bar = '<div class="bar" style="background:' + col + '">';
      if (fl[1] === 5) bar += '<span class="ht"></span>';
      else for (var k = 0; k < fl[1]; k++) bar += '<span class="hs"></span>';
      h += bar + "</div>";
    } else h += '<div class="ic">' + EST.icon(i, e) + "</div>";
    h += '<div class="nm">' + esc(EST.fieldName(i, e)) + "</div>";
    if (x.price && fl[0] < 0) h += '<div class="pr">' + EST.money(x.price, e) + "</div>";
    else if (x.tax) h += '<div class="pr">' + EST.money(x.tax, e) + "</div>";
    if (fl[0] >= 0) {
      var o = playerById(s, fl[0]);
      if (o) h += '<div class="own" style="--oc:' + o.color + '"></div><div class="flag" style="--oc:' + o.color + '"></div>';
    }
    return h;
  }

  /** Mittelpunkt eines Feldes in Pixeln (im Brett) + Versatz je Spieler. */
  function pawnXY(i, seat, count) {
    var c = $("ef" + i);
    if (!c) return [0, 0];
    var u = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--u")) || 50;
    var cx = c.offsetLeft + c.offsetWidth / 2, cy = c.offsetTop + c.offsetHeight / 2;
    var cols = count > 3 ? 3 : Math.max(1, count);
    var row = Math.floor(seat / 3), col = seat % 3;
    var ox = (col - (cols - 1) / 2) * u * 0.36, oy = (row - (count > 3 ? 0.5 : 0)) * u * 0.38;
    return [cx + ox - u * 0.21, cy + oy - u * 0.21];
  }

  function placePawn(p, idx, n, pos) {
    var xy = pawnXY(pos, idx, n);
    pawnEls[p.id].style.transform = "translate(" + xy[0] + "px," + xy[1] + "px)";
  }

  function animateMove(p, idx, n, from, to, kind) {
    var elp = pawnEls[p.id];
    if (!elp) return 0;
    if (kind === 1) {
      animating[p.id] = true;
      elp.classList.add("jump");
      placePawn(p, idx, n, to);
      setTimeout(function () { elp.classList.remove("jump"); delete animating[p.id]; }, 650);
      return 650;
    }
    var steps = (to - from + 40) % 40;
    if (steps === 0) return 0;
    animating[p.id] = true;
    var k = 0;
    var tick = function () {
      k++;
      placePawn(p, idx, n, (from + k) % 40);
      if ((from + k) % 40 === 0) { var go = $("ef0"); if (go) { go.classList.remove("pop"); void go.offsetWidth; go.classList.add("pop"); } }
      if (k < steps) setTimeout(tick, 170);
      else setTimeout(function () { delete animating[p.id]; }, 180);
    };
    setTimeout(tick, 60);
    return steps * 170 + 120;
  }

  function moneyFloats(s) {
    s.players.forEach(function (p) {
      if (prevMoney[p.id] != null && p.money !== prevMoney[p.id]) {
        var card = document.querySelector('.epc[data-pid="' + p.id + '"]');
        if (card) {
          var d = p.money - prevMoney[p.id];
          var f = el("div", "mfloat " + (d > 0 ? "plus" : "minus"), (d > 0 ? "+" : "−") + EST.money(Math.abs(d)));
          card.appendChild(f);
          setTimeout(function () { f.remove(); }, 1900);
        }
      }
      prevMoney[p.id] = p.money;
    });
  }

  function deedHtml(i, s, e) {
    var x = EST.F[i];
    var col = EST.color(i, e) || "#455a64";
    var h = '<div class="deed"><div class="hd" style="background:' + col + '">' + (EST.color(i, e) ? "" : EST.icon(i, e) + " ") + esc(EST.fieldName(i, e)) + '</div><div class="bd">';
    if (x.type === EST.T.STREET) {
      h += "<table><tr><td>Miete</td><td>" + EST.money(x.rent[0], e) + "</td></tr>";
      for (var k = 1; k <= 4; k++) h += "<tr><td>mit " + k + (k > 1 ? " Häusern" : " Haus") + "</td><td>" + EST.money(x.rent[k], e) + "</td></tr>";
      h += "<tr><td>mit Hotel</td><td>" + EST.money(x.rent[5], e) + "</td></tr></table>";
      h += "Hauskosten " + EST.money(x.house, e) + " · Hypothek " + EST.money(x.price / 2, e);
    } else if (x.type === EST.T.STATION) {
       h += "<table><tr><td>1 im Besitz</td><td>" + EST.money(25, e) + "</td></tr><tr><td>2</td><td>" + EST.money(50, e) +
        "</td></tr><tr><td>3</td><td>" + EST.money(100, e) + "</td></tr><tr><td>4</td><td>" + EST.money(200, e) + "</td></tr></table>Hypothek " + EST.money(100, e);
    } else if (x.type === EST.T.UTILITY) {
      h += "1 Werk: 4× Augenzahl<br>beide Werke: 10× Augenzahl<br>Hypothek " + EST.money(75, e);
    }
    return h + "</div></div>";
  }

  function panel(s, e) {
    var p = $("estPanel");
    var h = "";
    if (s.st === "buy") {
      var cp = playerById(s, s.cur), cf = cp ? cp.pos : 0;
      h = '<div>' + EST.fmt("{p" + s.cur + "} überlegt:", s) + '</div><div class="big">' + esc(EST.fieldName(cf, e)) + '</div>' +
        "kaufen für " + EST.money(EST.F[cf].price, e) + " – oder versteigern?";
    } else if (s.auction) {
      var a = s.auction;
      h = '<div>Versteigerung: <b>' + esc(EST.fieldName(a.f, e)) + "</b></div>" +
        '<div class="big">' + (a.bidder >= 0 ? EST.money(a.high, e) : "noch kein Gebot") + "</div>" +
        (a.bidder >= 0 ? EST.fmt("von {p" + a.bidder + "} · ", s) : "") + (a.turn >= 0 ? EST.fmt("{p" + a.turn + "} bietet …", s) : "");
    } else if (s.debt) {
      var d = s.debt;
      h = EST.fmt("{p" + d.debtor + "} muss <b>{m" + d.amount + "}</b> zahlen" + (d.creditor >= 0 ? " an {p" + d.creditor + "}" : ""), s) +
        '<div style="font-size:.85em;opacity:.8">Häuser verkaufen, Hypothek aufnehmen, handeln – oder aufgeben.</div>';
    } else if (s.trade) {
      var t = s.trade;
      var part = function (props, m, j) {
        var l = props.map(function (f) { return esc(EST.fieldName(f, e)); });
        if (m) l.push(EST.money(m, e)); if (j) l.push(j + "× " + esc(e.jail) + "-frei");
        return l.length ? l.join(", ") : "nichts";
      };
      h = EST.fmt("Handel: {p" + t.from + "} → {p" + t.to + "}", s) + '<div style="font-size:.9em;margin-top:.3em">gibt: ' + part(t.give, t.giveMoney, t.giveJail) +
        "<br>bekommt: " + part(t.get, t.getMoney, t.getJail) + "</div>";
    }
    p.style.display = h ? "block" : "none";
    p.innerHTML = h;
  }

  function showCard(s, e, delay) {
    var c = s.card;
    clearTimeout(cardTimer);
    cardTimer = setTimeout(function () {
      var box = $("estCard");
      box.className = "ecard d" + c[0];
      box.innerHTML = '<div class="cic">' + EST.icon(c[0] === 0 ? 7 : 2, e) + '</div><div class="deck">' + esc(c[0] === 0 ? e.chance : e.chest) + "</div>" +
        EST.cardText(c[0], c[1], e);
      void box.offsetWidth;
      box.classList.add("show");
      cardTimer = setTimeout(function () { box.classList.remove("show"); }, 4200);
    }, delay);
  }

  function cardShowing() { var c = $("estCard"); return c && c.classList.contains("show"); }

  function banner(p) {
    if (!p || !S || S.playing !== "estate" || S.cur !== p.id || S.phase !== "PLAY") return;
    var t = $("turn");
    $("turnT").textContent = p.name + " ist dran!";
    t.style.background = "linear-gradient(90deg, transparent, " + p.color + " 15%, " + p.color + " 85%, transparent)";
    t.classList.remove("go"); void t.offsetWidth; t.classList.add("go");
  }

  /** Zeichnet alles; liefert die Dauer laufender Animationen (ms). */
  function render(s, fresh, p0) {
    var edId = (s.options && s.options.edition) || "stuttgart";
    var e = EST.get();
    if (lastEdition !== edId) {
      EST.use(edId, function () { lastEdition = edId; if (S) render(S, false, null); });
      if (!built) { size(); build(EST.get()); }
      return 0;
    }
    if (!built) { size(); build(e); }
    $("estTitle").textContent = e.title;
    $("estRound").textContent = "Runde " + s.round + (s.roundLimit ? " von " + s.roundLimit : "") + (s.potRule && s.pot ? " · Kasse " + EST.money(s.pot, e) : "");
    for (var i = 0; i < 40; i++) {
      var c = $("ef" + i);
      c.innerHTML = fieldHtml(i, s, e);
      c.classList.toggle("mort", !!s.fields[i][2]);
      c.classList.remove("hl");
    }
    // Gerade gekauft/gebaut -> kurz hüpfen
    if (p0 && p0.fields) for (var k = 0; k < 40; k++) {
      if (p0.fields[k][0] !== s.fields[k][0] || p0.fields[k][1] !== s.fields[k][1]) {
        var fe = $("ef" + k); fe.classList.remove("pop"); void fe.offsetWidth; fe.classList.add("pop");
      }
    }
    var hlField = s.st === "buy" ? (playerById(s, s.cur) || {}).pos : s.auction ? s.auction.f : null;
    if (hlField != null) $("ef" + hlField).classList.add("hl");

    // Spieler links
    var ps = $("estPlayers"); ps.innerHTML = "";
    s.players.forEach(function (p) {
      var cur = p.id === s.cur && s.phase === "PLAY";
      var card = el("div", "epc" + (cur ? " cur" : "") + (p.bankrupt ? " out" : ""));
      card.dataset.pid = p.id;
      var chips = "";
      for (var f = 0; f < 40; f++) if (s.fields[f][0] === p.id) chips += '<span style="background:' + (EST.color(f, e) || "#90a4ae") + '"></span>';
      card.innerHTML = '<div class="nm"><span class="sw" style="background:' + p.color + '"></span>' + esc(p.name) +
        (p.jail ? '<span class="badge">' + esc(e.jail) + "</span>" : p.bankrupt ? '<span class="badge">pleite</span>' : "") + "</div>" +
        '<div class="mo">' + EST.money(p.money, e) + '</div><div class="chips">' + chips + "</div>";
      ps.appendChild(card);
    });
    if (fresh) moneyFloats(s);

    // Rechts: Info + Verlauf
    $("estRight").innerHTML = '<div class="einfo">Bank: <b>' + s.bankHouses + "</b> Häuser, <b>" + s.bankHotels + "</b> Hotels" +
      (s.roundLimit ? "<br>Spielende nach Runde <b>" + s.roundLimit + "</b>" : "") + "</div>" +
      '<div class="einfo" style="font-size:1.8vh">' + EST.logLines(s, 7).map(function (l) { return "<div>" + l.html + "</div>"; }).join("") + "</div>" +
      '<div class="smallqr"><div class="qrbox" id="estQr"></div><div>Handy verloren?<br>Neu scannen – du bist automatisch wieder drin.</div></div>' +
      '<div class="row"><button class="ghost" id="estSkip">Zug überspringen</button><button class="ghost" id="estEnd">Zur Lobby</button></div>';
    if (s.url) $("estQr").innerHTML = qrSvg(s.url);
    $("estSkip").onclick = function () { boardAct("skip"); };
    $("estEnd").onclick = function () { if (confirm("Spiel abbrechen und zurück zur Lobby?")) boardAct("lobby"); };

    // Figuren
    var layer = $("estPawns");
    var alive = s.players;
    var walkMs = 0;
    alive.forEach(function (p, idx) {
      if (!pawnEls[p.id]) {
        var pe = el("div", "epawn", esc(p.name.charAt(0).toUpperCase()));
        pe.style.background = p.color;
        layer.appendChild(pe);
        pawnEls[p.id] = pe;
        placePawn(p, idx, alive.length, p.pos);
      }
      pawnEls[p.id].classList.toggle("gone", !!p.bankrupt);
      pawnEls[p.id].classList.toggle("cur", p.id === s.cur && s.phase === "PLAY");
    });
    Object.keys(pawnEls).forEach(function (id) { if (!playerById(s, +id)) { pawnEls[id].remove(); delete pawnEls[id]; } });
    var mv = s.move;
    if (fresh && mv && mv[4] !== lastMoveSeq && lastMoveSeq !== -1) {
      var mp = playerById(s, mv[0]);
      if (mp) walkMs = animateMove(mp, alive.indexOf(mp), alive.length, mv[1], mv[2], mv[3]);
    }
    if (mv) lastMoveSeq = mv[4]; else lastMoveSeq = 0;
    alive.forEach(function (p, idx) { if (!animating[p.id]) placePawn(p, idx, alive.length, p.pos); });

    // Würfel
    if (s.dice[0]) { setDie(0, s.dice[0]); setDie(1, s.dice[1]); }
    var dbl = s.dice[0] && s.dice[0] === s.dice[1];
    $("die0").classList.toggle("dbl", !!dbl); $("die1").classList.toggle("dbl", !!dbl);
    if (fresh && s.rollSeq !== lastRollSeq && lastRollSeq !== -1 && s.dice[0]) {
      ["die0", "die1"].forEach(function (d, k) {
        var de = $(d); de.classList.remove("rolling"); void de.offsetWidth; de.classList.add("rolling");
        var n = 0, fl = setInterval(function () { setDie(k, 1 + Math.floor(Math.random() * 6)); if (++n > 6) { clearInterval(fl); setDie(k, s.dice[k]); } }, 80);
      });
    }
    lastRollSeq = s.rollSeq;

    // Karte
    var cardNow = fresh && s.card && s.card[3] !== lastCardSeq && lastCardSeq !== -1;
    if (cardNow) showCard(s, e, Math.max(0, walkMs - 200));
    lastCardSeq = s.card ? s.card[3] : 0;

    $("estStatus").innerHTML = s.phase === "FINISHED" ? EST.fmt("{p" + s.winner + "} hat gewonnen!", s) : EST.fmt(s.msg, s);
    panel(s, e);
    $("estLog").innerHTML = "";

    // Banner beim Spielerwechsel
    if (fresh && s.phase === "PLAY" && s.cur !== prevCur && s.st === "roll") {
      var np = playerById(s, s.cur);
      clearTimeout(bannerTimer);
      bannerTimer = setTimeout(function () { banner(np); }, walkMs + 200 + (cardNow || cardShowing() ? 3800 : 0));
    }
    if (fresh) prevCur = s.cur;
    return walkMs;
  }

  function reset() { lastEdition = null; built = false; pawnEls = {}; lastMoveSeq = -1; lastRollSeq = -1; lastCardSeq = -1; prevMoney = {}; prevCur = null;
    var l = $("estPawns"); if (l) l.innerHTML = ""; }

  addEventListener("resize", function () { if (built) { size(); if (S && S.playing === "estate") render(S, false, null); } });

  return { render: render, reset: reset, deedHtml: deedHtml, size: size };
})();
