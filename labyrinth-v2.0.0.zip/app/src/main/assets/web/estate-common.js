/* Stadtbaron – gemeinsame Daten für Beamer, Handy und Editor */
var EST = (function () {
  // Typen wie im Server: 0 Start, 1 Straße, 2 Bahnhof, 3 Werk, 4 Steuer, 5 Zufall, 6 Gemeinschaft, 7 Gefängnis, 8 Parken, 9 Gehe ins Gefängnis
  var T = { START: 0, STREET: 1, STATION: 2, UTILITY: 3, TAX: 4, CHANCE: 5, CHEST: 6, JAIL: 7, PARK: 8, GOJAIL: 9 };
  var F = [];
  function f(i, type, o) { o = o || {}; o.i = i; o.type = type; F[i] = o; }
  f(0, T.START); f(10, T.JAIL); f(20, T.PARK); f(30, T.GOJAIL);
  [2, 17, 33].forEach(function (i) { f(i, T.CHEST); });
  [7, 22, 36].forEach(function (i) { f(i, T.CHANCE); });
  f(4, T.TAX, { tax: 200 }); f(38, T.TAX, { tax: 100 });
  [5, 15, 25, 35].forEach(function (i) { f(i, T.STATION, { price: 200, group: 8 }); });
  [12, 28].forEach(function (i, k) { f(i, T.UTILITY, { price: 150, group: 9, util: k }); });
  function st(i, g, price, house, rent) { f(i, T.STREET, { group: g, price: price, house: house, rent: rent }); }
  st(1, 0, 60, 50, [2, 10, 30, 90, 160, 250]); st(3, 0, 60, 50, [4, 20, 60, 180, 320, 450]);
  st(6, 1, 100, 50, [6, 30, 90, 270, 400, 550]); st(8, 1, 100, 50, [6, 30, 90, 270, 400, 550]); st(9, 1, 120, 50, [8, 40, 100, 300, 450, 600]);
  st(11, 2, 140, 100, [10, 50, 150, 450, 625, 750]); st(13, 2, 140, 100, [10, 50, 150, 450, 625, 750]); st(14, 2, 160, 100, [12, 60, 180, 500, 700, 900]);
  st(16, 3, 180, 100, [14, 70, 200, 550, 750, 950]); st(18, 3, 180, 100, [14, 70, 200, 550, 750, 950]); st(19, 3, 200, 100, [16, 80, 220, 600, 800, 1000]);
  st(21, 4, 220, 150, [18, 90, 250, 700, 875, 1050]); st(23, 4, 220, 150, [18, 90, 250, 700, 875, 1050]); st(24, 4, 240, 150, [20, 100, 300, 750, 925, 1100]);
  st(26, 5, 260, 150, [22, 110, 330, 800, 975, 1150]); st(27, 5, 260, 150, [22, 110, 330, 800, 975, 1150]); st(29, 5, 280, 150, [24, 120, 360, 850, 1025, 1200]);
  st(31, 6, 300, 200, [26, 130, 390, 900, 1100, 1275]); st(32, 6, 300, 200, [26, 130, 390, 900, 1100, 1275]); st(34, 6, 320, 200, [28, 150, 450, 1000, 1200, 1400]);
  st(37, 7, 350, 200, [35, 175, 500, 1100, 1300, 1500]); st(39, 7, 400, 200, [50, 200, 600, 1400, 1700, 2000]);

  var GROUPS = [];
  for (var g = 0; g < 10; g++) GROUPS.push([]);
  F.forEach(function (x) { if (x.group != null) GROUPS[x.group].push(x.i); });

  var DEFAULT_COLORS = ["#8d5524", "#81d4fa", "#ec407a", "#ff9800", "#e53935", "#fdd835", "#43a047", "#1565c0"];

  // Standard-Kartentexte (Platzhalter: {fN} Feldname, {mN} Betrag, {jail} Gefängnis-Wort)
  var CARDS = {
    chance: [
      "Rücke vor bis {f0}.",
      "Rücke vor bis {f24}. Kommst du über {f0}, erhältst du {m200}.",
      "Rücke vor bis {f11}. Kommst du über {f0}, erhältst du {m200}.",
      "Rücke vor zum nächsten Werk. Gehört es jemandem, wird gewürfelt und du zahlst das Zehnfache.",
      "Rücke vor zum nächsten Bahnhof und zahle dem Besitzer die doppelte Miete.",
      "Rücke vor zum nächsten Bahnhof und zahle dem Besitzer die doppelte Miete.",
      "Die Bank zahlt dir eine Dividende von {m50}.",
      "Du kommst aus dem {jail} frei. Behalte diese Karte, bis du sie brauchst.",
      "Gehe 3 Felder zurück.",
      "Gehe direkt ins {jail}. Gehe nicht über {f0}.",
      "Renoviere deine Gebäude: {m25} je Haus, {m100} je Hotel.",
      "Zu schnell unterwegs: Zahle {m15}.",
      "Fahre zu {f5}. Kommst du über {f0}, erhältst du {m200}.",
      "Rücke vor bis {f39}.",
      "Du wurdest zum Vorsitz gewählt: Zahle jedem Spieler {m50}.",
      "Dein Bausparvertrag ist fällig: Erhalte {m150}."
    ],
    chest: [
      "Rücke vor bis {f0}.",
      "Fehler der Bank zu deinen Gunsten: Erhalte {m200}.",
      "Arztrechnung: Zahle {m50}.",
      "Aktien verkauft: Erhalte {m50}.",
      "Du kommst aus dem {jail} frei. Behalte diese Karte, bis du sie brauchst.",
      "Gehe direkt ins {jail}. Gehe nicht über {f0}.",
      "Urlaubsgeld wird ausgezahlt: Erhalte {m100}.",
      "Steuerrückzahlung: Erhalte {m20}.",
      "Du hast Geburtstag: Jeder Spieler schenkt dir {m10}.",
      "Deine Lebensversicherung wird fällig: Erhalte {m100}.",
      "Krankenhausrechnung: Zahle {m100}.",
      "Schulgeld: Zahle {m50}.",
      "Beratungshonorar: Erhalte {m25}.",
      "Straßenausbau: Zahle {m40} je Haus und {m115} je Hotel.",
      "Zweiter Platz beim Schönheitswettbewerb: Erhalte {m10}.",
      "Du erbst {m100}."
    ]
  };

  var BUILTIN = [{ id: "stuttgart", title: "Stuttgart & Umgebung" }, { id: "piraten", title: "Piratenwelt" }];

  // ---------- Editionen laden ----------
  var cache = {}, current = null, currentId = null, waiting = [];

  function defaults(e) {
    e = e || {};
    e.title = e.title || "Stadtbaron";
    e.currency = e.currency || "€";
    e.currencyPos = e.currencyPos || "after";
    e.chance = e.chance || "Zufall";
    e.chest = e.chest || "Gemeinschaft";
    e.jail = e.jail || "Gefängnis";
    e.colors = e.colors && e.colors.length === 8 ? e.colors : DEFAULT_COLORS;
    e.fields = e.fields && e.fields.length === 40 ? e.fields : [];
    for (var i = 0; i < 40; i++) if (!e.fields[i]) e.fields[i] = "Feld " + i;
    e.cards = e.cards || {};
    e.icons = e.icons || {};
    return e;
  }

  function load(id, cb) {
    id = id || "stuttgart";
    if (cache[id]) { cb(cache[id]); return; }
    var url = /^c-/.test(id) ? "/api/edition?id=" + encodeURIComponent(id) : "editions/" + id + ".json";
    fetch(url, { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (e) {
      if (e && e.ok === false) throw new Error(e.error);
      cache[id] = defaults(e); cb(cache[id]);
    }).catch(function () {
      if (id !== "stuttgart") load("stuttgart", cb); else { cache[id] = defaults({}); cb(cache[id]); }
    });
  }

  /** Aktuelle Edition passend zum Spielstand; ruft cb auf, sobald geladen. */
  function use(id, cb) {
    id = id || "stuttgart";
    if (currentId === id && current) { cb(current); return; }
    load(id, function (e) { currentId = id; current = e; cb(e); });
  }

  function forget(id) { delete cache[id]; if (currentId === id) { current = null; currentId = null; } }

  // ---------- Formatierung ----------
  function money(n, e) {
    e = e || current || defaults({});
    var s = String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return e.currencyPos === "before" ? e.currency + " " + s : s + " " + e.currency;
  }

  function fieldName(i, e) { e = e || current || defaults({}); return e.fields[i] || ("Feld " + i); }

  function cardText(deck, idx, e) {
    e = e || current || defaults({});
    var name = deck === 0 ? "chance" : "chest";
    var t = (e.cards[name] && e.cards[name][idx]) || CARDS[name][idx];
    return fmt(t, null, e, true);
  }

  /** Platzhalter ersetzen. plain=true: ohne HTML-Hervorhebung. */
  function fmt(t, s, e, plain) {
    e = e || current || defaults({});
    return String(t)
      .replace(/\{jail\}/g, esc(e.jail))
      .replace(/\{c(\d)_(\d+)\}/g, function (_, d, i) { return "„" + cardText(+d, +i, e) + "“"; })
      .replace(/\{p(\d+)\}/g, function (_, id) {
        var p = s && playerById(s, +id);
        if (!p) return "?";
        return plain ? esc(p.name) : '<b style="color:' + p.color + '">' + esc(p.name) + "</b>";
      })
      .replace(/\{f(\d+)\}/g, function (_, i) { return plain ? esc(fieldName(+i, e)) : "<b>" + esc(fieldName(+i, e)) + "</b>"; })
      .replace(/\{m(\d+)\}/g, function (_, n) { return money(+n, e); });
  }

  function logLines(s, n) {
    var out = [];
    (s.log || []).slice(-(n || 6)).forEach(function (l) {
      var k = l.indexOf("|");
      out.push({ seq: +l.slice(0, k), html: fmt(l.slice(k + 1), s) });
    });
    return out;
  }

  function color(i, e) { e = e || current || defaults({}); var x = F[i]; return x && x.group != null && x.group < 8 ? e.colors[x.group] : null; }

  function icon(i, e) {
    e = e || current || defaults({});
    var x = F[i];
    var ic = e.icons || {};
    switch (x.type) {
      case T.START: return ic.start || "➡️";
      case T.STATION: return ic.station || "🚉";
      case T.UTILITY: return x.util === 0 ? (ic.power || "💡") : (ic.water || "🚰");
      case T.TAX: return ic.tax || "💰";
      case T.CHANCE: return ic.chance || "❓";
      case T.CHEST: return ic.chest || "📦";
      case T.JAIL: return ic.jail || "🔒";
      case T.PARK: return ic.park || "🅿️";
      case T.GOJAIL: return ic.gojail || "👮";
    }
    return "";
  }

  /** Aktuelle Miete (für Anzeige). */
  function rentInfo(s, i) {
    var x = F[i], fl = s.fields[i], o = fl[0];
    if (o < 0 || fl[2]) return 0;
    if (x.type === T.STREET) {
      if (fl[1] > 0) return x.rent[fl[1]];
      var all = GROUPS[x.group].every(function (k) { return s.fields[k][0] === o; });
      return all ? x.rent[0] * 2 : x.rent[0];
    }
    if (x.type === T.STATION) {
      var n = GROUPS[8].filter(function (k) { return s.fields[k][0] === o; }).length;
      return 25 << (n - 1);
    }
    return -1; // Werk: abhängig vom Wurf
  }

  /** Position (Zeile, Spalte) im 11x11-Raster. */
  function gridPos(i) {
    if (i <= 10) return [10, 10 - i];
    if (i <= 20) return [10 - (i - 10), 0];
    if (i <= 30) return [0, i - 20];
    return [i - 30, 10];
  }

  /** Seite des Feldes: 0 unten, 1 links, 2 oben, 3 rechts (Ecken: -1). */
  function side(i) { if (i % 10 === 0) return -1; return Math.floor(i / 10); }

  return { T: T, F: F, GROUPS: GROUPS, CARDS: CARDS, BUILTIN: BUILTIN, DEFAULT_COLORS: DEFAULT_COLORS,
    load: load, use: use, forget: forget, defaults: defaults, money: money, fieldName: fieldName, cardText: cardText,
    fmt: fmt, logLines: logLines, color: color, icon: icon, rentInfo: rentInfo, gridPos: gridPos, side: side,
    get: function () { return current || defaults({}); } };
})();
